// Background Service Worker for FB Video AI Title & Description Generator
// Powered by Google Gemini Vision (gemini-3.8-flash)

const DEFAULT_API_KEY = 'AQ.Ab8RN6ITtQPSjP9mMkKauhAMAvSPOEKBBdEW0HboC5or-j_THA';

const DEFAULT_SETTINGS = {
  geminiApiKey: DEFAULT_API_KEY,
  geminiModel: 'gemini-3.8-flash',
  language: 'auto', // 'auto', 'en', 'ur', 'roman_ur', 'hi'
  tone: 'viral', // 'viral', 'storytelling', 'professional', 'funny', 'educational'
  includeHashtags: true,
  includeTimestamps: false,
  frameCount: 6,
  customPrompt: ''
};

// Initialize settings on installation or load
chrome.runtime.onInstalled.addListener(async () => {
  const data = await chrome.storage.local.get(null);
  const updated = { ...DEFAULT_SETTINGS, ...data };
  // Ensure the Pro API key is set if key is currently empty or outdated
  if (!updated.geminiApiKey || updated.geminiApiKey.startsWith('AQ.Ab8RN6LqO')) {
    updated.geminiApiKey = DEFAULT_API_KEY;
  }
  if (!updated.geminiModel || updated.geminiModel.includes('1.5') || updated.geminiModel.includes('2.5')) {
    updated.geminiModel = 'gemini-3.8-flash';
  }
  await chrome.storage.local.set(updated);
  console.log('[FB Video AI] Initialized with Pro API Key and Gemini 3.8 Flash:', updated);
});

// Message listener
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'TEST_API_KEY') {
    testApiKey(request.apiKey || DEFAULT_API_KEY, request.model || 'gemini-3.8-flash')
      .then(res => sendResponse(res))
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true;
  }

  if (request.action === 'GENERATE_TITLE_DESCRIPTION') {
    handleGenerateRequest(request.payload)
      .then(res => sendResponse(res))
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true;
  }
});

/**
 * Test user's Gemini API Key
 */
async function testApiKey(apiKey, model = 'gemini-3.8-flash') {
  const cleanKey = (apiKey || DEFAULT_API_KEY).trim();
  if (!cleanKey) {
    return { success: false, error: 'API key is empty. Please enter a valid Gemini API Key.' };
  }

  const candidateModels = [model, 'gemini-3.8-flash', 'gemini-3.6-flash', 'gemini-flash-latest'];

  for (const m of candidateModels) {
    try {
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${m}:generateContent?key=${cleanKey}`;
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text: 'Respond with the single word: "READY"' }] }],
          generationConfig: { temperature: 0.1, maxOutputTokens: 10 }
        })
      });

      const data = await res.json();
      if (res.ok) {
        return { success: true, message: `Connected successfully to Google Gemini (${m})!` };
      }
      // If 404/503 try next model in list
      if (res.status === 404 || res.status === 503) {
        continue;
      }
      const errMsg = data.error ? data.error.message : `HTTP error ${res.status}`;
      return { success: false, error: errMsg };
    } catch (err) {
      console.warn(`Test failed on ${m}:`, err);
    }
  }

  return { success: false, error: 'Could not connect to Gemini API. Please check your network and API key.' };
}

/**
 * Handle multimodal video analysis and title/description generation
 */
async function handleGenerateRequest(payload) {
  const settings = await chrome.storage.local.get(null);
  const apiKey = (payload.apiKey || settings.geminiApiKey || DEFAULT_API_KEY).trim();
  const preferredModel = payload.model || settings.geminiModel || 'gemini-3.8-flash';
  const language = payload.language || settings.language || 'auto';
  const tone = payload.tone || settings.tone || 'viral';

  if (!apiKey) {
    return {
      success: false,
      error: 'Google Gemini API key not found! Please check the extension settings.'
    };
  }

  let languageInstruction = '';
  if (language === 'ur') {
    languageInstruction = 'Generate output in Urdu script (اردو) with high emotional appeal and strong hooks.';
  } else if (language === 'roman_ur') {
    languageInstruction = 'Generate output in catchy Roman Urdu / Hinglish (e.g. "Yeh video end tak zaroor dekhein, aisi cheez pehle kabhi nahi dekhi hogi!").';
  } else if (language === 'hi') {
    languageInstruction = 'Generate output in engaging Hindi.';
  } else if (language === 'en') {
    languageInstruction = 'Generate output in viral, modern high-retention English.';
  } else {
    languageInstruction = 'Intelligently analyze the visual context. If the video content or context relates to South Asia, provide a catchy Roman Urdu / English blend. Otherwise use viral English with power words and emojis.';
  }

  let toneInstruction = '';
  switch (tone) {
    case 'viral':
      toneInstruction = 'Tone: Ultra-high energy, curiosity gap, suspense, emotional hook, optimized for Facebook Reels & Video algorithm virality.';
      break;
    case 'storytelling':
      toneInstruction = 'Tone: Cinematic, narrative, suspenseful, touching, deep viewer engagement.';
      break;
    case 'professional':
      toneInstruction = 'Tone: Informative, authoritative, polished, clear value proposition.';
      break;
    case 'funny':
      toneInstruction = 'Tone: Humorous, witty, relatable meme style, high shareability.';
      break;
    case 'educational':
      toneInstruction = 'Tone: Value-packed, step-by-step insight, actionable takeaway.';
      break;
    default:
      toneInstruction = 'Tone: Viral, captivating, and high retention.';
  }

  const prompt = `You are an elite viral content strategist and copywriter for Facebook & Meta Reels.
I am providing you with multiple keyframe images captured across the timeline of an uploaded Facebook Video / Reel.

YOUR INSTRUCTIONS:
1. VISUAL DEEP ANALYSIS:
   - Carefully inspect every detail in these frames: What is shown? Who is in it? What actions, animations, fantasy creatures, characters, transformations, scenery, objects, or dramatic events take place?
   - Identify the exact core theme, emotion, and aesthetic of the video.

2. VIRAL HOOK & TITLE CREATION:
   - Create 1 Primary Viral Title ("bestTitle") that instantly grabs attention in Facebook feeds (under 75 characters, incorporates 1-2 impactful emojis, impossible to scroll past).
   - Create 4 distinct Alternative Titles ("titleOptions"):
     a) Curiosity Gap hook ("You won't believe what happens when...")
     b) Question / Debate hook
     c) Emotional / Dramatic hook
     d) Short punchy punchline hook

3. ENGAGING DESCRIPTION & HASHTAGS:
   - Write an irresistible Facebook Post / Reel Description ("description"):
     - Line 1: Strong hook sentence that stops the scroll.
     - Lines 2-3: Engaging story context / teaser without giving away the climax.
     - Call to Action: e.g. "🔥 Share this with your friends and tell us your thoughts in the comments!" or "👇 Tag someone who needs to see this!"
     - 8 to 12 trending, highly-relevant hashtags at the bottom.

4. LANGUAGE & TONE:
   - ${languageInstruction}
   - ${toneInstruction}

Respond strictly in valid JSON format only:
{
  "bestTitle": "string",
  "titleOptions": ["option 1", "option 2", "option 3", "option 4"],
  "description": "string",
  "summary": "detailed 2-sentence summary of what is visually happening in the video",
  "hashtags": ["#tag1", "#tag2", "#tag3"]
}`;

  // Prepare multimodal parts
  const parts = [{ text: prompt }];

  if (payload.frames && Array.isArray(payload.frames) && payload.frames.length > 0) {
    payload.frames.forEach((frameDataUrl) => {
      const match = frameDataUrl.match(/^data:(image\/[a-zA-Z]+);base64,(.+)$/);
      if (match) {
        parts.push({
          inlineData: {
            mimeType: match[1],
            data: match[2]
          }
        });
      }
    });
  } else {
    parts.push({
      text: `Context Hint: Facebook video upload preview. Please craft maximum virality title and description suggestions based on top trending Facebook video styles.`
    });
  }

  // Model fallback chain
  const modelsToTry = [preferredModel, 'gemini-3.8-flash', 'gemini-3.6-flash', 'gemini-flash-latest'];
  const uniqueModels = [...new Set(modelsToTry)];

  let lastError = null;

  for (const model of uniqueModels) {
    try {
      console.log(`[FB Video AI] Requesting Gemini model: ${model}`);
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;

      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts }],
          generationConfig: {
            temperature: 0.75,
            topP: 0.95
          }
        })
      });

      const data = await res.json();
      if (!res.ok) {
        const msg = data.error?.message || `HTTP ${res.status}`;
        console.warn(`[FB Video AI] Model ${model} returned error:`, msg);
        lastError = new Error(msg);
        if (res.status === 404 || res.status === 503) {
          continue; // Try next model
        }
        throw lastError;
      }

      const rawText = data.candidates?.[0]?.content?.parts?.[0]?.text;
      if (!rawText) {
        throw new Error('Received empty content from Gemini AI.');
      }

      const parsed = parseGeminiJson(rawText);
      return { success: true, data: parsed, modelUsed: model };

    } catch (err) {
      lastError = err;
      console.warn(`[FB Video AI] Attempt with ${model} failed:`, err.message);
    }
  }

  throw lastError || new Error('All Gemini model attempts failed.');
}

function parseGeminiJson(text) {
  let cleaned = text.trim();
  cleaned = cleaned.replace(/^```json\s*/i, '').replace(/^```\s*/, '').replace(/\s*```$/, '');
  try {
    return JSON.parse(cleaned);
  } catch (e) {
    // Fallback extraction
    const firstLine = cleaned.split('\n')[0] || 'Viral Facebook Video';
    return {
      bestTitle: firstLine.replace(/^[#*"\s]+|["\s]+$/g, ''),
      titleOptions: [
        firstLine,
        'Watch This Incredible Video! 🔥',
        'You Won’t Believe What Happened!',
        'Must Watch Till The End!'
      ],
      description: cleaned,
      summary: 'Video analyzed by Gemini AI',
      hashtags: ['#Viral', '#FacebookReels', '#Trending', '#MustWatch']
    };
  }
}
