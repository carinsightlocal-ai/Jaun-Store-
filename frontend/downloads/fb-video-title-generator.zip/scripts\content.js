// Content Script for Facebook & Meta Business Suite Video AI Generator
// Supports: facebook.com post creator, reels_composer, business.facebook.com

(function () {
  'use strict';

  console.log('[FB Video AI] Enhanced Content Script initialized.');

  let isAnalyzing = false;
  let activeResultsModal = null;
  let activeToast = null;
  let lastGeneratedResult = null;

  // Run DOM scan frequently to catch React route changes, modal openings, and tab transitions
  const observer = new MutationObserver(() => {
    injectAllAiButtons();
    autoFillPendingIfPresent();
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true
  });

  // Initial check on load
  setTimeout(() => {
    injectAllAiButtons();
    autoFillPendingIfPresent();
  }, 1000);

  /**
   * Main scan routine to inject buttons in all relevant areas
   */
  function injectAllAiButtons() {
    injectInMediaSection();
    injectInPreviewHeader();
    injectInTitleField();
    checkVideoUploadPresence();
  }

  /**
   * 1. INJECT IN META BUSINESS SUITE "MEDIA" SECTION
   * (e.g. Next to [+ Add Video], [+ Add Photos] in Reels Composer)
   */
  function injectInMediaSection() {
    // Look for "Add Video" or "Add Photos" buttons
    const allButtons = Array.from(document.querySelectorAll('button, div[role="button"]'));
    const addVideoBtn = allButtons.find(b => {
      const txt = (b.textContent || '').trim().toLowerCase();
      return txt.includes('add video') || txt.includes('add photos');
    });

    if (addVideoBtn) {
      const container = addVideoBtn.parentElement;
      if (container && !container.querySelector('.fb-ai-media-btn')) {
        const aiBtn = createGenerateButton('fb-ai-media-btn', '✨ AI Generate Title & Description');
        container.appendChild(aiBtn);
      }
      return;
    }

    // Fallback: look for header text "Media" or "Upload video"
    const mediaHeaders = Array.from(document.querySelectorAll('h1, h2, h3, h4, span, div'));
    const mediaHeader = mediaHeaders.find(el => {
      return el.children.length === 0 && (el.textContent || '').trim().toLowerCase() === 'media';
    });

    if (mediaHeader) {
      const parentCard = mediaHeader.closest('div[class*="card"], div[class*="section"]') || mediaHeader.parentElement;
      if (parentCard && !parentCard.querySelector('.fb-ai-media-btn')) {
        const aiBtn = createGenerateButton('fb-ai-media-btn', '✨ AI Generate Title & Description');
        mediaHeader.insertAdjacentElement('afterend', aiBtn);
      }
    }
  }

  /**
   * 2. INJECT IN "Facebook reel preview" HEADER
   */
  function injectInPreviewHeader() {
    const allElements = Array.from(document.querySelectorAll('span, div, h2, h3'));
    const previewHeader = allElements.find(el => {
      const txt = (el.textContent || '').trim().toLowerCase();
      return txt === 'facebook reel preview' || txt.includes('reel preview');
    });

    if (previewHeader) {
      const headerContainer = previewHeader.parentElement;
      if (headerContainer && !headerContainer.querySelector('.fb-ai-preview-header-btn')) {
        const aiBtn = createGenerateButton('fb-ai-preview-header-btn', '✨ AI Generate');
        headerContainer.style.display = 'flex';
        headerContainer.style.alignItems = 'center';
        headerContainer.style.justifyContent = 'space-between';
        headerContainer.appendChild(aiBtn);
      }
    }
  }

  /**
   * 3. INJECT NEXT TO TITLE / CAPTION INPUT FIELDS
   */
  function injectInTitleField() {
    const titleInput = findTitleInput();
    if (!titleInput) return;

    const parent = titleInput.parentElement;
    if (!parent || parent.querySelector('.fb-ai-title-btn')) return;

    const btn = createGenerateButton('fb-ai-title-btn', '✨ AI Generate');
    if (parent.style.display === 'flex') {
      parent.appendChild(btn);
    } else {
      titleInput.insertAdjacentElement('afterend', btn);
    }
  }

  /**
   * Helper to create styled generate button
   */
  function createGenerateButton(className, text) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = className;
    btn.title = 'Deeply analyze video and generate viral Title & Description';
    btn.innerHTML = `<span class="fb-ai-sparkle">✨</span> <span>${text}</span>`;

    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      startDeepVideoAnalysis();
    });

    return btn;
  }

  /**
   * 4. FLOATING ACTION WIDGET
   */
  function checkVideoUploadPresence() {
    const video = findVideoElement();
    const existingWidget = document.querySelector('.fb-ai-floating-widget');

    if (video) {
      if (!existingWidget) {
        const widget = document.createElement('div');
        widget.className = 'fb-ai-floating-widget';
        widget.innerHTML = `
          <button class="fb-ai-floating-btn" id="fbAiFloatingTrigger">
            <span class="fb-ai-sparkle">✨</span> AI Generate Title & Description
          </button>
          <button class="fb-ai-floating-close" title="Dismiss" id="fbAiFloatingClose">✕</button>
        `;

        widget.querySelector('#fbAiFloatingTrigger').addEventListener('click', () => {
          startDeepVideoAnalysis();
        });

        widget.querySelector('#fbAiFloatingClose').addEventListener('click', () => {
          widget.remove();
        });

        document.body.appendChild(widget);
      }
    } else {
      if (existingWidget && !isAnalyzing) {
        existingWidget.remove();
      }
    }
  }

  /**
   * Locate Title Input element
   */
  function findTitleInput() {
    const candidates = Array.from(document.querySelectorAll('input[type="text"], input:not([type])'));
    for (const input of candidates) {
      const ph = (input.getAttribute('placeholder') || '').toLowerCase();
      const aria = (input.getAttribute('aria-label') || '').toLowerCase();
      const name = (input.getAttribute('name') || '').toLowerCase();
      const testId = (input.getAttribute('data-testid') || '').toLowerCase();

      if (ph.includes('title') || aria.includes('title') || name.includes('title') || testId.includes('title')) {
        return input;
      }
    }

    const metaTitle = document.querySelector('[data-testid*="video-title"] input, [aria-label*="Video title" i]');
    if (metaTitle) return metaTitle;

    return null;
  }

  /**
   * Locate Description / Caption box
   */
  function findDescriptionInput() {
    // 1. Facebook contenteditable textbox
    const editors = Array.from(document.querySelectorAll('div[role="textbox"][contenteditable="true"]'));
    if (editors.length > 0) return editors[0];

    // 2. Textarea
    const textareas = Array.from(document.querySelectorAll('textarea'));
    for (const ta of textareas) {
      const ph = (ta.getAttribute('placeholder') || '').toLowerCase();
      const aria = (ta.getAttribute('aria-label') || '').toLowerCase();
      if (ph.includes('description') || ph.includes('text') || ph.includes('caption') || ph.includes('describe') ||
          aria.includes('description') || aria.includes('caption') || aria.includes('describe')) {
        return ta;
      }
    }

    if (textareas.length > 0) return textareas[0];
    return null;
  }

  /**
   * Locate <video> preview
   */
  function findVideoElement() {
    const videos = Array.from(document.querySelectorAll('video'));
    if (videos.length === 0) return null;

    // Prefer video with blob or duration
    const blobVideo = videos.find(v => v.src && v.src.startsWith('blob:'));
    if (blobVideo) return blobVideo;

    const readyVideo = videos.find(v => v.readyState >= 1 || v.duration > 0);
    if (readyVideo) return readyVideo;

    return videos[0];
  }

  /**
   * Extract Thumbnail image from Media section if available
   */
  async function extractThumbnailImage() {
    try {
      // Find thumbnail in Media card
      const imgs = Array.from(document.querySelectorAll('img'));
      const thumb = imgs.find(img => {
        const src = img.src || '';
        return (src.startsWith('blob:') || src.includes('fbcdn.net')) && img.naturalWidth > 60;
      });

      if (thumb && thumb.complete && thumb.naturalWidth > 0) {
        const canvas = document.createElement('canvas');
        canvas.width = Math.min(thumb.naturalWidth, 800);
        canvas.height = Math.min(thumb.naturalHeight, 800);
        const ctx = canvas.getContext('2d');
        ctx.drawImage(thumb, 0, 0, canvas.width, canvas.height);
        return canvas.toDataURL('image/jpeg', 0.85);
      }
    } catch (e) {
      console.warn('[FB Video AI] Thumbnail capture error:', e);
    }
    return null;
  }

  /**
   * DEEP VIDEO FRAME EXTRACTION (Takes 6 high-res frames across full timeline)
   */
  async function extractDeepVideoFrames(videoElement, frameCount = 6) {
    if (!videoElement) return [];

    return new Promise(async (resolve) => {
      const frames = [];
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');

      const width = Math.min(videoElement.videoWidth || 720, 960);
      const height = Math.min(videoElement.videoHeight || 1280, 1280);
      canvas.width = width;
      canvas.height = height;

      const duration = videoElement.duration || 15;
      const initialTime = videoElement.currentTime || 0;

      // Evenly distribute keyframes across the video (10%, 25%, 45%, 65%, 85%, 95%)
      const percentages = [0.10, 0.25, 0.45, 0.65, 0.85, 0.95];
      const timestamps = percentages.slice(0, frameCount).map(p => duration * p);

      for (let i = 0; i < timestamps.length; i++) {
        showToast(`Deep Analysis: Capturing keyframe ${i + 1}/${timestamps.length}...`);
        const targetTime = timestamps[i];
        try {
          await seekVideo(videoElement, targetTime);
          ctx.drawImage(videoElement, 0, 0, width, height);
          const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
          frames.push(dataUrl);
        } catch (captureErr) {
          console.warn('[FB Video AI] Frame capture error:', captureErr);
        }
      }

      // Restore video position
      try {
        videoElement.currentTime = initialTime;
      } catch (e) {}

      resolve(frames);
    });
  }

  function seekVideo(video, time) {
    return new Promise((resolve) => {
      let isResolved = false;

      const onSeeked = () => {
        if (!isResolved) {
          isResolved = true;
          video.removeEventListener('seeked', onSeeked);
          setTimeout(resolve, 80); // Ensure frame rendering
        }
      };

      video.addEventListener('seeked', onSeeked, { once: true });
      video.currentTime = Math.max(0, Math.min(time, (video.duration || 15) - 0.2));

      setTimeout(() => {
        if (!isResolved) {
          isResolved = true;
          video.removeEventListener('seeked', onSeeked);
          resolve();
        }
      }, 400);
    });
  }

  /**
   * MAIN WORKFLOW: Deep Analysis & Generation
   */
  async function startDeepVideoAnalysis() {
    if (isAnalyzing) return;
    isAnalyzing = true;

    // Set buttons to loading state
    const allGenButtons = document.querySelectorAll('.fb-ai-title-btn, .fb-ai-media-btn, .fb-ai-preview-header-btn');
    allGenButtons.forEach(b => {
      b.classList.add('loading');
      b.innerHTML = `<div class="fb-ai-toast-spinner"></div> <span>Analyzing Video...</span>`;
    });

    try {
      showToast('Step 1/3: Inspecting uploaded video & frames...');

      // 1. Get Settings
      const settings = await chrome.storage.local.get([
        'geminiApiKey',
        'geminiModel',
        'language',
        'tone',
        'frameCount'
      ]);

      const count = settings.frameCount || 6;
      const videoEl = findVideoElement();

      let frames = [];

      // Add thumbnail if accessible
      const thumbData = await extractThumbnailImage();
      if (thumbData) {
        frames.push(thumbData);
      }

      // Extract keyframes from video player
      if (videoEl) {
        const extracted = await extractDeepVideoFrames(videoEl, count);
        frames.push(...extracted);
        console.log(`[FB Video AI] Successfully captured ${frames.length} visual frames.`);
      }

      showToast('Step 2/3: Google Gemini 3.8 Flash is analyzing visual content...');

      // 2. Call Background Service Worker
      const response = await chrome.runtime.sendMessage({
        action: 'GENERATE_TITLE_DESCRIPTION',
        payload: {
          frames: frames,
          apiKey: settings.geminiApiKey,
          model: settings.geminiModel || 'gemini-3.8-flash',
          language: settings.language || 'auto',
          tone: settings.tone || 'viral',
          hint: 'Meta Business Suite Reel Upload'
        }
      });

      if (!response || !response.success) {
        const errorMsg = response?.error || 'Failed to analyze video.';
        alert(`[FB Video AI Error] ${errorMsg}`);
        hideToast();
        return;
      }

      const data = response.data;
      lastGeneratedResult = data;
      // Save in session storage so it persists between Step 1 (Create) and Step 2/3 (Share)
      sessionStorage.setItem('fb_ai_last_data', JSON.stringify(data));

      showToast('Step 3/3: Auto-filling Title & Description...');
      hideToast();

      // 3. Auto-fill available inputs
      autoFillInputs(data.bestTitle, data.description);

      // 4. Show Sleek Results Modal
      showResultsModal(data);

    } catch (err) {
      console.error('[FB Video AI] Error in generation:', err);
      alert(`Error: ${err.message}`);
      hideToast();
    } finally {
      isAnalyzing = false;
      allGenButtons.forEach(b => {
        b.classList.remove('loading');
        b.innerHTML = `<span class="fb-ai-sparkle">✨</span> <span>AI Generate</span>`;
      });
    }
  }

  /**
   * Automatically fill Title & Description
   */
  function autoFillInputs(title, description) {
    let filledAny = false;

    // Fill Title
    const titleInput = findTitleInput();
    if (titleInput && title) {
      setReactInputValue(titleInput, title);
      filledAny = true;
    }

    // Fill Description / Caption
    const descInput = findDescriptionInput();
    if (descInput && description) {
      if (descInput.isContentEditable) {
        setReactContentEditable(descInput, description);
        filledAny = true;
      } else if (descInput.tagName === 'TEXTAREA' || descInput.tagName === 'INPUT') {
        setReactInputValue(descInput, description);
        filledAny = true;
      }
    }

    return filledAny;
  }

  /**
   * If user navigated to Step 3 / Caption step, auto-fill pending data
   */
  function autoFillPendingIfPresent() {
    if (!lastGeneratedResult) {
      const stored = sessionStorage.getItem('fb_ai_last_data');
      if (stored) {
        try { lastGeneratedResult = JSON.parse(stored); } catch (e) {}
      }
    }

    if (lastGeneratedResult) {
      const descInput = findDescriptionInput();
      if (descInput) {
        const currentVal = descInput.isContentEditable ? descInput.innerText : descInput.value;
        if (!currentVal || currentVal.trim() === '') {
          autoFillInputs(lastGeneratedResult.bestTitle, lastGeneratedResult.description);
        }
      }
    }
  }

  function setReactInputValue(input, val) {
    try {
      const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
      if (nativeSetter) {
        nativeSetter.call(input, val);
      } else {
        input.value = val;
      }
      input.dispatchEvent(new Event('input', { bubbles: true }));
      input.dispatchEvent(new Event('change', { bubbles: true }));
    } catch (e) {
      input.value = val;
    }
  }

  function setReactContentEditable(element, text) {
    try {
      element.focus();
      document.execCommand('selectAll', false, null);
      document.execCommand('insertText', false, text);
      element.dispatchEvent(new Event('input', { bubbles: true }));
    } catch (e) {
      element.innerText = text;
      element.dispatchEvent(new Event('input', { bubbles: true }));
    }
  }

  /**
   * Display Interactive Modal Card
   */
  function showResultsModal(data) {
    if (activeResultsModal) activeResultsModal.remove();

    const overlay = document.createElement('div');
    overlay.className = 'fb-ai-modal-overlay';

    const optionsHtml = (data.titleOptions || [])
      .map(opt => `
        <div class="fb-ai-alt-item">
          <span>${escapeHtml(opt)}</span>
          <button class="fb-ai-alt-btn" data-title="${escapeHtml(opt)}">Use This</button>
        </div>
      `).join('');

    const hashtagsHtml = (data.hashtags || [])
      .map(t => `<span style="color:#818cf8; margin-right:6px; font-weight:600;">${escapeHtml(t)}</span>`)
      .join(' ');

    overlay.innerHTML = `
      <div class="fb-ai-modal-card">
        <div class="fb-ai-modal-header">
          <div class="fb-ai-modal-title">
            <span>✨</span> Video AI Deep Analysis Results
          </div>
          <button class="fb-ai-modal-close" id="fbModalCloseBtn">✕</button>
        </div>

        <div class="fb-ai-modal-body">
          ${data.summary ? `
            <div class="fb-ai-summary-badge">
              <strong>🔍 Video Visual Analysis:</strong> ${escapeHtml(data.summary)}
            </div>
          ` : ''}

          <!-- Best Title -->
          <div class="fb-ai-section">
            <div class="fb-ai-label">
              <span>🔥 Primary Viral Title</span>
              <button class="fb-ai-alt-btn" id="fbCopyTitleBtn">Copy Title</button>
            </div>
            <div class="fb-ai-title-box" id="fbCurrentTitleText">${escapeHtml(data.bestTitle)}</div>
          </div>

          <!-- Alternative Titles -->
          ${data.titleOptions && data.titleOptions.length > 0 ? `
            <div class="fb-ai-section">
              <div class="fb-ai-label">
                <span>💡 4 Viral Title Hook Variations</span>
              </div>
              <div class="fb-ai-alt-titles">
                ${optionsHtml}
              </div>
            </div>
          ` : ''}

          <!-- Description -->
          <div class="fb-ai-section">
            <div class="fb-ai-label">
              <span>📝 Reel Description & Viral Hooks</span>
              <button class="fb-ai-alt-btn" id="fbCopyDescBtn">Copy Description</button>
            </div>
            <div class="fb-ai-desc-box" id="fbCurrentDescText">${escapeHtml(data.description)}</div>
          </div>

          <!-- Hashtags -->
          ${hashtagsHtml ? `
            <div class="fb-ai-section">
              <div class="fb-ai-label">
                <span>#️⃣ Viral Hashtags</span>
              </div>
              <div style="font-size:12px; line-height:1.6;">${hashtagsHtml}</div>
            </div>
          ` : ''}
        </div>

        <div class="fb-ai-modal-footer">
          <button class="fb-ai-btn fb-ai-btn-secondary" id="fbReAnalyzeBtn">🔄 Re-Analyze Video</button>
          <button class="fb-ai-btn fb-ai-btn-primary" id="fbApplyAllBtn">✓ Auto-Fill to Post</button>
        </div>
      </div>
    `;

    // Close
    overlay.querySelector('#fbModalCloseBtn').addEventListener('click', () => overlay.remove());
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) overlay.remove();
    });

    // Copy Title
    overlay.querySelector('#fbCopyTitleBtn').addEventListener('click', () => {
      const text = overlay.querySelector('#fbCurrentTitleText').textContent;
      navigator.clipboard.writeText(text);
      overlay.querySelector('#fbCopyTitleBtn').textContent = 'Copied! ✓';
      setTimeout(() => overlay.querySelector('#fbCopyTitleBtn').textContent = 'Copy Title', 1500);
    });

    // Copy Description
    overlay.querySelector('#fbCopyDescBtn').addEventListener('click', () => {
      const text = overlay.querySelector('#fbCurrentDescText').textContent;
      navigator.clipboard.writeText(text);
      overlay.querySelector('#fbCopyDescBtn').textContent = 'Copied! ✓';
      setTimeout(() => overlay.querySelector('#fbCopyDescBtn').textContent = 'Copy Description', 1500);
    });

    // Switch title
    overlay.querySelectorAll('.fb-ai-alt-btn[data-title]').forEach(btn => {
      btn.addEventListener('click', () => {
        const chosenTitle = btn.getAttribute('data-title');
        overlay.querySelector('#fbCurrentTitleText').textContent = chosenTitle;
        const titleInput = findTitleInput();
        if (titleInput) {
          setReactInputValue(titleInput, chosenTitle);
        }
        btn.textContent = 'Active ✓';
        setTimeout(() => btn.textContent = 'Use This', 1500);
      });
    });

    // Auto-fill button
    overlay.querySelector('#fbApplyAllBtn').addEventListener('click', () => {
      const title = overlay.querySelector('#fbCurrentTitleText').textContent;
      const desc = overlay.querySelector('#fbCurrentDescText').textContent;
      const filled = autoFillInputs(title, desc);
      if (filled) {
        overlay.querySelector('#fbApplyAllBtn').textContent = 'Applied! ✓';
      } else {
        overlay.querySelector('#fbApplyAllBtn').textContent = 'Saved for next step! ✓';
      }
      setTimeout(() => overlay.remove(), 800);
    });

    // Regenerate
    overlay.querySelector('#fbReAnalyzeBtn').addEventListener('click', () => {
      overlay.remove();
      startDeepVideoAnalysis();
    });

    document.body.appendChild(overlay);
    activeResultsModal = overlay;
  }

  function showToast(msg) {
    if (activeToast) activeToast.remove();
    const toast = document.createElement('div');
    toast.className = 'fb-ai-toast';
    toast.innerHTML = `<div class="fb-ai-toast-spinner"></div> <span>${escapeHtml(msg)}</span>`;
    document.body.appendChild(toast);
    activeToast = toast;
  }

  function hideToast() {
    if (activeToast) {
      activeToast.remove();
      activeToast = null;
    }
  }

  function escapeHtml(str) {
    if (!str) return '';
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

})();
