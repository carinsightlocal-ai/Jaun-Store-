// Popup logic for FB Video AI Extension

document.addEventListener('DOMContentLoaded', async () => {
  const apiKeyInput = document.getElementById('apiKey');
  const toggleKeyVisibilityBtn = document.getElementById('toggleKeyVisibility');
  const testKeyBtn = document.getElementById('testKeyBtn');
  const testResult = document.getElementById('testResult');
  const geminiModelSelect = document.getElementById('geminiModel');
  const languageSelect = document.getElementById('language');
  const toneSelect = document.getElementById('tone');
  const frameCountSelect = document.getElementById('frameCount');
  const includeHashtagsSelect = document.getElementById('includeHashtags');
  const saveBtn = document.getElementById('saveBtn');
  const saveNotification = document.getElementById('saveNotification');
  const statusBadge = document.getElementById('statusBadge');

  // New Pro API key from user
  const PRO_API_KEY = 'AQ.Ab8RN6ITtQPSjP9mMkKauhAMAvSPOEKBBdEW0HboC5or-j_THA';

  // Load existing settings
  const settings = await chrome.storage.local.get([
    'geminiApiKey',
    'geminiModel',
    'language',
    'tone',
    'frameCount',
    'includeHashtags'
  ]);

  // If key is empty or outdated, set the new PRO key
  if (!settings.geminiApiKey || settings.geminiApiKey.startsWith('AQ.Ab8RN6LqO')) {
    apiKeyInput.value = PRO_API_KEY;
    await chrome.storage.local.set({
      geminiApiKey: PRO_API_KEY,
      geminiModel: 'gemini-3.8-flash'
    });
    updateStatus(true);
  } else {
    apiKeyInput.value = settings.geminiApiKey;
    updateStatus(true);
  }

  if (settings.geminiModel && (settings.geminiModel.includes('3.8') || settings.geminiModel.includes('3.6') || settings.geminiModel.includes('flash-latest'))) {
    geminiModelSelect.value = settings.geminiModel;
  } else {
    geminiModelSelect.value = 'gemini-3.8-flash';
  }

  if (settings.language) languageSelect.value = settings.language;
  if (settings.tone) toneSelect.value = settings.tone;
  if (settings.frameCount) frameCountSelect.value = settings.frameCount;
  if (settings.includeHashtags !== undefined) includeHashtagsSelect.value = String(settings.includeHashtags);

  // Toggle API key visibility
  toggleKeyVisibilityBtn.addEventListener('click', () => {
    if (apiKeyInput.type === 'password') {
      apiKeyInput.type = 'text';
      toggleKeyVisibilityBtn.textContent = '🔒';
    } else {
      apiKeyInput.type = 'password';
      toggleKeyVisibilityBtn.textContent = '👁️';
    }
  });

  // Test Connection
  testKeyBtn.addEventListener('click', async () => {
    const key = apiKeyInput.value.trim();
    if (!key) {
      showTestMessage('Please enter an API key first.', false);
      return;
    }

    const spinner = testKeyBtn.querySelector('.spinner');
    const btnText = testKeyBtn.querySelector('.btn-text');
    spinner.classList.remove('hidden');
    btnText.textContent = 'Testing...';
    testKeyBtn.disabled = true;
    testResult.textContent = '';

    try {
      const response = await chrome.runtime.sendMessage({
        action: 'TEST_API_KEY',
        apiKey: key,
        model: geminiModelSelect.value
      });

      if (response && response.success) {
        showTestMessage('✓ ' + response.message, true);
        updateStatus(true);
      } else {
        const err = response ? response.error : 'Connection failed';
        showTestMessage(`Error: ${err}`, false);
        updateStatus(false);
      }
    } catch (e) {
      showTestMessage(`Test failed: ${e.message}`, false);
      updateStatus(false);
    } finally {
      spinner.classList.add('hidden');
      btnText.textContent = '⚡ Test Connection';
      testKeyBtn.disabled = false;
    }
  });

  // Save Settings
  saveBtn.addEventListener('click', async () => {
    const key = apiKeyInput.value.trim();
    const model = geminiModelSelect.value;
    const language = languageSelect.value;
    const tone = toneSelect.value;
    const frameCount = parseInt(frameCountSelect.value, 10) || 6;
    const includeHashtags = includeHashtagsSelect.value === 'true';

    await chrome.storage.local.set({
      geminiApiKey: key,
      geminiModel: model,
      language: language,
      tone: tone,
      frameCount: frameCount,
      includeHashtags: includeHashtags
    });

    updateStatus(Boolean(key));

    saveNotification.classList.remove('hidden');
    setTimeout(() => {
      saveNotification.classList.add('hidden');
    }, 2500);
  });

  function showTestMessage(msg, isSuccess) {
    testResult.textContent = msg;
    testResult.className = `status-msg ${isSuccess ? 'success' : 'error'}`;
  }

  function updateStatus(isReady) {
    if (isReady) {
      statusBadge.textContent = 'Pro Active';
      statusBadge.style.color = '#10b981';
      statusBadge.style.background = 'rgba(16, 185, 129, 0.15)';
      statusBadge.style.borderColor = 'rgba(16, 185, 129, 0.3)';
    } else {
      statusBadge.textContent = 'Key Needed';
      statusBadge.style.color = '#f59e0b';
      statusBadge.style.background = 'rgba(245, 158, 11, 0.15)';
      statusBadge.style.borderColor = 'rgba(245, 158, 11, 0.3)';
    }
  }
});
