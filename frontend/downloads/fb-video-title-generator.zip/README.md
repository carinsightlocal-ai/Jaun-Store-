# 🚀 Facebook Video AI Title & Description Generator (Chrome Extension)

Google Gemini AI se powered Chrome Extension jo Facebook video upload karte waqt video ko analyze karke automatically **viral titles** aur **engaging descriptions** generate karti hai aur direct Facebook ke Title aur Description fields me fill kar deti hai.

---

## 🌟 Key Features (Khususiyaat)

1. **Title Space per "✨ AI Generate" Button**:
   - Jaise hi aap Facebook ya Meta Business Suite me video upload shuru karte hain, video ke **Title** box ke sath **✨ AI Generate** ka stylish button appear ho jata hai.
   - Sath hi screen ke bottom-right per floating quick-action assistant bhi milta hai.
2. **Video Frame Analysis (Vision AI)**:
   - Video upload hone per extension video player se 3 se 5 high-quality frames (screenshots) capture karti hai.
   - Google Gemini AI (Vision) in frames ko deeply analyze karta hai (video kis cheez ke baray me hai, emotions, actions, key moments).
3. **Smart Auto-Fill**:
   - Ek click me sabse viral Title aur engaging Description (hashtags ke sath) Facebook ke input boxes me fill ho jata hai.
4. **Interactive Results Modal**:
   - 3 mukhtalif viral title options (Question hook, Curiosity hook, Emotional hook).
   - 1-Click "Use This Title" button.
   - 1-Click "Copy Title" & "Copy Description".
5. **Language & Tone Flexibility**:
   - Roman Urdu / Hinglish (e.g. *"Yeh video zaroor dekhein!"*)
   - Urdu Script (اردو)
   - English (Global viral style)
   - Hindi (हिन्दी)
   - Tones: Viral, Storytelling, Professional, Funny, Educational.

---

## 📦 How to Install in Chrome (Extension Install Karne Ka Tareeqa)

1. Apna Chrome Browser open karein.
2. Address bar me ye type karke Enter dabayein:
   ```text
   chrome://extensions/
   ```
3. Top-right corner me **Developer mode** toggle ko **ON** karein.
4. Top-left per **"Load unpacked"** button per click karein.
5. Is folder ko select karein:
   ```text
   C:\Users\Jaun Khan\Desktop\title geate
   ```
6. Extension install ho jayegi aur Chrome ke Extensions toolbar me show hogi!

---

## ⚙️ Configuration (API Key Setup)

1. Chrome ke top-right me **Extensions** icon (puzzle piece) per click karein aur **FB Video AI** extension ko pin kar lein.
2. Extension icon per click karein:
   - **Google Gemini API Key**: Agar aapke paas apni Gemini API key hai to paste karein (Free key lene ke liye popup me diye gaye link [aistudio.google.com](https://aistudio.google.com/app/apikey) per click karein).
   - **AI Model**: Default `Gemini 1.5 Flash` (Fast & Vision optimized) select rehne dein.
   - **Language**: Apni pasand ki language (Roman Urdu, Urdu, English) select karein.
   - **Tone**: Viral & High Retention select karein.
3. **⚡ Test Connection** per click karke verify karein.
4. **💾 Save Settings** dabayein.

---

## 🎬 How to Use (Istemal Kaise Karein)

1. [Facebook](https://www.facebook.com) ya [Meta Business Suite](https://business.facebook.com) open karein.
2. **"Photo / Video"** ya **"Create Post"** me ja kar apni video select karein.
3. Video preview aane ke baad, **Title** field ke sath **"✨ AI Generate"** button nazar aayega.
4. Button per click karein:
   - Extension video ke frames extract karegi.
   - Google Gemini AI video content analyze karega.
   - Kuch seconds me Title aur Description automatically post me fill ho jayenge!
   - Samne ek popup card open hoga jahan se aap alternative titles bhi select kar sakte hain.

---

## 🛠️ File Structure

- `manifest.json` - Chrome Extension Manifest V3 configuration
- `scripts/content.js` - Facebook DOM observer, video frame capture & input auto-fill
- `scripts/content.css` - UI styling for injected buttons, floating badge, and modal
- `scripts/background.js` - Service worker calling Google Gemini Multimodal Vision API
- `popup/popup.html` - Settings & API key interface
- `popup/popup.css` - Dark glassmorphic design system
- `popup/popup.js` - Configuration management & connection test
- `icons/` - Extension icons (16px, 48px, 128px)
