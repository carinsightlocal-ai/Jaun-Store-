const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

function createSolidPNG(width, height, r, g, b, a = 255) {
  // Simple uncompressed/deflated raw pixel buffer
  const rowBytes = 1 + width * 4;
  const rawBuffer = Buffer.alloc(rowBytes * height);

  for (let y = 0; y < height; y++) {
    const rowOffset = y * rowBytes;
    rawBuffer[rowOffset] = 0; // Filter type 0 (None)
    for (let x = 0; x < width; x++) {
      const pixelOffset = rowOffset + 1 + x * 4;
      // Let's create a nice gradient or circle badge
      const cx = width / 2;
      const cy = height / 2;
      const dist = Math.hypot(x - cx, y - cy);
      const radius = Math.min(width, height) * 0.45;

      if (dist <= radius) {
        // Deep purple to electric blue gradient with bright play symbol
        const factor = y / height;
        const pr = Math.round(108 * (1 - factor) + 37 * factor);
        const pg = Math.round(92 * (1 - factor) + 99 * factor);
        const pb = Math.round(231 * (1 - factor) + 235 * factor);

        // Simple play triangle in the center
        const isInPlay = (x >= cx - radius * 0.3) &&
                         (x <= cx + radius * 0.4) &&
                         (Math.abs(y - cy) <= (x - (cx - radius * 0.3)) * 0.7);

        if (isInPlay) {
          rawBuffer[pixelOffset] = 255;
          rawBuffer[pixelOffset + 1] = 255;
          rawBuffer[pixelOffset + 2] = 255;
          rawBuffer[pixelOffset + 3] = 255;
        } else {
          rawBuffer[pixelOffset] = pr;
          rawBuffer[pixelOffset + 1] = pg;
          rawBuffer[pixelOffset + 2] = pb;
          rawBuffer[pixelOffset + 3] = 255;
        }
      } else {
        rawBuffer[pixelOffset] = 0;
        rawBuffer[pixelOffset + 1] = 0;
        rawBuffer[pixelOffset + 2] = 0;
        rawBuffer[pixelOffset + 3] = 0;
      }
    }
  }

  const compressedData = zlib.deflateSync(rawBuffer);

  // Build PNG chunks
  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  // IHDR chunk
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr.writeUInt8(8, 8); // bit depth
  ihdr.writeUInt8(6, 9); // color type RGBA
  ihdr.writeUInt8(0, 10); // compression
  ihdr.writeUInt8(0, 11); // filter
  ihdr.writeUInt8(0, 12); // interlace

  const ihdrChunk = createChunk('IHDR', ihdr);
  const idatChunk = createChunk('IDAT', compressedData);
  const iendChunk = createChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdrChunk, idatChunk, iendChunk]);
}

function crc32(buf) {
  let table = [];
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) {
      if (c & 1) c = 0xedb88320 ^ (c >>> 1);
      else c = c >>> 1;
    }
    table[n] = c;
  }
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    c = table[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  }
  return (c ^ 0xffffffff) >>> 0;
}

function createChunk(type, data) {
  const typeBuf = Buffer.from(type, 'ascii');
  const lenBuf = Buffer.alloc(4);
  lenBuf.writeUInt32BE(data.length, 0);

  const crcBuf = Buffer.alloc(4);
  const toCrc = Buffer.concat([typeBuf, data]);
  crcBuf.writeUInt32BE(crc32(toCrc), 0);

  return Buffer.concat([lenBuf, typeBuf, data, crcBuf]);
}

const iconsDir = path.join(__dirname, 'icons');
if (!fs.existsSync(iconsDir)) {
  fs.mkdirSync(iconsDir, { recursive: true });
}

[16, 48, 128].forEach(size => {
  const png = createSolidPNG(size, size, 108, 92, 231);
  fs.writeFileSync(path.join(iconsDir, `icon${size}.png`), png);
  console.log(`Generated icon${size}.png`);
});
