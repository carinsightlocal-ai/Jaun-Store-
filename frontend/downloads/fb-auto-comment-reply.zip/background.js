// Background Service Worker for FB Auto Comment Replier
chrome.runtime.onInstalled.addListener(() => {
  console.log('[FB Replier VIP] Extension Installed');
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(err => {
    console.error('Failed to set panel behavior:', err);
  });
});

chrome.action.onClicked.addListener(async (tab) => {
  if (tab.id) {
    try {
      await chrome.sidePanel.open({ tabId: tab.id });
    } catch (err) {
      console.warn('Could not open side panel for tab:', err);
    }
  }
});

// Relay messages if needed between sidepanel and active tabs
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'GET_ACTIVE_TAB') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      sendResponse({ tab: tabs && tabs[0] ? tabs[0] : null });
    });
    return true;
  }
});
