# 🚀 FB Auto Comment Replier - VIP Edition (Chrome Extension)

Ye extension Facebook Groups aur Posts ke tamam comments par automatically aapka set kiya hua reply message har user ko bari bari bhejti hai.

---

## 🌟 Key Features

1. **Auto Reply to All Comments**:
   - Facebook Group ya Profile/Page post ke tamam comments par automatic reply karega.
2. **Personalized Dynamic Tags**:
   - `{name}`: Comment karne wale ka poora naam automatically insert karega (e.g. "Ali Khan").
   - `{first_name}`: Pehla naam insert karega (e.g. "Ali").
   - `{random_emoji}`: Alag alag natural emoji lagayega (👍, ✨, 📥, 🙏, 🔥).
3. **Spintax Support**:
   - `{Hi|Hello|Hey} {name}, check your inbox!` likhein ge to bot har user ko thora mukhtalif text bhejay ga taake Facebook spam checkpoint trigger na ho!
4. **Interactive Post Selector**:
   - Side panel me "🎯 Select Post on Page" button dabayein aur page par kisi bhi post par click karein—post instantly lock ho jayegi.
   - Ya "⚡ Auto-Detect" dabayein.
5. **Auto-Expand Hidden Comments**:
   - "View more comments" / "View previous comments" ko auto-click karke pehle se chhupe hue comments ko load karega.
6. **Smart Anti-Ban Safe Delays**:
   - Har reply ke darmiyan customizable random delay (default: 8 to 14 seconds) taake account safe rahe.
7. **No Duplicate Replies**:
   - Jis comment par pehle reply ho chuka hoga use automatically skip karega aur comment par `✅ Replied` badge display karega.
8. **Side Panel VIP UI**:
   - Chrome Side Panel me chalti hai—Facebook scroll karte waqt band nahi hoti!

---

## 🛠️ Chrome Me Install Karne Ka Tarika (Step-by-Step)

1. **Google Chrome** open karein.
2. Address bar me `chrome://extensions` likhein aur **Enter** press karein.
3. Top right corner par **"Developer mode"** toggle ko **ON** karein.
4. Top left par **"Load unpacked"** button par click karein.
5. Ye folder select karein:
   ```
   C:\Users\Jaun Khan\.gemini\antigravity-ide\scratch\fb-auto-comment-reply
   ```
6. Extension successfully Chrome me install ho jayegi! 🎉
7. Chrome toolbar ke **Puzzle icon (Extensions)** par click karke **"FB Auto Comment Replier - VIP Edition"** ko **Pin** kar lein.

---

## 📖 Kaise Use Karein (Usage Guide)

1. **Facebook.com** open karein aur kisi bhi Group ya Post par jayein.
2. Chrome toolbar me extension icon par click karein—right side par **VIP Side Panel** open ho jayega.
3. **Step 1: Select Post**:
   - **"🎯 Select Post on Page"** par click karein.
   - Mouse ko Facebook group ki post par le jayein (cyan border aayega) aur click karein.
   - Ya agar post khuli hui hai to **"⚡ Auto-Detect"** par click karein.
4. **Step 2: Message Likhain**:
   - Box me apna reply message likhein.
   - Maslan:
     ```text
     Hello {name}, thanks for commenting! Please check your inbox 📥
     ```
   - Ya Spintax use karein:
     ```text
     {Hi|Hello|Hey} {first_name}, check your DM for details! {random_emoji}
     ```
5. **Step 3: Safe Delays & Settings**:
   - Default: Min Delay `8s`, Max Delay `14s` (Safe anti-ban).
   - "Max Replies Limit" set karein (e.g. 50 ya jitne comments hon).
6. **Step 4: START**:
   - **"🚀 START AUTO REPLY"** button par click karein.
   - Bot automatically har comment ko find karega, Reply button click karega, message type karega aur enter press karega!
   - Agar kisi waqt rokna ho to **"🛑 STOP BOT"** button daba dein.

---

## 📁 File Structure

- `manifest.json`: Manifest V3 extension configuration
- `background.js`: Background worker for side panel management
- `sidepanel.html`: Modern Glassmorphism control center UI
- `sidepanel.css`: High-end dark theme & micro-animations
- `sidepanel.js`: Communication bridge and statistics manager
- `content.js`: Facebook DOM automation, Lexical input injector & throttle engine
- `generate_icons.js`: Generates high-res extension icons
- `icons/`: Extension icon assets (16x16, 48x48, 128x128)
