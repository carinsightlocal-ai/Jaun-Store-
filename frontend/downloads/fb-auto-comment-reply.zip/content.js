// Content Script for FB Auto Comment Replier VIP
(() => {
  if (window.__fbReplierInjected) return;
  window.__fbReplierInjected = true;

  console.log('%c[FB Replier VIP] Content Script Loaded', 'color: #00f2fe; font-weight: bold;');

  let activeTargetPost = null;
  let isSelectingPost = false;
  let isRunning = false;
  let shouldStop = false;
  let hoveredElement = null;

  // Track replied comment identifiers in session
  const repliedCommentIds = new Set();
  const savedRepliedUsers = new Set();

  function loadRepliedUsers() {
    chrome.storage.local.get(['repliedUsersList'], (res) => {
      if (Array.isArray(res.repliedUsersList)) {
        res.repliedUsersList.forEach(u => {
          if (typeof u === 'string') savedRepliedUsers.add(u.toLowerCase().trim());
        });
      }
    });
  }
  loadRepliedUsers();

  function normalizeProfileKey(url) {
    if (!url) return '';
    try {
      const u = new URL(url, window.location.origin);
      const id = u.searchParams.get('id');
      if (id) return `id_${id}`;
      const path = u.pathname.replace(/^\/+|\/+$/g, '');
      const segments = path.split('/').filter(s => s && !['profile.php', 'groups', 'user', 'people'].includes(s.toLowerCase()));
      if (segments.length > 0) return `user_${segments[0].toLowerCase()}`;
      return path.toLowerCase();
    } catch (e) {
      return (url || '').toLowerCase().replace(/[^a-z0-9]/g, '');
    }
  }

  function isUserInPermanentMemory(authorName, profileUrl) {
    const cleanName = (authorName || '').trim().toLowerCase();
    if (cleanName && savedRepliedUsers.has(cleanName)) return true;
    if (profileUrl) {
      const pKey = normalizeProfileKey(profileUrl);
      if (pKey && savedRepliedUsers.has(pKey)) return true;
    }
    return false;
  }

  function saveUserToPermanentMemory(authorName, profileUrl) {
    let changed = false;
    const cleanName = (authorName || '').trim().toLowerCase();
    if (cleanName && !cleanName.startsWith('user #')) {
      savedRepliedUsers.add(cleanName);
      changed = true;
    }
    if (profileUrl) {
      const pKey = normalizeProfileKey(profileUrl);
      if (pKey) {
        savedRepliedUsers.add(pKey);
        changed = true;
      }
    }
    if (changed) {
      chrome.storage.local.set({ repliedUsersList: Array.from(savedRepliedUsers) });
      notifySidepanel('HISTORY_UPDATED', { count: savedRepliedUsers.size });
    }
  }

  // Highlight style element
  const styleEl = document.createElement('style');
  styleEl.textContent = `
    .fb-replier-hover-target {
      outline: 3px solid #00f2fe !important;
      outline-offset: 4px !important;
      box-shadow: 0 0 20px rgba(0, 242, 254, 0.4) !important;
      cursor: crosshair !important;
      transition: outline 0.15s ease !important;
    }
    .fb-replier-locked-post {
      outline: 2px solid #10b981 !important;
      outline-offset: 2px !important;
    }
    .fb-replier-badge {
      display: inline-flex;
      align-items: center;
      gap: 4px;
      padding: 2px 8px;
      background: rgba(16, 185, 129, 0.18);
      border: 1px solid #10b981;
      border-radius: 999px;
      color: #10b981;
      font-size: 11px;
      font-weight: 600;
      margin-left: 6px;
      vertical-align: middle;
      z-index: 9999;
    }
  `;
  document.head.appendChild(styleEl);

  // Sleep utility
  const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

  // --- Message Listener ---
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    switch (request.action) {
      case 'PING':
        sendResponse({ status: 'OK', hasTargetPost: !!activeTargetPost });
        break;

      case 'START_POST_PICKER':
        startPostPicker();
        sendResponse({ status: 'PICKER_STARTED' });
        break;

      case 'AUTO_DETECT_POST':
        const detected = autoDetectPost();
        sendResponse(detected);
        break;

      case 'DETECT_PROFILE':
        const prof = detectActiveProfileName();
        sendResponse({ profileName: prof });
        break;

      case 'CLEAR_REPLIED_HISTORY':
        savedRepliedUsers.clear();
        chrome.storage.local.set({ repliedUsersList: [] });
        sendResponse({ success: true, count: 0 });
        break;

      case 'GET_REPLIED_HISTORY_COUNT':
        sendResponse({ count: savedRepliedUsers.size });
        break;

      case 'AUTO_FETCH_COMMENTS':
        (async () => {
          if (!activeTargetPost || findReplyButtons(activeTargetPost).length === 0) {
            autoDetectPost();
          }
          if (!activeTargetPost) {
            sendResponse({ success: false, error: 'No active post detected' });
            return;
          }
          notifySidepanel('LOG', { text: '📥 Starting Deep Auto-Fetch of all comments on this post...', type: 'info' });
          await autoExpandMoreComments(activeTargetPost, true);
          const comments = findCommentsInPost(activeTargetPost, request.scope || 'top_level');
          notifySidepanel('LOG', { text: `🎉 Fully fetched ${comments.length} comments! Updating scan...`, type: 'success' });
          sendResponse({ success: true, count: comments.length });
        })();
        return true;

      case 'SCAN_COMMENTS':
        loadRepliedUsers();
        if (!activeTargetPost || findReplyButtons(activeTargetPost).length === 0) {
          autoDetectPost();
        }
        const allComments = findCommentsInPost(activeTargetPost, request.scope || 'top_level');
        const profName = request.profileName || '';
        const filtMode = request.filterMode || 'unreplied_by_profile';
        const skipOwn = request.skipOwnComments !== false;
        const oneReply = request.oneReplyPerUser !== false;
        const actMode = request.actionMode || 'inbox_only';
        const skipInbox = request.skipIfInboxMessaged !== false;

        const targetComments = [];
        let skippedByFilter = 0;

        for (const c of allComments) {
          const check = checkIfCommentRepliedByProfile(
            c.commentEl,
            c.author,
            c.authorUrl,
            profName,
            filtMode,
            skipOwn,
            oneReply,
            skipInbox,
            actMode
          );
          if (check.replied) {
            skippedByFilter++;
          } else {
            targetComments.push(c);
          }
        }

        sendResponse({
          count: targetComments.length,
          totalFound: allComments.length,
          targetCount: targetComments.length,
          skippedCount: skippedByFilter,
          historyCount: savedRepliedUsers.size,
          details: targetComments.map(c => ({ author: c.author, snippet: c.snippet }))
        });
        break;

      case 'START_REPLY_BOT':
        if (isRunning) {
          sendResponse({ error: 'Bot is already running.' });
          return;
        }
        startReplyBot(request.config);
        sendResponse({ status: 'STARTED' });
        break;

      case 'STOP_REPLY_BOT':
        shouldStop = true;
        sendResponse({ status: 'STOPPING' });
        break;

      default:
        break;
    }
    return true;
  });

  // --- Post Picker Mode ---
  function startPostPicker() {
    if (isSelectingPost) return;
    isSelectingPost = true;

    notifySidepanel('LOG', { text: '🎯 Please click on the target Facebook post in your group.', type: 'info' });

    const onMouseOver = (e) => {
      if (!isSelectingPost) return;
      const post = findParentPost(e.target);
      if (post && post !== hoveredElement) {
        if (hoveredElement) hoveredElement.classList.remove('fb-replier-hover-target');
        hoveredElement = post;
        hoveredElement.classList.add('fb-replier-hover-target');
      }
    };

    const onMouseOut = (e) => {
      if (!isSelectingPost) return;
      if (hoveredElement && !hoveredElement.contains(e.relatedTarget)) {
        hoveredElement.classList.remove('fb-replier-hover-target');
        hoveredElement = null;
      }
    };

    const onClick = (e) => {
      if (!isSelectingPost) return;
      e.preventDefault();
      e.stopPropagation();

      const post = findParentPost(e.target);
      cleanupPicker();

      if (post) {
        setTargetPost(post);
      } else {
        notifySidepanel('LOG', { text: '⚠️ Could not lock post. Please try selecting again.', type: 'warning' });
      }
    };

    function cleanupPicker() {
      isSelectingPost = false;
      if (hoveredElement) {
        hoveredElement.classList.remove('fb-replier-hover-target');
        hoveredElement = null;
      }
      document.removeEventListener('mouseover', onMouseOver, true);
      document.removeEventListener('mouseout', onMouseOut, true);
      document.removeEventListener('click', onClick, true);
    }

    document.addEventListener('mouseover', onMouseOver, true);
    document.addEventListener('mouseout', onMouseOut, true);
    document.addEventListener('click', onClick, true);
  }

  function resolvePostAndCommentRoot(targetPost) {
    let el = targetPost || activeTargetPost;

    // 1. If currently inside a modal dialog (photo viewer or permalink popup)
    const dialog = (el && el.closest && el.closest('div[role="dialog"]')) || document.querySelector('div[role="dialog"]');
    if (dialog && (findReplyButtons(dialog).length > 0 || dialog.querySelectorAll('div[role="article"]').length > 0)) {
      return dialog;
    }

    // 2. If viewing a photo/video lightbox or permalink page
    const currentUrl = window.location.href;
    const isPhotoOrVideo = currentUrl.includes('/photo/') || currentUrl.includes('/photo.php') || currentUrl.includes('/videos/') || currentUrl.includes('fbid=');
    if (isPhotoOrVideo) {
      // In Facebook photo viewer, comments are in the feedback rail
      const feedbackPane = document.querySelector('div[data-pagelet*="MediaViewerFeedback"], div[data-pagelet*="Feedback"], div[role="complementary"]');
      if (feedbackPane && findReplyButtons(feedbackPane).length > 0) {
        return feedbackPane;
      }
      return document.body;
    }

    const isPermalink = currentUrl.includes('/posts/') || currentUrl.includes('/permalink/') || currentUrl.includes('permalink.php');
    if (isPermalink) {
      const main = document.querySelector('div[role="main"]');
      if (main && (findReplyButtons(main).length > 0 || main.querySelectorAll('div[role="article"]').length > 0)) {
        return main;
      }
      return document.body;
    }

    // 3. If element is provided, ensure it actually encloses comments
    if (el && el !== document.body) {
      if (findReplyButtons(el).length > 0 || el.querySelectorAll('div[role="article"]').length > 0) {
        return el;
      }

      // Ascend to FeedUnit or parent container that has comments
      const feedUnit = el.closest('div[data-pagelet*="FeedUnit"]') || el.closest('div[role="feed"] > div');
      if (feedUnit && (findReplyButtons(feedUnit).length > 0 || feedUnit.querySelectorAll('div[role="article"]').length > 0)) {
        return feedUnit;
      }

      // Check parent element
      if (el.parentElement && el.parentElement !== document.body) {
        if (findReplyButtons(el.parentElement).length > 0 || el.parentElement.querySelectorAll('div[role="article"]').length > 0) {
          return el.parentElement;
        }
      }
    }

    // 4. Fallback: check main content, or document.body
    const fallbackMain = document.querySelector('div[role="main"]');
    if (fallbackMain && (findReplyButtons(fallbackMain).length > 0 || fallbackMain.querySelectorAll('div[role="article"]').length > 0)) {
      return fallbackMain;
    }

    return document.body;
  }

  function findParentPost(el) {
    if (!el || el === document.body || el === document.documentElement) return null;

    // 1. Check if within modal dialog
    const modalDialog = el.closest('div[role="dialog"]');
    if (modalDialog) {
      return modalDialog;
    }

    // 2. Ascend to find the true post container (FeedUnit or parent container that includes comments)
    let current = el;
    let postCandidate = null;

    while (current && current !== document.body) {
      if (
        current.getAttribute('data-pagelet')?.includes('FeedUnit') ||
        current.classList.contains('userContentWrapper')
      ) {
        return current;
      }
      if (current.getAttribute('role') === 'article' && !postCandidate) {
        postCandidate = current;
      }
      current = current.parentElement;
    }

    if (postCandidate) {
      const hasComments = findReplyButtons(postCandidate).length > 0 || postCandidate.querySelectorAll('div[role="article"]').length > 1;
      if (!hasComments && postCandidate.parentElement && postCandidate.parentElement !== document.body) {
        const parentUnit = postCandidate.parentElement.closest('div[data-pagelet*="FeedUnit"]') || postCandidate.parentElement;
        return parentUnit;
      }
      return postCandidate;
    }

    const mainContainer = el.closest('div[role="main"]');
    if (mainContainer && findReplyButtons(mainContainer).length > 0) return mainContainer;

    return document.body;
  }

  function autoDetectPost() {
    const currentUrl = window.location.href;
    const isPhotoOrVideo = currentUrl.includes('/photo/') || currentUrl.includes('/photo.php') || currentUrl.includes('/videos/') || currentUrl.includes('fbid=');
    const isPermalinkPage = isPhotoOrVideo || currentUrl.includes('/posts/') || currentUrl.includes('/permalink/') || currentUrl.includes('permalink.php');

    // 1. Check if user is viewing a post modal dialog
    const modal = document.querySelector('div[role="dialog"]');
    if (modal && (findReplyButtons(modal).length > 0 || modal.querySelectorAll('div[role="article"]').length > 0)) {
      setTargetPost(modal);
      return { success: true, method: 'dialog' };
    }

    // 2. Photo Lightbox / Media Viewer page
    if (isPhotoOrVideo) {
      const feedbackPane = document.querySelector('div[data-pagelet*="MediaViewerFeedback"], div[data-pagelet*="Feedback"], div[role="complementary"]');
      if (feedbackPane && findReplyButtons(feedbackPane).length > 0) {
        setTargetPost(feedbackPane);
        return { success: true, method: 'photo_feedback_pane' };
      }
      if (findReplyButtons(document).length > 0) {
        setTargetPost(document.body);
        return { success: true, method: 'photo_page_body' };
      }
    }

    // 3. Direct permalink post page
    if (isPermalinkPage) {
      const mainPost = document.querySelector('div[role="main"] div[role="article"], div[role="feed"] div[role="article"], div[data-pagelet*="FeedUnit"]');
      if (mainPost && (findReplyButtons(mainPost).length > 0 || mainPost.querySelectorAll('div[role="article"]').length > 0)) {
        setTargetPost(mainPost);
        return { success: true, method: 'permalink_page' };
      }
    }

    // 4. Find post visible in current viewport with comments
    const posts = Array.from(document.querySelectorAll('div[role="article"], [data-pagelet*="FeedUnit"]'));
    const viewportHeight = window.innerHeight;
    for (const p of posts) {
      const rect = p.getBoundingClientRect();
      if (rect.top >= 0 && rect.top <= viewportHeight * 0.75) {
        if (findReplyButtons(p).length > 0) {
          setTargetPost(p);
          return { success: true, method: 'viewport' };
        }
      }
    }

    // 5. If any post exists on page
    if (posts.length > 0) {
      setTargetPost(posts[0]);
      return { success: true, method: 'first' };
    }

    // 6. Universal fallback: if document has reply buttons
    if (findReplyButtons(document).length > 0) {
      setTargetPost(document.body);
      return { success: true, method: 'document_body' };
    }

    return { success: false, error: 'No active Facebook post detected on this page.' };
  }

  function setTargetPost(postEl) {
    if (activeTargetPost && activeTargetPost !== document.body) {
      activeTargetPost.classList.remove('fb-replier-locked-post');
    }
    activeTargetPost = postEl;
    if (activeTargetPost !== document.body) {
      activeTargetPost.classList.add('fb-replier-locked-post');
    }

    // Extract details
    let author = 'Facebook Post';
    let snippet = 'Post content...';

    if (postEl === document.body) {
      author = 'Facebook Photo Post';
      const heading = document.querySelector('h1, h2, [data-pagelet*="Feedback"] strong, [data-pagelet*="MediaViewer"] strong');
      if (heading && heading.textContent) author = heading.textContent.trim().slice(0, 35);
      const msgPreview = document.querySelector('[data-ad-preview="message"], [data-pagelet*="Feedback"] [dir="auto"]');
      if (msgPreview && msgPreview.textContent) snippet = msgPreview.textContent.slice(0, 70).trim();
    } else {
      const authorEl = postEl.querySelector('h2, h3, h4, strong, a[role="link"] span');
      if (authorEl) author = authorEl.textContent.trim();
      const snippetEl = postEl.querySelector('[data-ad-preview="message"], [dir="auto"]');
      if (snippetEl) snippet = snippetEl.textContent.slice(0, 70).trim();
    }

    const comments = findCommentsInPost(postEl, 'top_level');

    notifySidepanel('POST_SELECTED', {
      author,
      snippet,
      commentCount: comments.length
    });

    notifySidepanel('LOG', { text: `🎯 Target Post locked: "${author}" (${comments.length} comments visible)`, type: 'success' });
  }

  // --- Comment Finder & Parser ---
  function findCommentsInPost(container, scope = 'top_level') {
    let root = resolvePostAndCommentRoot(container);
    if (!root) root = document.body;

    const commentsList = [];
    const seenElements = new Set();
    const seenAuthorsAndText = new Set();

    // Strategy 1: Find all Reply buttons inside root (or document fallback)
    let replyButtons = findReplyButtons(root);
    if (replyButtons.length === 0 && root !== document.body) {
      replyButtons = findReplyButtons(document.body);
      if (replyButtons.length > 0) root = document.body;
    }

    // Strategy 2: Also find all "Send message" buttons
    const sendMsgButtons = findSendMessageButtons(root);

    // Collect candidate action anchors
    const anchorButtons = [...replyButtons];
    for (const smb of sendMsgButtons) {
      if (!anchorButtons.includes(smb)) anchorButtons.push(smb);
    }

    // Also collect standard div[role="article"] if present
    const articleElements = Array.from(root.querySelectorAll('div[role="article"]')).filter(a => a !== root);

    // Build candidate comment containers
    const candidateContainers = [];

    // From anchor buttons
    for (const btn of anchorButtons) {
      const commentEl = getCommentElementFromButton(btn);
      if (commentEl && !candidateContainers.includes(commentEl) && commentEl !== root) {
        candidateContainers.push(commentEl);
      }
    }

    // From article elements
    for (const art of articleElements) {
      if (!candidateContainers.includes(art)) {
        candidateContainers.push(art);
      }
    }

    for (let i = 0; i < candidateContainers.length; i++) {
      const commentEl = candidateContainers[i];
      if (!commentEl || seenElements.has(commentEl)) continue;
      seenElements.add(commentEl);

      // Extract author name & profile link
      const authorInfo = extractCommentAuthor(commentEl);
      const author = authorInfo.name || `User #${commentsList.length + 1}`;
      const authorUrl = authorInfo.url || '';

      // Extract snippet
      const snippet = extractCommentSnippet(commentEl);

      // Avoid exact duplicates
      const dedupeKey = `${author.toLowerCase()}_${snippet.slice(0, 30).toLowerCase()}`;
      if (seenAuthorsAndText.has(dedupeKey)) continue;
      seenAuthorsAndText.add(dedupeKey);

      // Check if top level vs nested reply
      const isNested = isNestedComment(commentEl, root);
      if (scope === 'top_level' && isNested) {
        continue;
      }

      // Find action buttons & inbox status
      const replyBtn = findReplyButtons(commentEl)[0] || null;
      const messageBtn = findSendMessageButton(commentEl);
      const hasInbox = checkCommentHasInboxMessage(commentEl);

      const commentId = `${author}_${snippet.slice(0, 25)}`;

      commentsList.push({
        id: commentId,
        author,
        authorUrl,
        snippet,
        commentEl,
        replyBtn,
        messageBtn,
        hasInbox,
        isNested
      });
    }

    return commentsList;
  }

  function getCommentElementFromButton(btn) {
    if (!btn) return null;

    // First check if already inside a role="article"
    const standardArticle = btn.closest('div[role="article"]');
    if (standardArticle && standardArticle !== document.body && standardArticle.getAttribute('role') !== 'main') {
      if (findReplyButtons(standardArticle).length <= 2) {
        return standardArticle;
      }
    }

    // Ascend hierarchy looking for the comment container
    let curr = btn.parentElement;
    let best = null;

    for (let depth = 0; depth < 10 && curr && curr !== document.body; depth++) {
      if (curr.getAttribute('role') === 'main' || curr.getAttribute('role') === 'dialog') {
        break;
      }

      const repliesInside = findReplyButtons(curr);
      const hasAuthor = !!curr.querySelector('a[role="link"], a[href*="facebook.com"], a[href*="user"], strong, span[dir="auto"]');

      if (repliesInside.length <= 1 && hasAuthor) {
        best = curr;
      } else if (repliesInside.length > 2) {
        // Stop before entering the parent list of multiple comments
        break;
      }

      curr = curr.parentElement;
    }

    return best || btn.closest('div[role="article"]') || btn.parentElement?.parentElement || btn.parentElement;
  }

  function extractCommentAuthor(commentEl) {
    if (!commentEl) return { name: '', url: '' };

    const links = Array.from(commentEl.querySelectorAll('a[role="link"], a[href]'));
    for (const a of links) {
      const href = a.getAttribute('href') || '';
      const text = (a.textContent || '').trim();
      if (!text || /^(like|reply|send message|share|follow|\d+[hdwmy]|just now)$/i.test(text)) continue;
      if (href.includes('user/') || href.includes('profile.php') || href.includes('/groups/') || (href.startsWith('/') && !href.includes('/photo') && !href.includes('/posts/'))) {
        return { name: text, url: href };
      }
      if (text.length >= 2 && text.length <= 40 && !text.includes('\n')) {
        return { name: text, url: href };
      }
    }

    const strong = commentEl.querySelector('strong span, span strong, strong');
    if (strong && strong.textContent) {
      const text = strong.textContent.trim();
      if (text && !/^(like|reply|share)$/i.test(text)) {
        return { name: text, url: '' };
      }
    }

    return { name: '', url: '' };
  }

  function extractCommentSnippet(commentEl) {
    if (!commentEl) return '';
    const textEls = Array.from(commentEl.querySelectorAll('div[dir="auto"], span[dir="auto"]'));
    for (const el of textEls) {
      const txt = (el.textContent || '').trim();
      if (!txt || /^(like|reply|send message|share|follow|\d+[hdwmy]|view\s*\d*\s*repl)/i.test(txt)) continue;
      if (el.querySelector('[role="button"]')) continue;
      return txt.slice(0, 70);
    }
    return '';
  }

  function findReplyButtons(root) {
    if (!root) return [];
    // CRITICAL: On Facebook photo pages, Reply/Send message are plain <span> or <a> elements
    // without role="button". We must search ALL spans, links, and button-role elements.
    const candidates = Array.from(root.querySelectorAll('div[role="button"], span[role="button"], button, a[role="button"], span, a, [role="link"]'));
    const replyWords = /^(reply|jawab|répondre|responder|balas|antworten|rispondi|رد)$/i;

    const matched = [];
    const seen = new Set();

    for (const el of candidates) {
      const text = (el.textContent || '').trim();
      const aria = (el.getAttribute('aria-label') || '').trim();

      // Skip elements with too much text (these are containers, not buttons)
      if (text.length > 30) continue;

      // Exclude expanders
      const isExpand = /view\s*\d*\s*(more|previous|next|all)?\s*repl|hide\s*repl|view\s*all|\b\d+\s*repl(y|ies)\b|view\s*more|view\s*\d+\s*more/i.test(text) ||
                       /view\s*\d*\s*repl|hide\s*repl/i.test(aria);
      if (isExpand) continue;

      const isReply = replyWords.test(text) ||
                      /^(reply to|replying to)/i.test(aria) ||
                      (replyWords.test(aria) && text.length < 15);

      if (isReply) {
        // Use the element itself (it IS the clickable target)
        const btn = el.closest('[role="button"]') || el;
        if (!seen.has(btn)) {
          seen.add(btn);
          matched.push(btn);
        }
      }
    }
    return matched;
  }

  function findSendMessageButtons(root) {
    if (!root) return [];
    // Search ALL spans, links, and button elements (photo page uses plain spans)
    const candidates = Array.from(root.querySelectorAll('div[role="button"], span[role="button"], button, a[role="button"], span, a, [role="link"], a[href*="/messages/"]'));
    const msgWords = /^(send\s*message|message|send\s*private\s*reply|reply\s*privately|private\s*reply|میسج\s*کریں|پیغام\s*بھیجیں|نجی\s*پیغام|संदेश\s*भेजें|enviar\s*mensaje)$/i;

    const matched = [];
    const seen = new Set();

    for (const el of candidates) {
      const text = (el.textContent || '').trim();
      const aria = (el.getAttribute('aria-label') || '').trim();

      // Skip elements with too much text
      if (text.length > 30) continue;

      if (/sent|replied|bheja|diya|view\s*message/i.test(text) || /sent|replied|bheja|diya|view\s*message/i.test(aria)) {
        continue;
      }

      if (msgWords.test(text) || msgWords.test(aria) || (/\b(send\s*message|میسج\s*کریں)\b/i.test(text) && text.length < 25)) {
        const btn = el.closest('[role="button"]') || el;
        if (!seen.has(btn)) {
          seen.add(btn);
          matched.push(btn);
        }
      }
    }
    return matched;
  }

  // Find "Send message" / "Message" / "میسج کریں" button under a comment
  function findSendMessageButton(commentEl) {
    if (!commentEl) return null;
    const buttons = findSendMessageButtons(commentEl);
    return buttons[0] || null;
  }

  // Detect if comment already has an inbox message
  function checkCommentHasInboxMessage(commentEl) {
    if (!commentEl) return false;
    const text = (commentEl.textContent || '').toLowerCase();
    const inboxPatterns = [
      'replied privately',
      'page replied privately',
      'you replied privately',
      'message sent',
      'sent a message',
      'view message in inbox',
      'view message',
      'پرائیویٹ جواب دیا گیا',
      'پیغام بھیج دیا گیا',
      'میسج بھیج دیا گیا',
      'نجی پیغام بھیجا گیا',
      'نجی جواب دیا گیا'
    ];

    for (const pat of inboxPatterns) {
      if (text.includes(pat)) return true;
    }

    const labeledElements = commentEl.querySelectorAll('[aria-label]');
    for (const el of labeledElements) {
      const lbl = (el.getAttribute('aria-label') || '').toLowerCase();
      for (const pat of inboxPatterns) {
        if (lbl.includes(pat)) return true;
      }
    }

    return false;
  }

  function isNestedComment(commentEl, root) {
    const parentComment = commentEl.parentElement?.closest('div[role="article"]');
    if (parentComment && parentComment !== root && root.contains(parentComment)) {
      return true;
    }
    const style = window.getComputedStyle(commentEl);
    if (parseInt(style.marginLeft || '0', 10) > 25 || parseInt(style.paddingLeft || '0', 10) > 25) {
      return true;
    }
    return false;
  }

  // --- Profile Detector ---
  function detectActiveProfileName() {
    const commentAsSelectors = [
      '[aria-label*="Commenting as" i]',
      '[aria-label*="Interacting as" i]',
      'div[role="combobox"] [aria-label*="as " i]',
      'div[role="textbox"] [aria-label*="as " i]'
    ];
    for (const sel of commentAsSelectors) {
      const el = document.querySelector(sel);
      if (el) {
        const label = el.getAttribute('aria-label') || '';
        const match = label.match(/(?:commenting|interacting)\s+as\s+([^,.]+)/i);
        if (match && match[1]) return match[1].trim();
      }
    }

    const topProfile = document.querySelector('[role="navigation"] [aria-label*="Your profile" i], [aria-label="Your Profile" i], [aria-label*="Account Controls" i]');
    if (topProfile) {
      const img = topProfile.querySelector('img[alt]');
      if (img && img.alt && !img.alt.toLowerCase().includes('profile') && !img.alt.toLowerCase().includes('picture')) {
        return img.alt.trim();
      }
      const label = topProfile.getAttribute('aria-label') || '';
      const match = label.match(/your profile,\s*(.+)/i) || label.match(/profile:\s*(.+)/i);
      if (match && match[1]) return match[1].trim();
    }

    const leftLink = document.querySelector('[data-pagelet="LeftRail"] a[href*="/user/"] span, [role="navigation"] a[href^="/me"] span');
    if (leftLink && leftLink.textContent) {
      return leftLink.textContent.trim();
    }

    const avatars = Array.from(document.querySelectorAll('div[role="banner"] img[alt], [role="navigation"] img[alt]'));
    for (const img of avatars) {
      const alt = (img.alt || '').trim();
      if (alt && !['facebook', 'profile picture', 'story', 'menu', 'notifications', 'messenger'].some(x => alt.toLowerCase().includes(x))) {
        return alt;
      }
    }

    return '';
  }

  // --- Check if comment is already replied / messaged ---
  function checkIfCommentRepliedByProfile(
    commentEl,
    authorName,
    authorUrl,
    profileName,
    filterMode = 'unreplied_by_profile',
    skipOwn = true,
    oneReplyPerUser = true,
    skipIfInboxMessaged = true,
    actionMode = 'inbox_only'
  ) {
    const cleanProfile = (profileName || '').trim().toLowerCase();
    const cleanAuthor = (authorName || '').trim().toLowerCase();

    // 1. Strict Lifetime Memory Check
    if (oneReplyPerUser && isUserInPermanentMemory(authorName, authorUrl)) {
      return { replied: true, reason: `Already in permanent memory - never message again ("${authorName}")` };
    }

    // 2. Strict Inbox Status Check
    if (skipIfInboxMessaged && checkCommentHasInboxMessage(commentEl)) {
      return { replied: true, reason: 'Already messaged in inbox (Found existing message indicator)' };
    }

    // 3. Skip own comment if enabled
    if (skipOwn && cleanProfile && (cleanAuthor === cleanProfile || cleanProfile.includes(cleanAuthor) || cleanAuthor.includes(cleanProfile))) {
      return { replied: true, reason: 'Own comment posted by this profile' };
    }

    // 4. Check session replied
    if (commentEl.hasAttribute('data-fb-replied') || commentEl.querySelector('.fb-replier-badge') || repliedCommentIds.has(`${authorName}_${commentEl.textContent.slice(0, 20)}`)) {
      return { replied: true, reason: 'Processed in current session' };
    }

    if (filterMode === 'all') {
      return { replied: false };
    }

    const parentContainer = commentEl.closest('ul > li') || commentEl.parentElement || commentEl;
    const nestedArticles = Array.from(parentContainer.querySelectorAll('div[role="article"]')).filter(el => el !== commentEl);

    const buttons = Array.from(parentContainer.querySelectorAll('[role="button"], span[role="button"]'));
    const replyCountBtn = buttons.find(b => {
      const txt = (b.textContent || '').trim();
      return /\b(\d+\s*(replies|reply)|view\s*\d+\s*repl)/i.test(txt);
    });

    if (filterMode === 'zero_replies') {
      if (nestedArticles.length > 0 || replyCountBtn) {
        return { replied: true, reason: 'Comment already has existing replies' };
      }
      return { replied: false };
    }

    // filterMode === 'unreplied_by_profile'
    for (const reply of nestedArticles) {
      const replyAuthorEl = reply.querySelector('a[role="link"] span, span[dir="auto"] strong');
      const replyAuthor = (replyAuthorEl ? replyAuthorEl.textContent : '').trim().toLowerCase();

      if (cleanProfile && replyAuthor && (replyAuthor === cleanProfile || replyAuthor.includes(cleanProfile) || cleanProfile.includes(replyAuthor))) {
        return { replied: true, reason: `Already replied by "${replyAuthor}"` };
      }

      const badges = Array.from(reply.querySelectorAll('span, div'));
      const hasAuthorBadge = badges.some(b => {
        const t = (b.textContent || '').trim().toLowerCase();
        return t === 'author' || t === 'musannif' || t === 'admin';
      });

      if (hasAuthorBadge) {
        return { replied: true, reason: 'Already replied by Post Author/Admin' };
      }
    }

    return { replied: false };
  }

  // --- Find Comment Expanders ("View X more comments", "View replies") ---
  function findCommentExpanderButtons() {
    const searchRoot = document;
    const candidates = Array.from(searchRoot.querySelectorAll('div[role="button"], span[role="button"], a[role="button"], span, a, div[dir="auto"]'));
    const expandRegex = /(view\s*\d*\s*(more|previous|next|all)?\s*comment|see\s*more\s*comment|load\s*more\s*comment|view\s*\d+\s*repl|view\s*previous\s*repl|view\s*more\s*repl|view\s*replies|\b\d+\s*repl(y|ies)\b|مزید\s*تبصرے|پچھلے\s*تبصرے|تمام\s*تبصرے|اور\s*کمنٹس)/i;

    const matched = [];
    const seen = new Set();

    for (const el of candidates) {
      const text = (el.textContent || '').trim();
      const aria = (el.getAttribute('aria-label') || '').trim();

      if (/^(reply|jawab|responder|like|share)$/i.test(text)) continue;

      if (expandRegex.test(text) || expandRegex.test(aria)) {
        const btn = el.closest('[role="button"]') || el;
        if (!seen.has(btn)) {
          seen.add(btn);
          matched.push(btn);
        }
      }
    }
    return matched;
  }

  // --- Auto-expand Hidden Comments with Deep Fetch ---
  async function autoExpandMoreComments(postEl, isDeepFetch = false) {
    const root = resolvePostAndCommentRoot(postEl);
    notifySidepanel('LOG', { text: `🔎 ${isDeepFetch ? 'Deep Auto-Fetching all comments on post' : 'Expanding hidden comments'}...`, type: 'info' });

    // 1. Switch Comment Filter to "All comments"
    try {
      await switchCommentFilterToAll(root);
    } catch (e) {
      console.warn('Could not switch to All comments filter:', e);
    }

    let expandClicks = 0;
    const maxRounds = isDeepFetch ? 35 : 12;
    let lastCount = findReplyButtons(document).length;
    let stagnantRounds = 0;

    for (let round = 0; round < maxRounds; round++) {
      if (shouldStop) break;

      const moreButtons = findCommentExpanderButtons();

      if (moreButtons.length > 0) {
        for (let i = 0; i < Math.min(6, moreButtons.length); i++) {
          if (shouldStop) break;
          const btn = moreButtons[i];
          try {
            if (btn.scrollIntoView) {
              btn.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
            btn.click();
            btn.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
            expandClicks++;
            await sleep(600);
          } catch (e) {}
        }
      }

      // Scroll container down to trigger lazy loading
      scrollForMoreComments(root);
      await sleep(1400);

      const currentCount = findReplyButtons(document).length;
      if (currentCount > lastCount) {
        notifySidepanel('LOG', { text: `📥 Auto-fetching: ${currentCount} comments loaded in DOM...`, type: 'info' });
        lastCount = currentCount;
        stagnantRounds = 0;
      } else {
        stagnantRounds++;
      }

      if (moreButtons.length === 0 && stagnantRounds >= 3) {
        break;
      }
    }

    const finalCount = findCommentsInPost(postEl, 'all').length;
    notifySidepanel('LOG', { text: `🎉 Fully fetched ${finalCount} comments! Updating scan...`, type: 'success' });
  }

  function scrollForMoreComments(root) {
    window.scrollBy(0, 500);
    // Find all scrollable containers on the page (photo sidebar, feeds, modals)
    const allElements = document.querySelectorAll('div, section, main, aside');
    for (const el of allElements) {
      try {
        if (el.scrollHeight > el.clientHeight && el.clientHeight > 100) {
          const style = window.getComputedStyle(el);
          if (style.overflowY === 'auto' || style.overflowY === 'scroll') {
            el.scrollTop += 500;
          }
        }
      } catch (e) {}
    }
  }

  async function switchCommentFilterToAll(root) {
    const candidates = Array.from(document.querySelectorAll('[role="button"], span[dir="auto"], [aria-label*="comment ranking" i], [aria-label*="filter" i]'));
    const filterBtn = candidates.find(c => {
      const t = (c.textContent || '').trim().toLowerCase();
      const a = (c.getAttribute('aria-label') || '').trim().toLowerCase();
      return t.includes('most relevant') || t.includes('top comments') || t.includes('prasangik') ||
             a.includes('comment ranking') || a.includes('filter comments');
    });

    if (filterBtn) {
      filterBtn.click();
      await sleep(800);
      const menuItems = Array.from(document.querySelectorAll('[role="menuitem"], [role="menuitemradio"], span[dir="auto"], div[role="button"]'));
      const allItem = menuItems.find(m => {
        const txt = (m.textContent || '').trim().toLowerCase();
        return txt.includes('all comments') || txt.includes('tamam tabsire');
      });
      if (allItem) {
        allItem.click();
        await sleep(1500);
        notifySidepanel('LOG', { text: '🎯 Switched comments filter to "All comments".', type: 'info' });
      }
    }
  }

  // --- Reply & Inbox Execution Engine ---
  async function startReplyBot(config) {
    isRunning = true;
    shouldStop = false;

    const {
      messageTemplate,
      actionMode = 'inbox_only',
      skipIfInboxMessaged = true,
      minDelay = 8,
      maxDelay = 14,
      maxReplies = 50,
      replyScope = 'top_level',
      autoExpand = true,
      skipReplied = true,
      enableSpintax = true,
      profileName = '',
      filterMode = 'unreplied_by_profile',
      skipOwnComments = true,
      oneReplyPerUser = true
    } = config;

    loadRepliedUsers();
    notifySidepanel('BOT_STATE', { isRunning: true });
    notifySidepanel('LOG', { text: `🚀 Starting Bot [Mode: ${getModeLabel(actionMode)}]...`, type: 'info' });

    try {
      if (!activeTargetPost) {
        autoDetectPost();
      }

      if (!activeTargetPost) {
        notifySidepanel('LOG', { text: '❌ No post selected. Please select a post first!', type: 'error' });
        stopBot();
        return;
      }

      // 1. Auto expand if requested
      if (autoExpand) {
        await autoExpandMoreComments(activeTargetPost, true);
      }

      // 2. Scan comments
      let comments = findCommentsInPost(activeTargetPost, replyScope);
      notifySidepanel('STATS_UPDATE', { total: comments.length, remaining: comments.length });
      notifySidepanel('LOG', { text: `📋 Found ${comments.length} target comments on post.`, type: 'info' });

      let repliedCount = 0;
      let skippedCount = 0;

      for (let i = 0; i < comments.length; i++) {
        if (shouldStop) {
          notifySidepanel('LOG', { text: '🛑 Bot stopped by user.', type: 'warning' });
          break;
        }

        if (repliedCount >= maxReplies) {
          notifySidepanel('LOG', { text: `🎉 Reached maximum limit (${maxReplies})!`, type: 'success' });
          break;
        }

        const comment = comments[i];

        // Check profile reply status, memory, and inbox status
        const profileCheck = checkIfCommentRepliedByProfile(
          comment.commentEl,
          comment.author,
          comment.authorUrl,
          profileName,
          filterMode,
          skipOwnComments,
          oneReplyPerUser,
          skipIfInboxMessaged,
          actionMode
        );

        if (skipReplied && profileCheck.replied) {
          skippedCount++;
          notifySidepanel('STATS_UPDATE', { skipped: skippedCount, remaining: comments.length - (repliedCount + skippedCount) });
          notifySidepanel('LOG', { text: `⏩ Skipped "${comment.author}" (${profileCheck.reason}).`, type: 'system' });
          continue;
        }

        // Format message for this user
        const finalMessage = formatMessage(messageTemplate, comment.author, enableSpintax);

        notifySidepanel('PROGRESS_UPDATE', {
          status: `Processing ${comment.author}...`,
          countdown: 0,
          percent: Math.round(((i + 1) / comments.length) * 100)
        });

        // Scroll to comment
        if (comment.commentEl.scrollIntoView) {
          comment.commentEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
        await sleep(800);

        let sendSuccess = false;
        let actionLabel = 'Messaged';

        // 3. Perform action based on actionMode
        if (actionMode === 'inbox_only') {
          const msgBtn = comment.messageBtn || findSendMessageButton(comment.commentEl);
          if (msgBtn) {
            notifySidepanel('LOG', { text: `📩 Sending Inbox Message to "${comment.author}"...`, type: 'info' });
            sendSuccess = await executeInboxMessage(comment.commentEl, msgBtn, finalMessage);
            actionLabel = 'Inbox Messaged 📥';
          } else {
            notifySidepanel('LOG', { text: `⚠️ "Send message" (میسج کریں) button not available on comment by "${comment.author}". Skipping...`, type: 'warning' });
            skippedCount++;
            continue;
          }
        } else if (actionMode === 'inbox_or_reply') {
          const msgBtn = comment.messageBtn || findSendMessageButton(comment.commentEl);
          if (msgBtn) {
            notifySidepanel('LOG', { text: `📩 Sending Inbox Message to "${comment.author}"...`, type: 'info' });
            sendSuccess = await executeInboxMessage(comment.commentEl, msgBtn, finalMessage);
            actionLabel = 'Inbox Messaged 📥';
          }
          if (!sendSuccess) {
            notifySidepanel('LOG', { text: `ℹ️ "Send message" not available, sending Comment Reply to "${comment.author}"...`, type: 'info' });
            sendSuccess = await executeCommentReply(comment.commentEl, comment.replyBtn, finalMessage);
            actionLabel = 'Comment Replied 💬';
          }
        } else if (actionMode === 'reply_only') {
          notifySidepanel('LOG', { text: `💬 Sending Comment Reply to "${comment.author}": "${finalMessage.slice(0, 40)}..."`, type: 'info' });
          sendSuccess = await executeCommentReply(comment.commentEl, comment.replyBtn, finalMessage);
          actionLabel = 'Comment Replied 💬';
        } else if (actionMode === 'both') {
          notifySidepanel('LOG', { text: `🚀 Sending Inbox Message + Comment Reply to "${comment.author}"...`, type: 'info' });
          const msgBtn = comment.messageBtn || findSendMessageButton(comment.commentEl);
          let inboxDone = false;
          if (msgBtn) {
            inboxDone = await executeInboxMessage(comment.commentEl, msgBtn, finalMessage);
            await sleep(1500);
          }
          const replyDone = await executeCommentReply(comment.commentEl, comment.replyBtn, finalMessage);
          sendSuccess = inboxDone || replyDone;
          actionLabel = 'Inbox + Reply 🚀';
        }

        if (sendSuccess) {
          repliedCount++;
          repliedCommentIds.add(comment.id);

          // Save author name and profile URL to permanent memory
          saveUserToPermanentMemory(comment.author, comment.authorUrl);

          comment.commentEl.setAttribute('data-fb-replied', 'true');
          attachVisualBadge(comment.commentEl, actionLabel);

          notifySidepanel('STATS_UPDATE', {
            replied: repliedCount,
            skipped: skippedCount,
            remaining: Math.max(0, comments.length - (repliedCount + skippedCount))
          });
          notifySidepanel('LOG', { text: `✅ Successfully processed "${comment.author}" (${actionLabel}) & saved in memory!`, type: 'success' });
        } else {
          skippedCount++;
          notifySidepanel('LOG', { text: `⚠️ Failed to send to "${comment.author}".`, type: 'error' });
        }

        // Delay before next comment (Anti-ban throttle)
        if (i < comments.length - 1 && repliedCount < maxReplies && !shouldStop) {
          const delaySec = Math.floor(minDelay + Math.random() * (maxDelay - minDelay + 1));
          notifySidepanel('LOG', { text: `⏳ Safe delay: waiting ${delaySec}s before next...`, type: 'system' });

          for (let s = delaySec; s > 0; s--) {
            if (shouldStop) break;
            notifySidepanel('PROGRESS_UPDATE', {
              status: `Next action in ${s}s...`,
              countdown: s,
              percent: Math.round(((i + 1) / comments.length) * 100)
            });
            await sleep(1000);
          }
        }
      }

      notifySidepanel('LOG', { text: `🏁 Task complete! Total: ${repliedCount} processed, ${skippedCount} skipped.`, type: 'success' });
    } catch (error) {
      console.error('Bot Error:', error);
      notifySidepanel('LOG', { text: `❌ Error occurred: ${error.message}`, type: 'error' });
    } finally {
      stopBot();
    }
  }

  function getModeLabel(mode) {
    switch (mode) {
      case 'inbox_only': return 'Inbox Private Message Only';
      case 'inbox_or_reply': return 'Inbox Message (fallback to Reply)';
      case 'reply_only': return 'Public Comment Reply Only';
      case 'both': return 'Both (Inbox + Reply)';
      default: return mode;
    }
  }

  function stopBot() {
    isRunning = false;
    shouldStop = false;
    notifySidepanel('BOT_STATE', { isRunning: false });
    notifySidepanel('PROGRESS_UPDATE', { status: 'Idle', countdown: 0, percent: 0 });
  }

  // --- Inbox Message Automation ---
  async function executeInboxMessage(commentEl, msgBtn, message) {
    try {
      try {
        msgBtn.click();
      } catch (e) {
        msgBtn.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
      }

      await sleep(1500);
      if (shouldStop) return false;

      // Find inbox input field
      const inputField = findInboxMessageInputField(commentEl);
      if (!inputField) {
        console.warn('Could not find inbox message input field');
        return false;
      }

      const submitted = await typeAndSubmitReply(inputField, message, true);
      await sleep(1000);

      // Clean up open Messenger dock tabs
      closeMessengerChatDock();

      return submitted;
    } catch (e) {
      console.error('Error executing inbox message:', e);
      return false;
    }
  }

  // --- Comment Reply Automation ---
  async function executeCommentReply(commentEl, replyBtn, message) {
    try {
      const btn = replyBtn || findReplyButtons(commentEl)[0];
      if (!btn) return false;

      try {
        btn.click();
      } catch (e) {
        btn.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
      }

      await sleep(1200);
      if (shouldStop) return false;

      const inputField = findCommentInputField(commentEl);
      if (!inputField) {
        return false;
      }

      return await typeAndSubmitReply(inputField, message, false);
    } catch (e) {
      console.error('Error executing comment reply:', e);
      return false;
    }
  }

  // Find input field for inbox private message
  function findInboxMessageInputField(commentEl) {
    // 1. Look inside comment container for inline private reply box
    if (commentEl) {
      const inlineBox = commentEl.querySelector('div[role="textbox"][contenteditable="true"], textarea, div[contenteditable="true"]');
      if (inlineBox) return inlineBox;
    }

    // 2. Look in opened dialogs or Messenger popover/dock
    const dialogs = Array.from(document.querySelectorAll('div[role="dialog"], div[role="region"], div[data-pagelet*="Chat"], div[data-pagelet*="Messenger"]'));
    for (let i = dialogs.length - 1; i >= 0; i--) {
      const d = dialogs[i];
      const tb = d.querySelector('div[role="textbox"][contenteditable="true"], textarea, div[contenteditable="true"]');
      if (tb) return tb;
    }

    // 3. Check active element
    if (document.activeElement && (document.activeElement.getAttribute('contenteditable') === 'true' || document.activeElement.tagName === 'TEXTAREA')) {
      return document.activeElement;
    }

    // 4. Any open textbox on page
    const textboxes = Array.from(document.querySelectorAll('div[role="textbox"][contenteditable="true"]'));
    if (textboxes.length > 0) {
      return textboxes[textboxes.length - 1];
    }

    return null;
  }

  // Close Messenger chat dock if it was opened
  function closeMessengerChatDock() {
    try {
      const closeButtons = Array.from(document.querySelectorAll('div[aria-label*="Close chat" i], div[aria-label*="Close" i][role="button"], div[aria-label*="बंद" i], div[aria-label*="چیٹ بند کریں" i]'));
      if (closeButtons.length > 0) {
        closeButtons[closeButtons.length - 1].click();
      }
    } catch (e) {}
  }

  // --- Lexical Input & Submit Simulator ---
  function findCommentInputField(commentEl) {
    if (document.activeElement && document.activeElement.getAttribute('contenteditable') === 'true') {
      return document.activeElement;
    }

    const container = commentEl.parentElement || commentEl;
    const candidates = Array.from(container.querySelectorAll('div[role="textbox"][contenteditable="true"], div[contenteditable="true"]'));
    if (candidates.length > 0) {
      return candidates[candidates.length - 1];
    }

    if (activeTargetPost) {
      const postBoxes = Array.from(activeTargetPost.querySelectorAll('div[role="textbox"][contenteditable="true"]'));
      if (postBoxes.length > 0) {
        return postBoxes[postBoxes.length - 1];
      }
    }

    return null;
  }

  async function typeAndSubmitReply(inputEl, message, isInbox = false) {
    try {
      inputEl.focus();
      await sleep(200);

      // Select content and insert text using execCommand for Lexical/DraftJS compatibility
      const selection = window.getSelection();
      const range = document.createRange();
      range.selectNodeContents(inputEl);
      range.collapse(false);
      selection.removeAllRanges();
      selection.addRange(range);

      const inserted = document.execCommand('insertText', false, message);

      if (!inserted || !inputEl.textContent.includes(message.slice(0, 10))) {
        inputEl.dispatchEvent(new InputEvent('beforeinput', {
          bubbles: true,
          cancelable: true,
          data: message,
          inputType: 'insertText'
        }));
        inputEl.dispatchEvent(new InputEvent('input', {
          bubbles: true,
          cancelable: true,
          data: message,
          inputType: 'insertText'
        }));
      }

      await sleep(500);

      // Trigger Enter keydown
      const enterDown = new KeyboardEvent('keydown', {
        key: 'Enter',
        code: 'Enter',
        keyCode: 13,
        which: 13,
        bubbles: true,
        cancelable: true
      });
      inputEl.dispatchEvent(enterDown);

      const enterUp = new KeyboardEvent('keyup', {
        key: 'Enter',
        code: 'Enter',
        keyCode: 13,
        which: 13,
        bubbles: true,
        cancelable: true
      });
      inputEl.dispatchEvent(enterUp);

      await sleep(1000);

      // Fallback: If input is not cleared or button needs to be clicked
      const container = inputEl.closest('form') || inputEl.closest('div[role="dialog"]') || inputEl.parentElement?.parentElement;
      if (container) {
        const sendBtn = container.querySelector(
          'div[role="button"][aria-label*="send" i], div[role="button"][aria-label*="message" i], div[role="button"][aria-label*="comment" i], div[role="button"][aria-label*="reply" i], div[role="button"][aria-label*="post" i], div[role="button"][aria-label*="بھیجیں" i], svg[aria-label*="Send" i], button[type="submit"]'
        );
        if (sendBtn) {
          sendBtn.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
          await sleep(1000);
        }
      }

      return true;
    } catch (err) {
      console.error('Error typing reply/message:', err);
      return false;
    }
  }

  // --- Message Formatter ---
  function formatMessage(template, authorName, useSpintax) {
    let result = template || 'Hello {name}, thanks for reaching out!';

    // Replace {name}
    result = result.replace(/\{name\}/gi, authorName || 'Friend');

    // Replace {first_name}
    const firstName = (authorName || 'Friend').split(' ')[0];
    result = result.replace(/\{first_name\}/gi, firstName);

    // Random Emoji
    const emojis = ['👍', '✨', '📥', '🙏', '🔥', '😊', '⭐', '🤝'];
    result = result.replace(/\{random_emoji\}/gi, () => emojis[Math.floor(Math.random() * emojis.length)]);

    // Spintax {Hi|Hello|Hey}
    if (useSpintax) {
      result = result.replace(/\{([^{}]+)\}/g, (match, content) => {
        const parts = content.split('|');
        if (parts.length > 1) {
          return parts[Math.floor(Math.random() * parts.length)].trim();
        }
        return match;
      });
    }

    return result.trim();
  }

  function attachVisualBadge(commentEl, actionText = 'Messaged 📥') {
    if (commentEl.querySelector('.fb-replier-badge')) return;
    const badge = document.createElement('span');
    badge.className = 'fb-replier-badge';
    badge.textContent = `✅ ${actionText}`;
    const headerEl = commentEl.querySelector('a[role="link"], strong') || commentEl;
    headerEl.appendChild(badge);
  }

  // --- Helper to send messages to sidepanel ---
  function notifySidepanel(type, payload) {
    chrome.runtime.sendMessage({
      target: 'SIDEPANEL',
      type,
      ...payload
    }).catch(() => {
      // Side panel might be closed, ignore error
    });
  }
})();
