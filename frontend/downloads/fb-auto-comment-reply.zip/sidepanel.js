// Side Panel Controller for FB Auto Comment Replier VIP
document.addEventListener('DOMContentLoaded', async () => {
  // DOM Elements
  const fbStatusBadge = document.getElementById('fbStatusBadge');
  const fbStatusText = document.getElementById('fbStatusText');
  const postUrlInput = document.getElementById('postUrlInput');
  const btnLoadPostUrl = document.getElementById('btnLoadPostUrl');
  const btnSelectPost = document.getElementById('btnSelectPost');
  const btnAutoDetectPost = document.getElementById('btnAutoDetectPost');
  const selectedPostStatus = document.getElementById('selectedPostStatus');
  const previewEmpty = document.getElementById('previewEmpty');
  const previewDetails = document.getElementById('previewDetails');
  const previewAuthor = document.getElementById('previewAuthor');
  const previewSnippet = document.getElementById('previewSnippet');
  const previewCommentCount = document.getElementById('previewCommentCount');

  const replyMessage = document.getElementById('replyMessage');
  const enableSpintax = document.getElementById('enableSpintax');
  const tagChips = document.querySelectorAll('.chip');

  const actionMode = document.getElementById('actionMode');
  const skipIfInboxMessaged = document.getElementById('skipIfInboxMessaged');
  const profileNameInput = document.getElementById('profileNameInput');
  const btnDetectProfile = document.getElementById('btnDetectProfile');
  const replyFilterMode = document.getElementById('replyFilterMode');
  const skipOwnComments = document.getElementById('skipOwnComments');

  const oneReplyPerUser = document.getElementById('oneReplyPerUser');
  const historyCounterLabel = document.getElementById('historyCounterLabel');
  const btnClearHistory = document.getElementById('btnClearHistory');
  const btnFetchAllComments = document.getElementById('btnFetchAllComments');

  const minDelay = document.getElementById('minDelay');
  const maxDelay = document.getElementById('maxDelay');
  const maxReplies = document.getElementById('maxReplies');
  const replyScope = document.getElementById('replyScope');
  const autoExpandComments = document.getElementById('autoExpandComments');
  const skipReplied = document.getElementById('skipReplied');

  const btnScanComments = document.getElementById('btnScanComments');
  const btnStart = document.getElementById('btnStart');
  const btnStop = document.getElementById('btnStop');

  const statTotal = document.getElementById('statTotal');
  const statReplied = document.getElementById('statReplied');
  const statRemaining = document.getElementById('statRemaining');
  const statSkipped = document.getElementById('statSkipped');

  const progressSection = document.getElementById('progressSection');
  const progressStatusText = document.getElementById('progressStatusText');
  const progressCountdown = document.getElementById('progressCountdown');
  const progressBarFill = document.getElementById('progressBarFill');

  const logConsole = document.getElementById('logConsole');
  const btnClearLogs = document.getElementById('btnClearLogs');

  let activeFbTabId = null;
  let isBotRunning = false;

  // --- Initialize Storage ---
  chrome.storage.local.get(['fbReplyMessage', 'actionMode', 'skipIfInboxMessaged', 'minDelay', 'maxDelay', 'maxReplies', 'autoExpand', 'fbProfileName', 'fbFilterMode', 'skipOwn', 'oneReply', 'repliedUsersList'], (res) => {
    if (res.fbReplyMessage) {
      replyMessage.value = res.fbReplyMessage;
    } else {
      replyMessage.value = 'Hello {name}, thanks for reaching out! Check your inbox 📥';
    }
    if (res.actionMode) actionMode.value = res.actionMode;
    if (res.skipIfInboxMessaged !== undefined) skipIfInboxMessaged.checked = res.skipIfInboxMessaged;
    if (res.minDelay) minDelay.value = res.minDelay;
    if (res.maxDelay) maxDelay.value = res.maxDelay;
    if (res.maxReplies) maxReplies.value = res.maxReplies;
    if (res.autoExpand !== undefined) autoExpandComments.checked = res.autoExpand;
    if (res.fbProfileName) profileNameInput.value = res.fbProfileName;
    if (res.fbFilterMode) replyFilterMode.value = res.fbFilterMode;
    if (res.skipOwn !== undefined) skipOwnComments.checked = res.skipOwn;
    if (res.oneReply !== undefined) oneReplyPerUser.checked = res.oneReply;

    const count = Array.isArray(res.repliedUsersList) ? res.repliedUsersList.length : 0;
    historyCounterLabel.textContent = `Memory: ${count} users saved (Never message again)`;
  });

  // Save changes to storage
  const saveSettings = () => {
    chrome.storage.local.set({
      fbReplyMessage: replyMessage.value,
      actionMode: actionMode.value,
      skipIfInboxMessaged: skipIfInboxMessaged.checked,
      minDelay: parseInt(minDelay.value, 10),
      maxDelay: parseInt(maxDelay.value, 10),
      maxReplies: parseInt(maxReplies.value, 10),
      autoExpand: autoExpandComments.checked,
      fbProfileName: profileNameInput.value.trim(),
      fbFilterMode: replyFilterMode.value,
      skipOwn: skipOwnComments.checked,
      oneReply: oneReplyPerUser.checked
    });
  };

  actionMode.addEventListener('change', saveSettings);
  skipIfInboxMessaged.addEventListener('change', saveSettings);
  replyMessage.addEventListener('input', saveSettings);
  profileNameInput.addEventListener('input', saveSettings);
  replyFilterMode.addEventListener('change', saveSettings);
  skipOwnComments.addEventListener('change', saveSettings);
  oneReplyPerUser.addEventListener('change', saveSettings);
  minDelay.addEventListener('change', saveSettings);
  maxDelay.addEventListener('change', saveSettings);
  maxReplies.addEventListener('change', saveSettings);
  autoExpandComments.addEventListener('change', saveSettings);

  // --- Tag Chips Click ---
  tagChips.forEach(chip => {
    chip.addEventListener('click', () => {
      const tag = chip.getAttribute('data-tag');
      insertTextAtCursor(replyMessage, tag);
      saveSettings();
    });
  });

  function insertTextAtCursor(textarea, text) {
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const val = textarea.value;
    textarea.value = val.substring(0, start) + text + val.substring(end);
    textarea.focus();
    textarea.selectionStart = textarea.selectionEnd = start + text.length;
  }

  // --- Log Utility ---
  function addLog(text, type = 'system') {
    const line = document.createElement('div');
    line.className = `log-line log-${type}`;
    const time = new Date().toLocaleTimeString('en-US', { hour12: false });
    line.textContent = `[${time}] ${text}`;
    logConsole.appendChild(line);
    logConsole.scrollTop = logConsole.scrollHeight;
  }

  btnClearLogs.addEventListener('click', () => {
    logConsole.innerHTML = '';
    addLog('Logs cleared.', 'system');
  });

  // --- Tab Finder & Connection ---
  async function getActiveFacebookTab() {
    return new Promise((resolve) => {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs && tabs[0] && tabs[0].url && tabs[0].url.includes('facebook.com')) {
          resolve(tabs[0]);
        } else {
          // Check any tab with facebook.com
          chrome.tabs.query({ url: '*://*.facebook.com/*' }, (fbTabs) => {
            if (fbTabs && fbTabs.length > 0) {
              resolve(fbTabs[0]);
            } else {
              resolve(null);
            }
          });
        }
      });
    });
  }

  async function checkFacebookConnection() {
    const tab = await getActiveFacebookTab();
    if (tab) {
      activeFbTabId = tab.id;
      fbStatusBadge.classList.remove('disconnected');
      fbStatusText.textContent = 'FB Connected';

      // Check if content script responds
      chrome.tabs.sendMessage(tab.id, { action: 'PING' }, (res) => {
        if (chrome.runtime.lastError) {
          // Needs injection or reload
          fbStatusText.textContent = 'Reload FB Tab';
          fbStatusBadge.classList.add('disconnected');
        } else {
          fbStatusText.textContent = 'FB Connected';
          fbStatusBadge.classList.remove('disconnected');
        }
      });
    } else {
      activeFbTabId = null;
      fbStatusBadge.classList.add('disconnected');
      fbStatusText.textContent = 'Open Facebook';
    }
  }

  // Check periodically
  checkFacebookConnection();
  setInterval(checkFacebookConnection, 3000);

  // --- Script Injection Helper ---
  async function ensureContentScriptInjected(tabId) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        files: ['content.js']
      });
      return true;
    } catch (e) {
      console.warn('Could not inject content script:', e);
      return false;
    }
  }

  // --- Helper to Send Tab Message with Auto-Injection Retry ---
  async function sendTabMessage(msg, retry = true) {
    if (!activeFbTabId) {
      const tab = await getActiveFacebookTab();
      if (tab) activeFbTabId = tab.id;
    }
    if (!activeFbTabId) {
      addLog('❌ Please open Facebook in a tab first!', 'error');
      return null;
    }

    return new Promise((resolve) => {
      chrome.tabs.sendMessage(activeFbTabId, msg, async (res) => {
        if (chrome.runtime.lastError) {
          const err = chrome.runtime.lastError.message || '';
          if (retry && err.includes('Receiving end does not exist')) {
            addLog('🔄 Connecting to Facebook tab...', 'system');
            const injected = await ensureContentScriptInjected(activeFbTabId);
            if (injected) {
              await new Promise(r => setTimeout(r, 400));
              const retryRes = await sendTabMessage(msg, false);
              return resolve(retryRes);
            }
          }
          addLog(`⚠️ Facebook connection error: ${err}`, 'error');
          resolve(null);
        } else {
          resolve(res);
        }
      });
    });
  }

  // --- Open & Scan Post URL Button ---
  btnLoadPostUrl.addEventListener('click', async () => {
    let url = postUrlInput.value.trim();
    if (!url) {
      addLog('❌ Please paste a Facebook post link first!', 'error');
      postUrlInput.focus();
      return;
    }

    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      url = 'https://' + url;
    }

    addLog(`🌐 Loading Facebook post: ${url.slice(0, 45)}...`, 'info');

    let tab = await getActiveFacebookTab();
    if (!tab) {
      tab = await chrome.tabs.create({ url, active: true });
      activeFbTabId = tab.id;
    } else {
      activeFbTabId = tab.id;
      chrome.tabs.update(tab.id, { url, active: true });
    }

    addLog('⏳ Waiting for post page to load...', 'system');

    // Wait for page to finish loading
    await new Promise((resolve) => {
      const listener = (tabId, changeInfo) => {
        if (tabId === activeFbTabId && changeInfo.status === 'complete') {
          chrome.tabs.onUpdated.removeListener(listener);
          resolve();
        }
      };
      chrome.tabs.onUpdated.addListener(listener);
      // Fallback timeout 8 seconds
      setTimeout(() => {
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }, 8000);
    });

    await new Promise(r => setTimeout(r, 2500));
    await ensureContentScriptInjected(activeFbTabId);
    await new Promise(r => setTimeout(r, 800));

    // Auto-detect post on newly loaded page
    addLog('⚡ Auto-locking post...', 'info');
    const autoRes = await sendTabMessage({ action: 'AUTO_DETECT_POST' });
    if (autoRes && autoRes.success) {
      addLog('🎯 Post locked successfully!', 'success');
    }

    // Auto-scan comments
    addLog('🔍 Scanning all comments with profile filter...', 'info');
    const scanRes = await sendTabMessage({
      action: 'SCAN_COMMENTS',
      scope: replyScope.value,
      profileName: profileNameInput.value.trim(),
      filterMode: replyFilterMode.value,
      skipOwnComments: skipOwnComments.checked
    });

    if (scanRes && scanRes.count !== undefined) {
      statTotal.textContent = scanRes.totalFound || scanRes.count;
      statRemaining.textContent = scanRes.targetCount !== undefined ? scanRes.targetCount : scanRes.count;
      statSkipped.textContent = scanRes.skippedCount || 0;
      addLog(`📊 Found ${scanRes.targetCount || scanRes.count} comments that need a reply! (${scanRes.skippedCount || 0} skipped as already replied)`, 'success');
    }
  });

  // --- Auto-Detect Profile Button ---
  btnDetectProfile.addEventListener('click', async () => {
    addLog('👤 Detecting active Facebook profile/page...', 'info');
    const res = await sendTabMessage({ action: 'DETECT_PROFILE' });
    if (res && res.profileName) {
      profileNameInput.value = res.profileName;
      saveSettings();
      addLog(`✅ Detected active profile: "${res.profileName}"`, 'success');
    } else {
      addLog('⚠️ Could not auto-detect profile name. Please type your Profile/Page name manually in the box.', 'warning');
    }
  });

  // --- Select Post Button ---
  btnSelectPost.addEventListener('click', async () => {
    addLog('🎯 Hover over a post on Facebook and click it to lock.', 'info');
    const res = await sendTabMessage({ action: 'START_POST_PICKER' });
    if (res) {
      selectedPostStatus.textContent = 'Selecting...';
      selectedPostStatus.classList.add('active');
    }
  });

  // --- Auto-Detect Post Button ---
  btnAutoDetectPost.addEventListener('click', async () => {
    addLog('⚡ Attempting to auto-detect post on page...', 'info');
    const res = await sendTabMessage({ action: 'AUTO_DETECT_POST' });
    if (res && res.success) {
      addLog(`✅ Auto-detected post successfully (Mode: ${res.method}).`, 'success');
    } else {
      addLog('⚠️ Could not auto-detect post. Please use "Select Post on Page" or paste Post URL.', 'warning');
    }
  });

  // --- Auto-Fetch All Comments Button ---
  btnFetchAllComments.addEventListener('click', async () => {
    addLog('📥 Starting Deep Auto-Fetch of all comments on this post...', 'info');
    btnFetchAllComments.disabled = true;
    const origText = btnFetchAllComments.innerHTML;
    btnFetchAllComments.innerHTML = '<span class="btn-icon">⏳</span> Auto-fetching all comments...';

    // Ensure post is locked
    await sendTabMessage({ action: 'AUTO_DETECT_POST' });

    const res = await sendTabMessage({
      action: 'AUTO_FETCH_COMMENTS',
      scope: replyScope.value
    });

    btnFetchAllComments.disabled = false;
    btnFetchAllComments.innerHTML = origText;

    if (res && res.success) {
      addLog(`🎉 Fully fetched ${res.count} comments! Updating scan...`, 'success');
      btnScanComments.click();
    } else {
      addLog('⚠️ Could not complete auto-fetch. Make sure post is open on the page.', 'warning');
    }
  });

  // --- Clear Replied History Button ---
  btnClearHistory.addEventListener('click', async () => {
    if (confirm('Are you sure you want to clear the saved users history from memory?')) {
      await sendTabMessage({ action: 'CLEAR_REPLIED_HISTORY' });
      chrome.storage.local.set({ repliedUsersList: [] });
      historyCounterLabel.textContent = 'Memory: 0 users saved (Never message again)';
      addLog('🗑️ Saved users history reset to 0.', 'system');
    }
  });

  // --- Scan Comments Button ---
  btnScanComments.addEventListener('click', async () => {
    addLog('🔍 Scanning target post for comments...', 'info');
    // Ensure post is locked first
    await sendTabMessage({ action: 'AUTO_DETECT_POST' });

    const res = await sendTabMessage({
      action: 'SCAN_COMMENTS',
      scope: replyScope.value,
      profileName: profileNameInput.value.trim(),
      filterMode: replyFilterMode.value,
      skipOwnComments: skipOwnComments.checked,
      oneReplyPerUser: oneReplyPerUser.checked,
      actionMode: actionMode.value,
      skipIfInboxMessaged: skipIfInboxMessaged.checked
    });

    if (res && res.count !== undefined) {
      statTotal.textContent = res.totalFound || res.count;
      statRemaining.textContent = res.targetCount !== undefined ? scanResCount(res) : res.count;
      statSkipped.textContent = res.skippedCount || 0;

      if (res.historyCount !== undefined) {
        historyCounterLabel.textContent = `Memory: ${res.historyCount} users saved (Never message again)`;
      }

      const prof = profileNameInput.value.trim();
      if (res.skippedCount > 0) {
        addLog(`📊 Total ${res.totalFound} comments: ${res.targetCount} ready for message, ${res.skippedCount} skipped (Inbox messaged / Memory / Profile filter).`, 'success');
      } else {
        addLog(`📊 Found ${res.count} comments ready for auto messaging!`, 'success');
      }
    } else {
      addLog('⚠️ Please make sure Facebook post and comments are open on the page.', 'warning');
    }
  });

  function scanResCount(res) {
    return res.targetCount !== undefined ? res.targetCount : res.count;
  }

  // --- Start Reply Bot ---
  btnStart.addEventListener('click', async () => {
    const text = replyMessage.value.trim();
    if (!text) {
      addLog('❌ Please enter a message before starting!', 'error');
      replyMessage.focus();
      return;
    }

    const minD = parseInt(minDelay.value, 10) || 8;
    const maxD = parseInt(maxDelay.value, 10) || 14;

    if (minD > maxD) {
      addLog('⚠️ Min delay cannot be greater than Max delay.', 'warning');
      return;
    }

    const config = {
      messageTemplate: text,
      actionMode: actionMode.value,
      skipIfInboxMessaged: skipIfInboxMessaged.checked,
      minDelay: minD,
      maxDelay: maxD,
      maxReplies: parseInt(maxReplies.value, 10) || 50,
      replyScope: replyScope.value,
      autoExpand: autoExpandComments.checked,
      skipReplied: skipReplied.checked,
      enableSpintax: enableSpintax.checked,
      profileName: profileNameInput.value.trim(),
      filterMode: replyFilterMode.value,
      skipOwnComments: skipOwnComments.checked,
      oneReplyPerUser: oneReplyPerUser.checked
    };

    const res = await sendTabMessage({
      action: 'START_REPLY_BOT',
      config
    });

    if (res && res.status === 'STARTED') {
      isBotRunning = true;
      updateBotUiState(true);
      progressSection.classList.remove('hidden');
    } else if (res && res.error) {
      addLog(`❌ ${res.error}`, 'error');
    }
  });

  // --- Stop Reply Bot ---
  btnStop.addEventListener('click', async () => {
    addLog('🛑 Stopping bot...', 'warning');
    await sendTabMessage({ action: 'STOP_REPLY_BOT' });
  });

  function updateBotUiState(running) {
    isBotRunning = running;
    if (running) {
      btnStart.classList.add('hidden');
      btnStop.classList.remove('hidden');
      btnFetchAllComments.disabled = true;
      btnSelectPost.disabled = true;
      btnAutoDetectPost.disabled = true;
      btnScanComments.disabled = true;
    } else {
      btnStart.classList.remove('hidden');
      btnStop.classList.add('hidden');
      btnFetchAllComments.disabled = false;
      btnSelectPost.disabled = false;
      btnAutoDetectPost.disabled = false;
      btnScanComments.disabled = false;
    }
  }

  // --- Listen to Messages from Content Script ---
  chrome.runtime.onMessage.addListener((message) => {
    if (message.target !== 'SIDEPANEL') return;

    switch (message.type) {
      case 'LOG':
        addLog(message.text, message.typeLog || message.type || 'info');
        break;

      case 'HISTORY_UPDATED':
        if (message.count !== undefined) {
          historyCounterLabel.textContent = `Replied History: ${message.count} users saved`;
        }
        break;

      case 'POST_SELECTED':
        selectedPostStatus.textContent = 'Locked';
        selectedPostStatus.classList.add('active');
        previewEmpty.classList.add('hidden');
        previewDetails.classList.remove('hidden');

        previewAuthor.textContent = `Author: ${message.author || 'Facebook User'}`;
        previewSnippet.textContent = `Post: "${message.snippet || ''}"`;
        previewCommentCount.textContent = `Comments: ${message.commentCount || 0}`;

        statTotal.textContent = message.commentCount || 0;
        statRemaining.textContent = message.commentCount || 0;
        break;

      case 'BOT_STATE':
        updateBotUiState(message.isRunning);
        if (!message.isRunning) {
          progressSection.classList.add('hidden');
        }
        break;

      case 'STATS_UPDATE':
        if (message.total !== undefined) statTotal.textContent = message.total;
        if (message.replied !== undefined) statReplied.textContent = message.replied;
        if (message.skipped !== undefined) statSkipped.textContent = message.skipped;
        if (message.remaining !== undefined) statRemaining.textContent = message.remaining;
        break;

      case 'PROGRESS_UPDATE':
        progressSection.classList.remove('hidden');
        progressStatusText.textContent = message.status || 'Processing...';
        progressCountdown.textContent = message.countdown > 0 ? `${message.countdown}s` : '';
        if (message.percent !== undefined) {
          progressBarFill.style.width = `${Math.min(100, Math.max(0, message.percent))}%`;
        }
        break;

      default:
        break;
    }
  });
});
