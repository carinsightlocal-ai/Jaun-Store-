const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

function createPNG(width, height, colorFn) {
  const bytesPerPixel = 4;
  const rowSize = 1 + width * bytesPerPixel;
  const rawData = Buffer.alloc(rowSize * height);

  for (let y = 0; y < height; y++) {
    const rowOffset = y * rowSize;
    rawData[rowOffset] = 0;
    for (let x = 0; x < width; x++) {
      const pixelOffset = rowOffset + 1 + x * bytesPerPixel;
      const [r, g, b, a] = colorFn(x, y, width, height);
      rawData[pixelOffset] = r;
      rawData[pixelOffset + 1] = g;
      rawData[pixelOffset + 2] = b;
      rawData[pixelOffset + 3] = a;
    }
  }

  const deflated = zlib.deflateSync(rawData);

  function makeChunk(type, data) {
    const len = Buffer.alloc(4);
    len.writeUInt32BE(data.length, 0);
    const typeBuf = Buffer.from(type, 'ascii');
    const crcBuf = Buffer.alloc(4);
    
    let crc = 0xffffffff;
    for (let i = 0; i < data.length + typeBuf.length; i++) {
      const byte = i < typeBuf.length ? typeBuf[i] : data[i - typeBuf.length];
      crc = (crc >>> 8) ^ crcTable[(crc ^ byte) & 0xff];
    }
    crcBuf.writeInt32BE(~crc, 0);

    return Buffer.concat([len, typeBuf, data, crcBuf]);
  }

  const crcTable = new Int32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) {
      c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
    }
    crcTable[n] = c;
  }

  const header = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8;
  ihdr[9] = 6;
  ihdr[10] = 0;
  ihdr[11] = 0;
  ihdr[12] = 0;

  const ihdrChunk = makeChunk('IHDR', ihdr);
  const idatChunk = makeChunk('IDAT', deflated);
  const iendChunk = makeChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([header, ihdrChunk, idatChunk, iendChunk]);
}

function replyTheme(x, y, w, h) {
  const cx = w / 2;
  const cy = h / 2;
  const radius = w * 0.46;
  const dx = x - cx;
  const dy = y - cy;
  const dist = Math.sqrt(dx * dx + dy * dy);

  if (dist > radius) {
    return [0, 0, 0, 0];
  }

  const normDist = dist / radius;
  
  // Outer glowing ring
  if (normDist > 0.88) {
    const t = (normDist - 0.88) / 0.12;
    return [0, 242, 254, Math.round(255 * (1 - t * 0.3))]; // Cyan glow
  }

  // Draw Chat Bubble + Reply Arrow Symbol
  const relX = (x - cx) / (w * 0.4);
  const relY = (y - cy) / (h * 0.4);

  // Chat Bubble Oval
  const bubbleDist = Math.sqrt(relX * relX * 0.8 + (relY + 0.1) * (relY + 0.1) * 1.2);
  const inBubble = bubbleDist <= 0.65;

  // Bubble tail
  const inTail = (relX >= -0.45 && relX <= -0.15 && relY >= 0.25 && relY <= 0.7 && (relX + relY * 0.5) <= 0.2);

  // Reply Arrow
  const inArrowHead = (relX >= -0.4 && relX <= -0.1 && Math.abs(relY - (-0.05)) <= 0.25 && (relX + 0.4) * 0.8 >= Math.abs(relY - (-0.05)));
  const inArrowStem = (relX >= -0.2 && relX <= 0.35 && relY >= -0.18 && relY <= 0.08);

  if (inArrowHead || inArrowStem) {
    return [255, 255, 255, 255]; // Pure White Arrow
  }

  if (inBubble || inTail) {
    // Gradient from Electric Blue to Cyan
    const bgT = (relY + 0.6) / 1.2;
    const r = Math.round(10 * (1 - bgT) + 0 * bgT);
    const g = Math.round(132 * (1 - bgT) + 220 * bgT);
    const b = Math.round(255 * (1 - bgT) + 240 * bgT);
    return [r, g, b, 255];
  }

  // Deep tech background gradient
  const bgGrad = (y / h);
  const r = Math.round(15 * (1 - bgGrad) + 10 * bgGrad);
  const g = Math.round(20 * (1 - bgGrad) + 12 * bgGrad);
  const b = Math.round(35 * (1 - bgGrad) + 22 * bgGrad);

  return [r, g, b, 255];
}

const iconsDir = path.join(__dirname, 'icons');
[16, 48, 128].forEach(size => {
  const pngBuf = createPNG(size, size, replyTheme);
  fs.writeFileSync(path.join(iconsDir, `icon${size}.png`), pngBuf);
  console.log(`Generated icon${size}.png`);
});
