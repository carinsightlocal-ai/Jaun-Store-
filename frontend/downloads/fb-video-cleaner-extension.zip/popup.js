/**
 * Extension Popup Logic
 */

document.addEventListener('DOMContentLoaded', () => {
  const dot = document.getElementById('popup-status-dot');
  const titleEl = document.getElementById('popup-tab-title');
  const totalEl = document.getElementById('popup-stat-total');
  const delEl = document.getElementById('popup-stat-deleted');
  const pendEl = document.getElementById('popup-stat-pending');

  const btnOpenDash = document.getElementById('btn-open-full-dash');
  const btnScan = document.getElementById('btn-popup-scan');
  const btnDel = document.getElementById('btn-popup-delete');

  function updateUI(state) {
    if (!state) return;
    
    if (state.isConnected) {
      dot.className = 'status-indicator connected';
      titleEl.textContent = state.pageTitle || 'Facebook Page';
      titleEl.title = state.pageUrl || '';
    } else {
      dot.className = 'status-indicator';
      titleEl.textContent = 'No FB tab connected';
    }

    const s = state.stats || { totalFound: 0, deleted: 0, pending: 0 };
    totalEl.textContent = s.totalFound || 0;
    delEl.textContent = s.deleted || 0;
    pendEl.textContent = s.pending || 0;
  }

  // Load state
  chrome.runtime.sendMessage({ action: 'GET_STATE' }, res => {
    if (res && res.state) {
      updateUI(res.state);
    }
  });

  // Open Full Dashboard
  btnOpenDash.addEventListener('click', () => {
    chrome.runtime.sendMessage({ action: 'OPEN_DASHBOARD' });
    window.close();
  });

  // Scan
  btnScan.addEventListener('click', () => {
    chrome.runtime.sendMessage({ action: 'START_SCAN' }, res => {
      chrome.runtime.sendMessage({ action: 'OPEN_DASHBOARD' });
      window.close();
    });
  });

  // Delete
  btnDel.addEventListener('click', () => {
    chrome.runtime.sendMessage({ action: 'OPEN_DASHBOARD' });
    window.close();
  });
});
