/**
 * FB Auto Post & Video Cleaner - Content Script
 * Injected into Facebook / Meta Business Suite / Local Mock tabs
 * Handles DOM scraping for ALL post types (Videos, Reels, Photos, Text),
 * continuous auto-scrolling, and automated deletion flows.
 */

(() => {
  if (window.__FB_POST_CLEANER_INJECTED) return;
  window.__FB_POST_CLEANER_INJECTED = true;

  let isScanningActive = false;
  let scanScrollCount = 0;
  const discoveredPostElements = new Map(); // id -> Element

  // Initialize In-Page Floating HUD
  function initHud() {
    if (document.getElementById('fb-cleaner-hud')) return;

    const hud = document.createElement('div');
    hud.id = 'fb-cleaner-hud';
    hud.innerHTML = `
      <div class="fb-cleaner-badge-dot" id="fb-cleaner-dot"></div>
      <div id="fb-cleaner-hud-text"><strong>FB Cleaner Side Panel:</strong> Ready</div>
      <button class="fb-cleaner-hud-btn" id="fb-cleaner-open-dash">Dashboard</button>
    `;

    document.body.appendChild(hud);

    hud.querySelector('#fb-cleaner-open-dash').addEventListener('click', () => {
      chrome.runtime.sendMessage({ action: 'OPEN_DASHBOARD' });
    });
  }

  function updateHud(statusText, stateClass = '') {
    const textEl = document.getElementById('fb-cleaner-hud-text');
    const dotEl = document.getElementById('fb-cleaner-dot');
    if (textEl) textEl.innerHTML = `<strong>FB Cleaner:</strong> ${statusText}`;
    if (dotEl) {
      dotEl.className = 'fb-cleaner-badge-dot ' + stateClass;
    }
  }

  function detectPageType() {
    const url = window.location.href;
    if (url.includes('test-fb-mock.html')) return 'mock_test_page';
    if (url.includes('business.facebook.com')) return 'meta_business_suite';
    if (url.includes('creatorstudio')) return 'creator_studio';
    if (url.includes('facebook.com')) return 'facebook_web';
    return 'generic_web';
  }

  const sleep = (ms) => new Promise(res => setTimeout(res, ms));

  function hashCode(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      hash = ((hash << 5) - hash) + str.charCodeAt(i);
      hash |= 0;
    }
    return hash;
  }

  // Detect and extract ALL POST TYPES from the DOM (Videos, Reels, Photos, Text Posts)
  function extractPostsFromDom() {
    const results = [];
    const pageType = detectPageType();

    // 1. Mock page support
    if (pageType === 'mock_test_page') {
      const mockCards = document.querySelectorAll('.mock-fb-card, [data-mock-post], [data-mock-video]');
      mockCards.forEach((card, idx) => {
        const id = card.getAttribute('data-id') || `mock_item_${idx}`;
        const title = card.querySelector('.mock-title, h3, h4')?.textContent?.trim() || `Post #${idx + 1}`;
        const thumbnail = card.querySelector('img')?.src || '';
        const timestamp = card.querySelector('.mock-date, time')?.textContent?.trim() || 'Recently';
        const type = card.getAttribute('data-type') || 'video';

        card.setAttribute('data-cleaner-id', id);
        discoveredPostElements.set(id, card);

        results.push({
          id,
          title,
          type,
          url: window.location.href + '#' + id,
          thumbnail,
          timestamp
        });
      });
      return results;
    }

    // 2. Facebook Standard & Meta Business Suite
    const seenIds = new Set();

    // Step A: Find all post articles on page
    const postArticles = document.querySelectorAll(
      'div[role="article"], div[data-pagelet*="FeedUnit"], div[data-pagelet*="ProfileTilesFeed"] > div, div[role="row"]'
    );

    postArticles.forEach((article, idx) => {
      // Avoid nested articles
      if (article.closest('div[role="article"]') && article.closest('div[role="article"]') !== article) {
        return;
      }

      // Determine Post Type & URL
      let type = 'post';
      let postUrl = '';
      let postId = '';

      // Check for Video
      const videoAnchor = article.querySelector('a[href*="/watch/?v="], a[href*="/videos/"], a[href*="/watch/"]');
      const reelAnchor = article.querySelector('a[href*="/reel/"]');
      const photoAnchor = article.querySelector('a[href*="/photo/"], a[href*="/photos/"], a[href*="fbid="]');
      const postAnchor = article.querySelector('a[href*="/posts/"], a[href*="/permalink.php"]');

      if (videoAnchor) {
        type = 'video';
        postUrl = videoAnchor.href;
      } else if (reelAnchor) {
        type = 'reel';
        postUrl = reelAnchor.href;
      } else if (photoAnchor) {
        type = 'photo';
        postUrl = photoAnchor.href;
      } else if (postAnchor) {
        type = 'post';
        postUrl = postAnchor.href;
      }

      // Extract Post ID from URL
      if (postUrl) {
        const idMatch = postUrl.match(/(?:videos|watch\/\?v=|reel|posts|photos|fbid=|\/p\/)([0-9]+)/i);
        if (idMatch && idMatch[1]) {
          postId = idMatch[1];
        }
      }

      if (!postId) {
        postId = article.id || 'fb_post_' + Math.abs(hashCode(article.innerText.slice(0, 70)));
      }

      if (seenIds.has(postId)) return;
      seenIds.add(postId);

      article.setAttribute('data-cleaner-id', postId);
      discoveredPostElements.set(postId, article);

      // Extract title / text content
      let title = '';
      const textContainers = article.querySelectorAll('div[dir="auto"], span[dir="auto"], h2, h3, h4');
      for (const t of textContainers) {
        const str = t.textContent.trim();
        if (str && str.length > 5 && !str.includes('Follow') && !str.includes('Like') && !str.includes('Share') && !str.includes('Comment')) {
          title = str.slice(0, 110);
          break;
        }
      }
      if (!title) {
        title = `Facebook ${type.toUpperCase()} Post (${postId})`;
      }

      // Extract thumbnail / image preview
      const img = article.querySelector('img[src*="fbcdn"], img[src*="scontent"], img');
      const thumbnail = img ? img.src : '';

      // Extract date / timestamp
      const timeEl = article.querySelector('abbr, time, span[id*="jsc"]');
      const timestamp = timeEl ? timeEl.textContent.trim() : '';

      results.push({
        id: postId,
        title,
        type,
        url: postUrl || window.location.href,
        thumbnail,
        timestamp: timestamp || 'Recently'
      });
    });

    return results;
  }

  // Auto-scroll loop to discover posts down the feed
  async function runAutoScan(maxScrolls = 30) {
    isScanningActive = true;
    scanScrollCount = 0;
    updateHud('Scanning all posts...', 'busy');

    let previousHeight = 0;
    let consecutiveSameHeights = 0;

    while (isScanningActive && scanScrollCount < maxScrolls) {
      const posts = extractPostsFromDom();
      if (posts.length > 0) {
        chrome.runtime.sendMessage({
          action: 'POSTS_DISCOVERED',
          posts
        });
      }

      window.scrollBy({
        top: window.innerHeight * 0.9,
        behavior: 'smooth'
      });
      scanScrollCount++;

      updateHud(`Scanning (${posts.length} found, scroll ${scanScrollCount}/${maxScrolls})...`, 'busy');
      await sleep(1600);

      const currentHeight = document.body.scrollHeight;
      if (currentHeight === previousHeight) {
        consecutiveSameHeights++;
        if (consecutiveSameHeights >= 3) break;
      } else {
        consecutiveSameHeights = 0;
        previousHeight = currentHeight;
      }
    }

    const finalPosts = extractPostsFromDom();
    chrome.runtime.sendMessage({
      action: 'POSTS_DISCOVERED',
      posts: finalPosts
    });

    isScanningActive = false;
    updateHud(`Scan Complete (${finalPosts.length} posts found)`, '');
    chrome.runtime.sendMessage({ action: 'SCAN_FINISHED' });
  }

  // Scroll down one batch for continuous auto-pilot
  async function scrollForNextBatch() {
    window.scrollBy({
      top: window.innerHeight * 1.2,
      behavior: 'smooth'
    });
    await sleep(2000);
    const newPosts = extractPostsFromDom();
    return newPosts;
  }

  // Automated Deletion of any Facebook post
  async function deletePostItem(post, dryRun = false) {
    updateHud(`Deleting "${post.title.slice(0, 25)}..."`, 'deleting');

    // 1. Locate DOM element
    let card = discoveredPostElements.get(post.id) ||
               document.querySelector(`[data-cleaner-id="${post.id}"]`) ||
               document.querySelector(`[data-id="${post.id}"]`);

    if (!card) {
      extractPostsFromDom();
      card = discoveredPostElements.get(post.id) || document.querySelector(`[data-cleaner-id="${post.id}"]`);
    }

    if (!card) {
      return { success: false, error: 'Post element not found in DOM.' };
    }

    // Scroll into view & highlight
    card.scrollIntoView({ behavior: 'smooth', block: 'center' });
    card.classList.add('fb-cleaner-target-highlight');
    await sleep(800);

    // If DRY RUN: simulation
    if (dryRun) {
      await sleep(1400);
      card.style.opacity = '0.4';
      card.style.filter = 'grayscale(100%)';
      card.classList.remove('fb-cleaner-target-highlight');
      updateHud('Dry-run deletion simulated', '');
      return { success: true, simulated: true };
    }

    // Mock page deletion shortcut
    if (detectPageType() === 'mock_test_page') {
      const mockDelBtn = card.querySelector('.mock-delete-btn, button.delete-btn, .mock-menu-btn');
      if (mockDelBtn) {
        mockDelBtn.click();
        await sleep(400);
        const delItem = card.querySelector('.mock-del-item') || document.querySelector('.mock-del-item');
        if (delItem) delItem.click();
        await sleep(400);
        const confirmBtn = document.querySelector('.mock-confirm-delete, #confirm-delete-modal-btn');
        if (confirmBtn) confirmBtn.click();
      } else {
        card.remove();
      }
      await sleep(600);
      card.classList.remove('fb-cleaner-target-highlight');
      updateHud('Post deleted (Mock)', '');
      return { success: true };
    }

    // REAL FACEBOOK POST DELETION WORKFLOW
    try {
      // Step A: Find 3-dots / action menu button
      const menuButtonSelectors = [
        'div[aria-label="Actions for this post"]',
        'div[aria-label="More"]',
        'div[aria-label="More options"]',
        'div[aria-haspopup="menu"]',
        'div[role="button"][aria-expanded="false"]',
        'div[aria-label*="Action"]',
        'button[aria-label*="More"]'
      ];

      let menuBtn = null;
      for (const sel of menuButtonSelectors) {
        menuBtn = card.querySelector(sel);
        if (menuBtn) break;
      }

      if (!menuBtn) {
        const allButtons = card.querySelectorAll('div[role="button"], button');
        for (const b of allButtons) {
          const aria = (b.getAttribute('aria-label') || '').toLowerCase();
          if (aria.includes('action') || aria.includes('more') || aria.includes('post options')) {
            menuBtn = b;
            break;
          }
        }
      }

      if (!menuBtn) {
        card.classList.remove('fb-cleaner-target-highlight');
        return { success: false, error: 'Could not find 3-dots menu on this post.' };
      }

      menuBtn.click();
      await sleep(1200);

      // Step B: Look for menu dropdown item: "Move to trash", "Delete post", "Delete video", etc.
      const deleteKeywords = [
        'move to trash',
        'move to your trash',
        'delete post',
        'delete video',
        'delete reel',
        'delete photo',
        'delete',
        'trash',
        'remove'
      ];

      let deleteMenuItem = null;
      const menuContainers = document.querySelectorAll('div[role="menu"], div[role="dialog"], div[data-pagelet="root"]');
      for (const container of menuContainers) {
        const items = container.querySelectorAll('div[role="menuitem"], div[role="button"], span');
        for (const it of items) {
          const text = it.textContent.trim().toLowerCase();
          if (deleteKeywords.some(kw => text.includes(kw))) {
            deleteMenuItem = it.closest('div[role="menuitem"]') || it.closest('div[role="button"]') || it;
            break;
          }
        }
        if (deleteMenuItem) break;
      }

      if (!deleteMenuItem) {
        document.body.click();
        card.classList.remove('fb-cleaner-target-highlight');
        return { success: false, error: 'Delete/Trash option not found in menu.' };
      }

      deleteMenuItem.click();
      await sleep(1400);

      // Step C: Confirm modal dialog
      const confirmKeywords = ['move', 'delete', 'confirm', 'move to trash'];
      let confirmBtn = null;
      
      const dialogs = document.querySelectorAll('div[role="dialog"]');
      for (const dia of dialogs) {
        const btns = dia.querySelectorAll('div[role="button"], button');
        for (const b of btns) {
          const text = b.textContent.trim().toLowerCase();
          const aria = (b.getAttribute('aria-label') || '').toLowerCase();
          if (confirmKeywords.some(kw => text === kw || aria === kw || text.includes('move to trash') || text.includes('delete'))) {
            confirmBtn = b;
            break;
          }
        }
        if (confirmBtn) break;
      }

      if (confirmBtn) {
        confirmBtn.click();
        await sleep(1600);
      }

      // Step D: Verify removal
      card.classList.remove('fb-cleaner-target-highlight');
      card.style.opacity = '0.3';
      card.style.pointerEvents = 'none';

      updateHud('Post deleted!', '');
      return { success: true };
    } catch (err) {
      card.classList.remove('fb-cleaner-target-highlight');
      return { success: false, error: err.message };
    }
  }

  // Runtime message listener
  chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
    switch (req.action) {
      case 'PING':
        initHud();
        sendResponse({
          success: true,
          pageType: detectPageType(),
          url: window.location.href,
          title: document.title
        });
        break;

      case 'START_SCAN_DOM':
        initHud();
        runAutoScan(req.maxScrolls || 30);
        sendResponse({ success: true });
        break;

      case 'STOP_SCAN_DOM':
        isScanningActive = false;
        updateHud('Scan stopped', '');
        sendResponse({ success: true });
        break;

      case 'FETCH_AND_SCROLL_NEXT':
        scrollForNextBatch().then(posts => {
          sendResponse({ success: true, posts });
        });
        return true;

      case 'DELETE_POST_DOM':
      case 'DELETE_VIDEO_DOM':
        deletePostItem(req.post || req.video, req.dryRun).then(res => {
          sendResponse(res);
        });
        return true; // async reply

      default:
        sendResponse({ success: false, message: 'Unknown action' });
    }
    return true;
  });

  initHud();
})();
