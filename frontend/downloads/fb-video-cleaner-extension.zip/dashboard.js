/**
 * FB Page Video Cleaner - Live Dashboard Controller
 * Real-time state synchronization, DOM updates, event handling, and multilingual support
 */

// Multilingual Dictionary: English & Roman Urdu
const I18N = {
  en: {
    connect_tab: "Connect FB Tab",
    connecting: "Connecting...",
    not_connected: "No Facebook Page Tab Connected",
    connected_to: "Connected to Page",
    safety_delay: "Safety Cooldown Delay:",
    delay_hint: "Recommended: 3s-6s to prevent Facebook rate limit or action block.",
    dry_run_title: "Dry-Run Simulation Mode",
    dry_run_hint: "Simulates the process without actually deleting any videos.",
    stop_on_err_title: "Stop on First Error",
    stop_on_err_hint: "Halts deletion queue if Facebook fails to delete an item.",
    stat_scanned: "Total Videos Scanned",
    stat_total_sub: "Found on active FB page",
    stat_deleted: "Successfully Deleted",
    stat_pending: "Pending In Queue",
    stat_pending_sub: "Ready to delete",
    stat_failed: "Failed / Skipped",
    stat_failed_sub: "Check terminal logs",
    ready_to_start: "Status: Ready to start",
    fetch_videos_btn: "Scan & Fetch Videos",
    stop_scan_btn: "Stop Scanning",
    start_delete_btn: "Auto-Delete All Videos",
    pause_btn: "Pause",
    resume_btn: "Resume",
    stop_btn: "Abort",
    clear_list: "Clear List",
    video_queue_title: "Videos Feed",
    tab_all: "All",
    tab_pending: "Pending",
    tab_deleted: "Deleted",
    tab_failed: "Failed",
    select_all: "Select All",
    delete_selected: "Delete Selected",
    no_videos_yet: "No Videos Fetched Yet",
    no_videos_desc: "Open your Facebook Page or Meta Business Suite in a tab, then click 'Scan & Fetch Videos'.",
    terminal_title: "Live Activity Terminal",
    auto_scroll: "Auto-scroll",
    confirm_modal_title: "Confirm Video Deletion",
    confirm_modal_body: "Are you sure you want to delete these video posts from your Facebook page? This action cannot be undone!",
    videos_to_delete: "Videos to Delete:",
    mode_label: "Mode:",
    cooldown_label: "Safety Delay:",
    cancel_btn: "Cancel",
    confirm_delete_btn: "Yes, Delete Videos",
    simulated_deletion: "Simulation (Dry Run)",
    real_deletion: "PERMANENT DELETION",
    status_scanning: "Status: Scanning Facebook Page DOM...",
    status_deleting: "Status: Deleting videos in queue...",
    status_paused: "Status: Deletion paused by user",
    status_completed: "Status: All videos processed!"
  },
  ur: {
    connect_tab: "FB Page Connect Karein",
    connecting: "Connecting...",
    not_connected: "Koi Facebook Page open nahi mila",
    connected_to: "Page se Connect hai",
    safety_delay: "Safety Cooldown Delay (Waqfa):",
    delay_hint: "Facebook block se bachne ke liye 3s-6s lazmi rakhein.",
    dry_run_title: "Dry-Run Simulation (Testing Mode)",
    dry_run_hint: "Is se videos delete nahi hongi, sirf test hoga.",
    stop_on_err_title: "Pehle Error par Stop Karein",
    stop_on_err_hint: "Agar koi video delete na ho sake to queue ruk jaye gi.",
    stat_scanned: "Kul Videos Scanned",
    stat_total_sub: "Open page se mili videos",
    stat_deleted: "Kamiyabi se Deleted",
    stat_pending: "Baqi Pending Videos",
    stat_pending_sub: "Delete hone ke liye ready",
    stat_failed: "Failed / Skipped",
    stat_failed_sub: "Terminal logs check karein",
    ready_to_start: "Status: Tayyar hai",
    fetch_videos_btn: "Videos Scan & Fetch Karein",
    stop_scan_btn: "Scanning Rokein",
    start_delete_btn: "Tamam Videos Auto-Delete Karein",
    pause_btn: "Waqfa (Pause)",
    resume_btn: "Dobara Shuru (Resume)",
    stop_btn: "Cancel (Abort)",
    clear_list: "List Saaf Karein",
    video_queue_title: "Videos Feed",
    tab_all: "Sab (All)",
    tab_pending: "Baqi (Pending)",
    tab_deleted: "Deleted",
    tab_failed: "Failed",
    select_all: "Sab Select Karein",
    delete_selected: "Selected Delete Karein",
    no_videos_yet: "Abhi koi video fetch nahi hui",
    no_videos_desc: "Apne Facebook Page ya Meta Business Suite ko open karein, phir 'Videos Scan & Fetch Karein' dabayein.",
    terminal_title: "Live Activity Terminal",
    auto_scroll: "Auto-scroll",
    confirm_modal_title: "Video Deletion ki Tasdeeq",
    confirm_modal_body: "Kya aap waqai Facebook page se tamam selected videos delete karna chahte hain? Yeh action wapas nahi ho sakta!",
    videos_to_delete: "Delete hone wali videos:",
    mode_label: "Tariqa (Mode):",
    cooldown_label: "Waqfa (Delay):",
    cancel_btn: "Cancel Karein",
    confirm_delete_btn: "Haan, Videos Delete Karein",
    simulated_deletion: "Testing Simulation (No Real Delete)",
    real_deletion: "PERMANENT DELETE (Asal Deletion)",
    status_scanning: "Status: Facebook Page videos dhoondi ja rahi hain...",
    status_deleting: "Status: Videos delete ki ja rahi hain...",
    status_paused: "Status: Deletion roki gayi hai (Paused)",
    status_completed: "Status: Tamam videos process ho chuki hain!"
  }
};

let currentLang = 'ur'; // Default to Roman Urdu / bilingual
let currentFilter = 'all';
let searchQuery = '';
let selectedVideoIds = new Set();

let localState = {
  isConnected: false,
  pageTitle: '',
  pageUrl: '',
  isScanning: false,
  isDeleting: false,
  isPaused: false,
  dryRun: false,
  delaySeconds: 4,
  stopOnError: false,
  videos: [],
  logs: [],
  stats: { totalFound: 0, deleted: 0, pending: 0, failed: 0 }
};

// UI Elements
const els = {
  connPill: document.getElementById('conn-pill'),
  connIndicator: document.getElementById('conn-indicator'),
  connTitle: document.getElementById('conn-title'),
  connUrl: document.getElementById('conn-url'),
  btnReconnect: document.getElementById('btn-reconnect'),

  settingsPanel: document.getElementById('settings-panel'),
  btnToggleSettings: document.getElementById('btn-toggle-settings'),
  delayRange: document.getElementById('delay-range'),
  delayVal: document.getElementById('delay-value'),
  toggleDryRun: document.getElementById('toggle-dry-run'),
  toggleStopErr: document.getElementById('toggle-stop-err'),

  statTotal: document.getElementById('stat-total'),
  statDeleted: document.getElementById('stat-deleted'),
  statDeletedPct: document.getElementById('stat-deleted-pct'),
  statPending: document.getElementById('stat-pending'),
  statFailed: document.getElementById('stat-failed'),

  progressStatus: document.getElementById('progress-status-text'),
  progressPercent: document.getElementById('progress-percent'),
  progressBarFill: document.getElementById('progress-bar-fill'),

  btnScan: document.getElementById('btn-scan'),
  btnStopScan: document.getElementById('btn-stop-scan'),
  btnStartDelete: document.getElementById('btn-start-delete'),
  btnPauseDelete: document.getElementById('btn-pause-delete'),
  btnResumeDelete: document.getElementById('btn-resume-delete'),
  btnStopDelete: document.getElementById('btn-stop-delete'),
  btnClearAll: document.getElementById('btnClearAll') || document.getElementById('btn-clear-all'),

  videoListContainer: document.getElementById('video-list-container'),
  videoCountBadge: document.getElementById('video-count-badge'),
  searchInput: document.getElementById('video-search-input'),
  tabBtns: document.querySelectorAll('.tab-btn'),
  selectAllCheckbox: document.getElementById('select-all-checkbox'),
  btnDeleteSelected: document.getElementById('btn-delete-selected'),

  terminalLogs: document.getElementById('terminal-logs'),
  autoscrollToggle: document.getElementById('term-autoscroll-toggle'),
  btnClearLogs: document.getElementById('btn-clear-logs'),

  confirmModal: document.getElementById('confirm-modal'),
  confirmModalMsg: document.getElementById('confirm-modal-msg'),
  modalVideoCount: document.getElementById('modal-video-count'),
  modalModeLabel: document.getElementById('modal-mode-label'),
  modalCooldownLabel: document.getElementById('modal-cooldown-label'),
  btnModalCancel: document.getElementById('btn-modal-cancel'),
  btnModalConfirm: document.getElementById('btn-modal-confirm'),

  langEn: document.getElementById('lang-en'),
  langUr: document.getElementById('lang-ur')
};

// Apply Language
function setLanguage(lang) {
  currentLang = lang;
  els.langEn.classList.toggle('active', lang === 'en');
  els.langUr.classList.toggle('active', lang === 'ur');

  const dict = I18N[lang];
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    if (dict[key]) {
      el.textContent = dict[key];
    }
  });

  updateConnectionUI();
  updateProgressUI();
}

// Update Connection Indicator
function updateConnectionUI() {
  const dict = I18N[currentLang];
  if (localState.isConnected) {
    els.connIndicator.className = 'pulse-indicator connected';
    els.connTitle.textContent = dict.connected_to + ': ' + (localState.pageTitle || 'Facebook Page');
    els.connUrl.textContent = localState.pageUrl || '';
  } else {
    els.connIndicator.className = 'pulse-indicator';
    els.connTitle.textContent = dict.not_connected;
    els.connUrl.textContent = 'Click "Connect FB Tab" when ready';
  }
}

// Update Stats Cards
function updateStatsUI() {
  const s = localState.stats || { totalFound: 0, deleted: 0, pending: 0, failed: 0 };
  els.statTotal.textContent = s.totalFound.toLocaleString();
  els.statDeleted.textContent = s.deleted.toLocaleString();
  els.statPending.textContent = s.pending.toLocaleString();
  els.statFailed.textContent = s.failed.toLocaleString();

  const pct = s.totalFound > 0 ? Math.round((s.deleted / s.totalFound) * 100) : 0;
  els.statDeletedPct.textContent = `${pct}% of total`;
  els.videoCountBadge.textContent = `${localState.videos.length} Items`;
}

// Update Progress Bar
function updateProgressUI() {
  const dict = I18N[currentLang];
  const s = localState.stats;
  const pct = s.totalFound > 0 ? Math.round(((s.deleted + s.failed) / s.totalFound) * 100) : 0;

  els.progressPercent.textContent = `${pct}%`;
  els.progressBarFill.style.width = `${pct}%`;

  if (localState.isDeleting) {
    els.progressStatus.textContent = localState.isPaused ? dict.status_paused : dict.status_deleting;
  } else if (localState.isScanning) {
    els.progressStatus.textContent = dict.status_scanning;
  } else if (s.totalFound > 0 && s.pending === 0) {
    els.progressStatus.textContent = dict.status_completed;
  } else {
    els.progressStatus.textContent = dict.ready_to_start;
  }
}

// Update Control Buttons (Start/Stop/Pause/Resume)
function updateControlsUI() {
  if (localState.isScanning) {
    els.btnScan.classList.add('hidden');
    els.btnStopScan.classList.remove('hidden');
  } else {
    els.btnScan.classList.remove('hidden');
    els.btnStopScan.classList.add('hidden');
  }

  if (localState.isDeleting) {
    els.btnStartDelete.classList.add('hidden');
    els.btnStopDelete.classList.remove('hidden');
    if (localState.isPaused) {
      els.btnPauseDelete.classList.add('hidden');
      els.btnResumeDelete.classList.remove('hidden');
    } else {
      els.btnPauseDelete.classList.remove('hidden');
      els.btnResumeDelete.classList.add('hidden');
    }
  } else {
    els.btnStartDelete.classList.remove('hidden');
    els.btnStopDelete.classList.add('hidden');
    els.btnPauseDelete.classList.add('hidden');
    els.btnResumeDelete.classList.add('hidden');
  }

  // Update Settings fields
  els.delayRange.value = localState.delaySeconds || 4;
  els.delayVal.textContent = (localState.delaySeconds || 4) + 's';
  els.toggleDryRun.checked = !!localState.dryRun;
  els.toggleStopErr.checked = !!localState.stopOnError;
}

// Render Videos Feed List
function renderVideoList() {
  const container = els.videoListContainer;
  const dict = I18N[currentLang];

  // Filter videos
  let list = localState.videos || [];
  if (currentFilter !== 'all') {
    list = list.filter(v => v.status === currentFilter);
  }
  if (searchQuery.trim()) {
    const q = searchQuery.toLowerCase();
    list = list.filter(v => (v.title && v.title.toLowerCase().includes(q)) || (v.id && v.id.toLowerCase().includes(q)));
  }

  if (list.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">
          <svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
        </div>
        <h3>${currentFilter === 'all' ? dict.no_videos_yet : 'No ' + currentFilter + ' videos'}</h3>
        <p>${dict.no_videos_desc}</p>
      </div>
    `;
    return;
  }

  container.innerHTML = '';
  list.forEach(v => {
    const row = document.createElement('div');
    row.className = `video-row is-${v.status}`;
    row.setAttribute('data-id', v.id);

    const isChecked = selectedVideoIds.has(v.id);
    const thumbHtml = v.thumbnail 
      ? `<img src="${v.thumbnail}" alt="thumb" onerror="this.style.display='none'">` 
      : `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>`;

    row.innerHTML = `
      <label class="checkbox-label" style="margin-right: 2px;">
        <input type="checkbox" class="video-item-check" data-id="${v.id}" ${isChecked ? 'checked' : ''}>
      </label>
      <div class="video-thumb">${thumbHtml}</div>
      <div class="video-info">
        <div class="video-title" title="${escapeHtml(v.title || v.id)}">
          <a href="${v.url || '#'}" target="_blank">${escapeHtml(v.title || 'Video #' + v.id)}</a>
        </div>
        <div class="video-meta">
          <span>ID: ${v.id}</span>
          ${v.timestamp ? `<span>📅 ${v.timestamp}</span>` : ''}
          ${v.deletedAt ? `<span>🗑️ Deleted at ${v.deletedAt}</span>` : ''}
          ${v.error ? `<span style="color: #f87171;" title="${escapeHtml(v.error)}">⚠️ ${escapeHtml(v.error.slice(0, 30))}...</span>` : ''}
        </div>
      </div>
      <div class="status-badge badge-${v.status}">${v.status}</div>
      <div class="video-actions">
        ${v.status === 'pending' ? `
          <button class="btn btn-xs btn-outline btn-single-delete" data-id="${v.id}" title="Delete this video now">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"></path></svg>
            Delete
          </button>
        ` : ''}
      </div>
    `;

    // Row event listeners
    const checkEl = row.querySelector('.video-item-check');
    checkEl.addEventListener('change', (e) => {
      if (e.target.checked) selectedVideoIds.add(v.id);
      else selectedVideoIds.delete(v.id);
      updateBatchUI();
    });

    const singleDelBtn = row.querySelector('.btn-single-delete');
    if (singleDelBtn) {
      singleDelBtn.addEventListener('click', () => {
        deleteSingleVideo(v.id);
      });
    }

    container.appendChild(row);
  });
}

function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function updateBatchUI() {
  const count = selectedVideoIds.size;
  els.btnDeleteSelected.disabled = count === 0;
  els.btnDeleteSelected.textContent = `${I18N[currentLang].delete_selected} (${count})`;
  
  const allChecks = document.querySelectorAll('.video-item-check');
  if (allChecks.length > 0) {
    els.selectAllCheckbox.checked = count === allChecks.length && count > 0;
  }
}

// Terminal Logging UI
function appendLogToTerminal(log) {
  const line = document.createElement('div');
  line.className = `log-line log-${log.level || 'info'}`;
  
  let tagClass = 'tag-info';
  if (log.level === 'success') tagClass = 'tag-success';
  else if (log.level === 'warn') tagClass = 'tag-warn';
  else if (log.level === 'error') tagClass = 'tag-error';

  line.innerHTML = `
    <span class="log-time">[${log.timestamp || new Date().toLocaleTimeString()}]</span>
    <span class="log-tag ${tagClass}">${(log.level || 'INFO').toUpperCase()}</span>
    <span class="log-msg">${escapeHtml(log.message)}</span>
  `;

  // Insert at top of reverse column or prepend
  els.terminalLogs.prepend(line);

  // Keep terminal capped at 200 elements in DOM
  if (els.terminalLogs.children.length > 200) {
    els.terminalLogs.lastElementChild.remove();
  }

  if (els.autoscrollToggle.checked) {
    els.terminalLogs.scrollTop = 0;
  }
}

function renderLogs(logs) {
  els.terminalLogs.innerHTML = '';
  if (!logs || logs.length === 0) return;
  // Logs are in descending order
  logs.slice(0, 150).forEach(log => {
    appendLogToTerminal(log);
  });
}

// Full State Sync
function applyState(newState) {
  localState = { ...localState, ...newState };
  updateConnectionUI();
  updateStatsUI();
  updateProgressUI();
  updateControlsUI();
  renderVideoList();
  updateBatchUI();
}

// Check if running inside extension or direct web preview
const isExtensionEnv = typeof chrome !== 'undefined' && chrome.runtime && !!chrome.runtime.id;

// Network Calls to background service worker (with preview mock fallback)
function fetchInitialState() {
  if (isExtensionEnv) {
    chrome.runtime.sendMessage({ action: 'GET_STATE' }, res => {
      if (res && res.success && res.state) {
        applyState(res.state);
        renderLogs(res.state.logs);
      }
    });
  } else {
    // Standalone Browser Preview Mode - Load rich sample data
    console.log('[Preview Mode] Running outside Chrome Extension context. Loading preview demo state...');
    const demoVideos = [
      { id: '1000847291', title: 'Top 10 Unreal Engine 5 Graphics Showcases 2026', url: 'https://facebook.com/watch/?v=1000847291', timestamp: '1 day ago', status: 'pending', thumbnail: '' },
      { id: '1000847292', title: 'Building a Quantum AI Agent in 15 Minutes Live Stream', url: 'https://facebook.com/watch/?v=1000847292', timestamp: '2 days ago', status: 'deleted', deletedAt: '10:14 PM', thumbnail: '' },
      { id: '1000847293', title: 'Gameplay Highlights: Championship Finals Match 3', url: 'https://facebook.com/watch/?v=1000847293', timestamp: '3 days ago', status: 'pending', thumbnail: '' },
      { id: '1000847294', title: 'Full Guide: How to Setup Dual PC Streaming Rig', url: 'https://facebook.com/watch/?v=1000847294', timestamp: '4 days ago', status: 'deleted', deletedAt: '10:18 PM', thumbnail: '' },
      { id: '1000847295', title: 'Podcast Episode #45: The Future of Autonomous Coding', url: 'https://facebook.com/watch/?v=1000847295', timestamp: '5 days ago', status: 'failed', error: 'Action blocked by FB temporary rate limit', thumbnail: '' }
    ];

    const demoState = {
      isConnected: true,
      pageTitle: 'Tech & Gaming Page Official (Facebook)',
      pageUrl: 'https://facebook.com/gamingtech/videos',
      isScanning: false,
      isDeleting: false,
      isPaused: false,
      dryRun: false,
      delaySeconds: 4,
      stopOnError: false,
      videos: demoVideos,
      stats: { totalFound: 5, deleted: 2, pending: 2, failed: 1 },
      logs: [
        { id: '1', timestamp: '10:14:02 PM', level: 'info', message: 'Connected to active Facebook tab' },
        { id: '2', timestamp: '10:14:15 PM', level: 'info', message: 'DOM Scan complete: Found 5 videos' },
        { id: '3', timestamp: '10:14:22 PM', level: 'success', message: 'Successfully deleted: "Top 10 Unreal Engine 5"' },
        { id: '4', timestamp: '10:18:05 PM', level: 'warn', message: 'Waiting 4s safety cooldown between actions...' },
        { id: '5', timestamp: '10:18:10 PM', level: 'error', message: 'Failed to delete #1000847295: Rate limit check' }
      ]
    };

    applyState(demoState);
    renderLogs(demoState.logs);
  }
}

function connectActiveTab() {
  els.connTitle.textContent = I18N[currentLang].connecting;
  if (isExtensionEnv) {
    chrome.runtime.sendMessage({ action: 'CONNECT_TAB' }, res => {
      if (res && res.success) {
        applyState(res.state);
      } else {
        localState.isConnected = false;
        updateConnectionUI();
        alert((res && res.message) || 'Could not find an open Facebook tab. Please open Facebook or Creator Studio in a browser tab first!');
      }
    });
  } else {
    setTimeout(() => {
      localState.isConnected = true;
      localState.pageTitle = 'Mock Facebook Page - Videos';
      localState.pageUrl = 'http://localhost:8765/test-fb-mock.html';
      updateConnectionUI();
      appendLogToTerminal({ timestamp: new Date().toLocaleTimeString(), level: 'success', message: 'Connected to http://localhost:8765/test-fb-mock.html' });
    }, 400);
  }
}

function startScanning() {
  if (isExtensionEnv) {
    chrome.runtime.sendMessage({ action: 'START_SCAN' }, res => {
      if (res && res.success) {
        localState.isScanning = true;
        updateControlsUI();
        updateProgressUI();
      } else {
        alert((res && res.message) || 'Failed to start scanning. Make sure a Facebook tab is open.');
      }
    });
  } else {
    localState.isScanning = true;
    updateControlsUI();
    updateProgressUI();
    appendLogToTerminal({ timestamp: new Date().toLocaleTimeString(), level: 'info', message: 'Scanning DOM for video items...' });
    setTimeout(() => {
      localState.isScanning = false;
      updateControlsUI();
      updateProgressUI();
      appendLogToTerminal({ timestamp: new Date().toLocaleTimeString(), level: 'success', message: 'Scan finished. All videos loaded into queue.' });
    }, 2000);
  }
}

function stopScanning() {
  if (isExtensionEnv) {
    chrome.runtime.sendMessage({ action: 'STOP_SCAN' });
  }
  localState.isScanning = false;
  updateControlsUI();
}

function triggerDeleteWorkflow(videoIds = null) {
  const dict = I18N[currentLang];
  const pendingTargets = videoIds 
    ? localState.videos.filter(v => videoIds.includes(v.id))
    : localState.videos.filter(v => v.status === 'pending');

  if (pendingTargets.length === 0) {
    alert('Koi pending video delete hone ke liye nahi mili!');
    return;
  }

  // Populate modal
  els.modalVideoCount.textContent = pendingTargets.length;
  els.modalModeLabel.textContent = localState.dryRun ? dict.simulated_deletion : dict.real_deletion;
  els.modalModeLabel.className = 'badge ' + (localState.dryRun ? 'badge-pending' : 'badge-failed');
  els.modalCooldownLabel.textContent = (localState.delaySeconds || 4) + 's';
  
  els.confirmModal.classList.remove('hidden');

  // Modal Confirm handler
  els.btnModalConfirm.onclick = () => {
    els.confirmModal.classList.add('hidden');
    if (isExtensionEnv) {
      chrome.runtime.sendMessage({
        action: 'START_DELETE',
        videoIds: videoIds
      }, res => {
        if (res && res.success) {
          localState.isDeleting = true;
          updateControlsUI();
        } else {
          alert(res.message || 'Failed to start deletion.');
        }
      });
    } else {
      // Simulation in preview
      localState.isDeleting = true;
      updateControlsUI();
      appendLogToTerminal({ timestamp: new Date().toLocaleTimeString(), level: 'warn', message: `Beginning deletion of ${pendingTargets.length} videos...` });
      
      let i = 0;
      const interval = setInterval(() => {
        if (i < pendingTargets.length && localState.isDeleting) {
          const v = pendingTargets[i];
          v.status = 'deleted';
          v.deletedAt = new Date().toLocaleTimeString();
          localState.stats.deleted++;
          localState.stats.pending = Math.max(0, localState.stats.pending - 1);
          updateStatsUI();
          updateProgressUI();
          renderVideoList();
          appendLogToTerminal({ timestamp: v.deletedAt, level: 'success', message: `Deleted video: "${v.title}"` });
          i++;
        } else {
          clearInterval(interval);
          localState.isDeleting = false;
          updateControlsUI();
          updateProgressUI();
          appendLogToTerminal({ timestamp: new Date().toLocaleTimeString(), level: 'success', message: 'All pending videos processed!' });
        }
      }, (localState.delaySeconds || 2) * 1000);
    }
  };
}

function deleteSingleVideo(id) {
  if (isExtensionEnv) {
    chrome.runtime.sendMessage({ action: 'DELETE_SINGLE', videoId: id });
  } else {
    const v = localState.videos.find(x => x.id === id);
    if (v) {
      v.status = 'deleted';
      v.deletedAt = new Date().toLocaleTimeString();
      localState.stats.deleted++;
      localState.stats.pending = Math.max(0, localState.stats.pending - 1);
      updateStatsUI();
      updateProgressUI();
      renderVideoList();
      appendLogToTerminal({ timestamp: v.deletedAt, level: 'success', message: `Single video deleted: "${v.title}"` });
    }
  }
}

function updateSettings() {
  const delaySeconds = parseInt(els.delayRange.value, 10) || 4;
  const dryRun = els.toggleDryRun.checked;
  const stopOnError = els.toggleStopErr.checked;

  els.delayVal.textContent = delaySeconds + 's';
  localState.delaySeconds = delaySeconds;
  localState.dryRun = dryRun;
  localState.stopOnError = stopOnError;

  if (isExtensionEnv) {
    chrome.runtime.sendMessage({
      action: 'UPDATE_SETTINGS',
      delaySeconds,
      dryRun,
      stopOnError
    });
  }
}

// EVENT LISTENERS
function setupEventListeners() {
  els.btnReconnect.addEventListener('click', connectActiveTab);
  
  els.btnToggleSettings.addEventListener('click', () => {
    els.settingsPanel.classList.toggle('hidden');
  });

  els.delayRange.addEventListener('input', updateSettings);
  els.toggleDryRun.addEventListener('change', updateSettings);
  els.toggleStopErr.addEventListener('change', updateSettings);

  els.btnScan.addEventListener('click', startScanning);
  els.btnStopScan.addEventListener('click', stopScanning);

  const quickScanBtn = document.getElementById('btn-quick-scan');
  if (quickScanBtn) quickScanBtn.addEventListener('click', startScanning);

  els.btnStartDelete.addEventListener('click', () => triggerDeleteWorkflow(null));
  
  els.btnPauseDelete.addEventListener('click', () => {
    chrome.runtime.sendMessage({ action: 'PAUSE_DELETE' });
  });

  els.btnResumeDelete.addEventListener('click', () => {
    chrome.runtime.sendMessage({ action: 'RESUME_DELETE' });
  });

  els.btnStopDelete.addEventListener('click', () => {
    chrome.runtime.sendMessage({ action: 'STOP_DELETE' });
  });

  els.btnClearAll.addEventListener('click', () => {
    if (confirm('Kya aap tamam fetched videos ki list saaf karna chahte hain?')) {
      chrome.runtime.sendMessage({ action: 'CLEAR_VIDEOS' });
      selectedVideoIds.clear();
    }
  });

  els.btnClearLogs.addEventListener('click', () => {
    chrome.runtime.sendMessage({ action: 'CLEAR_LOGS' });
  });

  // Filter Tabs
  els.tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      els.tabBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentFilter = btn.getAttribute('data-filter');
      renderVideoList();
    });
  });

  // Search Input
  els.searchInput.addEventListener('input', (e) => {
    searchQuery = e.target.value;
    renderVideoList();
  });

  // Select All Checkbox
  els.selectAllCheckbox.addEventListener('change', (e) => {
    const isChecked = e.target.checked;
    const checks = document.querySelectorAll('.video-item-check');
    checks.forEach(c => {
      c.checked = isChecked;
      const id = c.getAttribute('data-id');
      if (isChecked) selectedVideoIds.add(id);
      else selectedVideoIds.delete(id);
    });
    updateBatchUI();
  });

  // Delete Selected Button
  els.btnDeleteSelected.addEventListener('click', () => {
    if (selectedVideoIds.size > 0) {
      triggerDeleteWorkflow(Array.from(selectedVideoIds));
    }
  });

  // Modal Cancel
  els.btnModalCancel.addEventListener('click', () => {
    els.confirmModal.classList.add('hidden');
  });

  // Language Switch
  els.langEn.addEventListener('click', () => setLanguage('en'));
  els.langUr.addEventListener('click', () => setLanguage('ur'));
}

// Chrome message listener for real-time broadcasts
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.action === 'STATE_UPDATED') {
    applyState(msg.state);
  } else if (msg.action === 'LOG_ADDED') {
    appendLogToTerminal(msg.log);
    if (msg.stats) {
      localState.stats = msg.stats;
      updateStatsUI();
      updateProgressUI();
    }
  }
});

// Initialization
document.addEventListener('DOMContentLoaded', () => {
  setupEventListeners();
  setLanguage(currentLang);
  fetchInitialState();

  // Try auto-connecting on load
  setTimeout(() => {
    connectActiveTab();
  }, 500);
});
