/**
 * FB Auto Post & Video Cleaner - Background Service Worker
 * Manages Side Panel opening, continuous Auto-Pilot loop, and deletion queues
 */

// Enable open side panel when clicking the extension icon
if (chrome.sidePanel && chrome.sidePanel.setPanelBehavior) {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
}

const DEFAULT_STATE = {
  activeTabId: null,
  pageUrl: '',
  pageTitle: '',
  isConnected: false,
  isScanning: false,
  isDeleting: false,
  isAutoPilot: false,
  isPaused: false,
  dryRun: false,
  delaySeconds: 4,
  stopOnError: false,
  posts: [], // all post items
  logs: [],
  stats: {
    totalFound: 0,
    deleted: 0,
    pending: 0,
    failed: 0
  }
};

let appState = { ...DEFAULT_STATE };
let deletionQueue = [];
let isQueueRunning = false;
let autoPilotActive = false;

// Load persisted state
chrome.storage.local.get(['appState'], (res) => {
  if (res.appState) {
    appState = {
      ...DEFAULT_STATE,
      ...res.appState,
      isScanning: false,
      isDeleting: false,
      isAutoPilot: false,
      isPaused: false
    };
  }
  updateBadge();
});

function saveState() {
  chrome.storage.local.set({ appState });
  updateBadge();
}

function addLog(level, message) {
  const timestamp = new Date().toLocaleTimeString();
  const logItem = {
    id: 'log_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
    timestamp,
    level,
    message
  };
  
  appState.logs.unshift(logItem);
  if (appState.logs.length > 500) appState.logs.pop();
  
  broadcast({ action: 'LOG_ADDED', log: logItem, stats: appState.stats });
  saveState();
}

function updateStats() {
  const total = appState.posts.length;
  const deleted = appState.posts.filter(p => p.status === 'deleted').length;
  const failed = appState.posts.filter(p => p.status === 'failed').length;
  const pending = appState.posts.filter(p => p.status === 'pending' || p.status === 'deleting').length;
  
  appState.stats = { totalFound: total, deleted, pending, failed };
  saveState();
}

function updateBadge() {
  if (appState.isAutoPilot) {
    chrome.action.setBadgeText({ text: 'AUTO' });
    chrome.action.setBadgeBackgroundColor({ color: '#8B5CF6' });
  } else if (appState.isDeleting) {
    chrome.action.setBadgeText({ text: 'DEL' });
    chrome.action.setBadgeBackgroundColor({ color: '#E53E3E' });
  } else if (appState.isScanning) {
    chrome.action.setBadgeText({ text: 'SCAN' });
    chrome.action.setBadgeBackgroundColor({ color: '#3182CE' });
  } else if (appState.stats.pending > 0) {
    chrome.action.setBadgeText({ text: String(appState.stats.pending) });
    chrome.action.setBadgeBackgroundColor({ color: '#ED8936' });
  } else {
    chrome.action.setBadgeText({ text: '' });
  }
}

function broadcast(msg) {
  chrome.runtime.sendMessage(msg).catch(() => {});
}

async function findFacebookTab() {
  const tabs = await chrome.tabs.query({});
  const fbTab = tabs.find(t => 
    t.url && (
      t.url.includes('facebook.com') ||
      t.url.includes('business.facebook.com') ||
      t.url.includes('test-fb-mock.html') ||
      t.url.includes('localhost') ||
      t.url.includes('127.0.0.1')
    )
  );
  return fbTab || null;
}

async function sendToContentScript(tabId, message) {
  try {
    return await chrome.tabs.sendMessage(tabId, message);
  } catch (err) {
    try {
      await chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] });
      await chrome.scripting.insertCSS({ target: { tabId }, files: ['content.css'] });
      return await chrome.tabs.sendMessage(tabId, message);
    } catch (injErr) {
      throw new Error('Cannot reach Facebook tab: ' + injErr.message);
    }
  }
}

// Continuous Auto-Pilot Loop: Fetch batch -> Delete batch -> Scroll next -> Repeat
async function runAutoPilotLoop() {
  if (autoPilotActive) return;
  autoPilotActive = true;
  appState.isAutoPilot = true;
  appState.isDeleting = true;
  appState.isPaused = false;
  saveState();
  addLog('warn', `⚡ AUTO-PILOT STARTED: Continuously fetching and deleting all posts! Dry Run: ${appState.dryRun ? 'YES' : 'NO'}`);
  broadcast({ action: 'STATE_UPDATED', state: appState });

  let consecutiveEmptyBatches = 0;

  while (appState.isAutoPilot && !appState.isPaused) {
    // 1. Process any pending items in queue
    let pendingPosts = appState.posts.filter(p => p.status === 'pending');
    
    // If no pending items, scroll down to fetch more
    if (pendingPosts.length === 0) {
      addLog('info', '[Auto-Pilot] Scrolling page to discover next batch of posts...');
      try {
        const scrollRes = await sendToContentScript(appState.activeTabId, { action: 'FETCH_AND_SCROLL_NEXT' });
        if (scrollRes && scrollRes.posts && scrollRes.posts.length > 0) {
          let added = 0;
          scrollRes.posts.forEach(p => {
            const exists = appState.posts.find(x => x.id === p.id);
            if (!exists) {
              appState.posts.push({ ...p, status: 'pending', deletedAt: null, error: null });
              added++;
            }
          });
          updateStats();
          if (added > 0) {
            consecutiveEmptyBatches = 0;
            addLog('info', `[Auto-Pilot] Discovered ${added} new post(s).`);
          } else {
            consecutiveEmptyBatches++;
          }
        } else {
          consecutiveEmptyBatches++;
        }
      } catch (e) {
        addLog('error', `[Auto-Pilot] Scroll error: ${e.message}`);
        consecutiveEmptyBatches++;
      }

      // Check if page ended
      if (consecutiveEmptyBatches >= 4) {
        addLog('success', '🎉 [Auto-Pilot] No more posts found after multiple scrolls. Page is clean!');
        break;
      }

      pendingPosts = appState.posts.filter(p => p.status === 'pending');
    }

    if (pendingPosts.length === 0) {
      await new Promise(r => setTimeout(r, 2000));
      continue;
    }

    // 2. Delete the next post
    const currentPost = pendingPosts[0];
    currentPost.status = 'deleting';
    updateStats();
    broadcast({ action: 'STATE_UPDATED', state: appState });
    addLog('info', `[Auto-Pilot] Deleting ${currentPost.type.toUpperCase()}: "${currentPost.title.slice(0, 35)}..."`);

    try {
      const delRes = await sendToContentScript(appState.activeTabId, {
        action: 'DELETE_POST_DOM',
        post: currentPost,
        dryRun: appState.dryRun
      });

      if (delRes && delRes.success) {
        currentPost.status = 'deleted';
        currentPost.deletedAt = new Date().toLocaleTimeString();
        addLog('success', `[Auto-Pilot] Deleted: "${currentPost.title.slice(0, 35)}"`);
      } else {
        currentPost.status = 'failed';
        currentPost.error = (delRes && delRes.error) || 'Failed to delete';
        addLog('error', `[Auto-Pilot] Failed: ${currentPost.error}`);

        if (appState.stopOnError) {
          addLog('warn', 'Stop on Error is active. Halting Auto-Pilot.');
          break;
        }
      }
    } catch (err) {
      currentPost.status = 'failed';
      currentPost.error = err.message;
      addLog('error', `[Auto-Pilot] Error: ${err.message}`);
      if (appState.stopOnError) break;
    }

    updateStats();
    broadcast({ action: 'STATE_UPDATED', state: appState });

    // Safety Delay
    const delayMs = (appState.delaySeconds || 4) * 1000;
    addLog('info', `Waiting ${appState.delaySeconds}s safety delay before next post...`);
    await new Promise(r => setTimeout(r, delayMs));
  }

  autoPilotActive = false;
  appState.isAutoPilot = false;
  appState.isDeleting = false;
  saveState();
  broadcast({ action: 'STATE_UPDATED', state: appState });
  addLog('info', 'Auto-Pilot finished or stopped.');
}

// Runtime Message Router
chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
  (async () => {
    switch (req.action) {
      case 'GET_STATE': {
        sendResponse({ success: true, state: appState });
        break;
      }

      case 'OPEN_DASHBOARD': {
        chrome.tabs.create({ url: chrome.runtime.getURL('dashboard.html') });
        sendResponse({ success: true });
        break;
      }

      case 'CONNECT_TAB': {
        try {
          const tab = req.tabId ? await chrome.tabs.get(req.tabId) : await findFacebookTab();
          if (!tab) {
            appState.isConnected = false;
            saveState();
            sendResponse({ success: false, message: 'No open Facebook tab found. Please open Facebook in a tab first!' });
            return;
          }

          appState.activeTabId = tab.id;
          appState.pageUrl = tab.url;
          appState.pageTitle = tab.title || 'Facebook Page';
          appState.isConnected = true;

          addLog('info', `Connected to: ${appState.pageTitle}`);
          saveState();
          sendResponse({ success: true, state: appState });
        } catch (e) {
          appState.isConnected = false;
          saveState();
          sendResponse({ success: false, message: e.message });
        }
        break;
      }

      case 'POSTS_DISCOVERED':
      case 'VIDEOS_DISCOVERED': {
        const incoming = req.posts || req.videos || [];
        let newCount = 0;
        incoming.forEach(p => {
          const exists = appState.posts.find(x => x.id === p.id);
          if (!exists) {
            appState.posts.push({
              ...p,
              type: p.type || 'video',
              status: 'pending',
              deletedAt: null,
              error: null
            });
            newCount++;
          }
        });

        updateStats();
        if (newCount > 0) {
          addLog('info', `Found ${newCount} new post(s). Total: ${appState.posts.length}`);
        }
        broadcast({ action: 'STATE_UPDATED', state: appState });
        sendResponse({ success: true, total: appState.posts.length });
        break;
      }

      case 'START_SCAN': {
        if (!appState.activeTabId) {
          const tab = await findFacebookTab();
          if (tab) appState.activeTabId = tab.id;
          else {
            sendResponse({ success: false, message: 'Please open Facebook in a browser tab first!' });
            return;
          }
        }
        appState.isScanning = true;
        saveState();
        addLog('info', 'Scanning Facebook page for all posts...');
        try {
          await sendToContentScript(appState.activeTabId, { action: 'START_SCAN_DOM' });
          sendResponse({ success: true });
        } catch (e) {
          appState.isScanning = false;
          saveState();
          addLog('error', `Scan failed: ${e.message}`);
          sendResponse({ success: false, message: e.message });
        }
        break;
      }

      case 'STOP_SCAN': {
        appState.isScanning = false;
        saveState();
        addLog('warn', 'Scan stopped.');
        if (appState.activeTabId) {
          sendToContentScript(appState.activeTabId, { action: 'STOP_SCAN_DOM' }).catch(() => {});
        }
        sendResponse({ success: true });
        break;
      }

      case 'START_AUTOPILOT': {
        if (!appState.activeTabId) {
          const tab = await findFacebookTab();
          if (tab) appState.activeTabId = tab.id;
          else {
            sendResponse({ success: false, message: 'No active Facebook tab connected.' });
            return;
          }
        }
        runAutoPilotLoop();
        sendResponse({ success: true });
        break;
      }

      case 'STOP_AUTOPILOT':
      case 'STOP_DELETE': {
        appState.isAutoPilot = false;
        appState.isDeleting = false;
        appState.isPaused = false;
        autoPilotActive = false;
        saveState();
        addLog('warn', 'Auto-Pilot / Deletion cancelled.');
        broadcast({ action: 'STATE_UPDATED', state: appState });
        sendResponse({ success: true });
        break;
      }

      case 'PAUSE_DELETE': {
        appState.isPaused = true;
        saveState();
        addLog('info', 'Auto-Pilot / Deletion paused.');
        broadcast({ action: 'STATE_UPDATED', state: appState });
        sendResponse({ success: true });
        break;
      }

      case 'RESUME_DELETE': {
        appState.isPaused = false;
        saveState();
        addLog('info', 'Auto-Pilot resumed.');
        broadcast({ action: 'STATE_UPDATED', state: appState });
        if (appState.isAutoPilot) {
          runAutoPilotLoop();
        }
        sendResponse({ success: true });
        break;
      }

      case 'DELETE_SINGLE': {
        const pId = req.postId || req.videoId;
        const post = appState.posts.find(p => p.id === pId);
        if (!post) {
          sendResponse({ success: false, message: 'Post not found.' });
          return;
        }

        if (!appState.activeTabId) {
          const tab = await findFacebookTab();
          if (tab) appState.activeTabId = tab.id;
          else {
            sendResponse({ success: false, message: 'No active FB tab.' });
            return;
          }
        }

        post.status = 'deleting';
        saveState();
        broadcast({ action: 'STATE_UPDATED', state: appState });
        addLog('info', `Deleting single post: "${post.title.slice(0, 30)}"...`);

        try {
          const delRes = await sendToContentScript(appState.activeTabId, {
            action: 'DELETE_POST_DOM',
            post,
            dryRun: appState.dryRun
          });

          if (delRes && delRes.success) {
            post.status = 'deleted';
            post.deletedAt = new Date().toLocaleTimeString();
            addLog('success', `Deleted: "${post.title.slice(0, 30)}"`);
          } else {
            post.status = 'failed';
            post.error = (delRes && delRes.error) || 'Failed to delete';
            addLog('error', `Failed: ${post.error}`);
          }
        } catch (e) {
          post.status = 'failed';
          post.error = e.message;
          addLog('error', `Error: ${e.message}`);
        }

        updateStats();
        broadcast({ action: 'STATE_UPDATED', state: appState });
        sendResponse({ success: post.status === 'deleted' });
        break;
      }

      case 'UPDATE_SETTINGS': {
        if (typeof req.delaySeconds === 'number') appState.delaySeconds = req.delaySeconds;
        if (typeof req.dryRun === 'boolean') appState.dryRun = req.dryRun;
        if (typeof req.stopOnError === 'boolean') appState.stopOnError = req.stopOnError;
        saveState();
        addLog('info', `Settings updated: Cooldown = ${appState.delaySeconds}s, Dry Run = ${appState.dryRun ? 'ON' : 'OFF'}`);
        broadcast({ action: 'STATE_UPDATED', state: appState });
        sendResponse({ success: true, state: appState });
        break;
      }

      case 'CLEAR_VIDEOS':
      case 'CLEAR_POSTS': {
        appState.posts = [];
        updateStats();
        addLog('info', 'Posts list cleared.');
        broadcast({ action: 'STATE_UPDATED', state: appState });
        sendResponse({ success: true });
        break;
      }

      case 'CLEAR_LOGS': {
        appState.logs = [];
        saveState();
        broadcast({ action: 'STATE_UPDATED', state: appState });
        sendResponse({ success: true });
        break;
      }

      default:
        sendResponse({ success: false, message: 'Unknown action' });
    }
  })();
  return true;
});
