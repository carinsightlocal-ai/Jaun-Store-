# FB Page Video Cleaner & Live Dashboard (Chrome Extension Manifest V3)

🚀 **Chrome Extension** jo aapke open Facebook Page / Meta Business Suite ya Creator Studio tab se connect ho kar tamam videos scan karta hai, unhein Live Dashboard me dikhata hai, aur unhein ek ek kar ke automatically delete karta jata hai.

---

## 🌟 Features

1. **Auto Facebook Connect**:
   - Open Facebook tab (`facebook.com/<page>/videos`, `business.facebook.com`) ko automatic detect karta hai.
   - Content Script inject ho kar DOM se videos fetch karta hai.
2. **Auto-Scroll & Video Fetching**:
   - Page ko scroll down kar ke saari purani aur nayi videos collect karta hai (Title, Thumbnail, Link, ID).
3. **Real-time Live Dashboard**:
   - **Live Counters**: Total Found, Deleted, Pending, Failed, Progress Bar (%).
   - **Terminal Logs**: Har action ka live timestamped log (`[INFO]`, `[SUCCESS]`, `[ERROR]`).
   - **Bilingual Interface**: Roman Urdu aur English me 1-click toggle switch.
4. **Safety & Throttling Engine**:
   - Adjustable cooldown delay (default 4 seconds, 1s se 15s tak adjustable) taake Facebook rate-limit ya action block na lagaye.
   - **Dry-Run Simulation Mode**: Test karne ke liye bina asal deletion ke live process preview karein.
   - **Stop on Error**: Agar koi issue aye to khud ba khud ruk jaye ga.
5. **Interactive Controls**:
   - Start All, Pause, Resume, Stop (Abort), Single Delete, Select All, Delete Selected.

---

## 📥 How to Install in Google Chrome (Kaise Load Karein)

1. Open **Google Chrome** browser.
2. Address bar me type karein: `chrome://extensions` aur Enter dabayein.
3. Top right corner me **Developer mode** toggle ko **ON** karein.
4. Top left par **Load unpacked** button par click karein.
5. Is folder ko select karein:
   `C:\Users\Jaun Khan\.gemini\antigravity-ide\scratch\fb-video-cleaner-extension`
6. Extension Chrome toolbar me add ho jaye gi! 🎉

---

## 🧪 How to Test Offline (Pehle Test Karein)

Extension ke sath ek offline mock Facebook page include hai:
1. Browser me open karein:
   `test-fb-mock.html` (Extension folder ke andar)
2. Extension icon par click karke **"Open Live Dashboard"** dabayein.
3. **"Scan & Fetch Videos"** click karein: 12 mock videos dashboard me show hon gi.
4. **"Auto-Delete All Videos"** click karein: Live terminal aur cards me live deletion dekhein!

---

## 💻 How to Use on Real Facebook Page (Asal Facebook Page par Istemaal)

1. Chrome me apna Facebook Page ya Meta Business Suite ka videos tab open karein:
   - Example: `https://www.facebook.com/YOUR_PAGE_NAME/videos/`
   - Ya Meta Business Suite: `https://business.facebook.com/latest/content_calendar_and_posts`
2. Extension icon par click karein aur **"Open Live Dashboard"** dabayein.
3. Dashboard par **"Connect FB Tab"** indicator green (🟢 Connected) show kare ga.
4. **"Scan & Fetch Videos"** button dabayein: Content script Facebook page par scroll kar ke videos fetch kare ga.
5. Review karein: Jo videos delete karni hain unhein select karein ya **"Auto-Delete All Videos"** dabayein.
6. Safety delay ke mutabiq extension ek ek video ke 3-dots menu par click kare ga, confirmation handle kare ga, aur live progress report kare ga.
