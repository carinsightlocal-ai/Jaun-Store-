/**
 * FB Cleaner Side Panel Controller
 * Handles Auto-Pilot continuous execution, DOM updates, real-time logs, and language toggles
 */

const I18N = {
  en: {
    btn_start_autopilot: "Start Auto-Pilot (All Posts)",
    btn_stop_autopilot: "Stop Auto-Pilot",
    scan_batch: "Scan Batch",
    pause: "Pause",
    resume: "Resume",
    abort: "Stop",
    safety_delay: "Cooldown Delay:",
    dry_run: "Dry Run (Preview)",
    stop_err: "Stop on Error",
    stat_found: "Found",
    stat_deleted: "Deleted",
    stat_pending: "Pending",
    stat_failed: "Failed",
    status_ready: "Status: Ready to clean",
    status_autopilot: "Status: ⚡ Auto-Pilot Running...",
    status_paused: "Status: Paused",
    empty_tip: "Open your Facebook Page or Group on the left, then click <strong>'Start Auto-Pilot'</strong> to automatically fetch and delete all posts!"
  },
  ur: {
    btn_start_autopilot: "Auto-Pilot Shuru Karein (All Posts)",
    btn_stop_autopilot: "Auto-Pilot Rokein",
    scan_batch: "Scan Karein",
    pause: "Waqfa (Pause)",
    resume: "Dobara Shuru",
    abort: "Rokein (Stop)",
    safety_delay: "Cooldown Waqfa (Delay):",
    dry_run: "Dry Run (Sirf Test)",
    stop_err: "Error par Stop",
    stat_found: "Total",
    stat_deleted: "Deleted",
    stat_pending: "Baqi",
    stat_failed: "Failed",
    status_ready: "Status: Clean karne ke liye tayyar",
    status_autopilot: "Status: ⚡ Auto-Pilot Chal Raha Hai...",
    status_paused: "Status: Roka gaya hai (Paused)",
    empty_tip: "Left side par Facebook page open karein, aur <strong>'Auto-Pilot Shuru Karein'</strong> dabayein. Tamam posts khud ba khud delete hoti jayen gi!"
  }
};

let currentLang = 'ur';
let currentTypeFilter = 'all';
let searchQuery = '';

const isExtension = typeof chrome !== 'undefined' && chrome.runtime && !!chrome.runtime.id;

let state = {
  isConnected: false,
  pageTitle: '',
  pageUrl: '',
  isScanning: false,
  isDeleting: false,
  isAutoPilot: false,
  isPaused: false,
  dryRun: false,
  delaySeconds: 4,
  stopOnError: false,
  posts: [],
  logs: [],
  stats: { totalFound: 0, deleted: 0, pending: 0, failed: 0 }
};

const dom = {
  connDot: document.getElementById('conn-dot'),
  connTitle: document.getElementById('conn-title'),
  connUrl: document.getElementById('conn-url'),
  btnConnect: document.getElementById('btn-connect'),

  btnSettings: document.getElementById('btn-settings'),
  settingsDrawer: document.getElementById('settings-drawer'),
  delayRange: document.getElementById('delay-range'),
  delayVal: document.getElementById('delay-val'),
  toggleDryRun: document.getElementById('toggle-dry-run'),
  toggleStopErr: document.getElementById('toggle-stop-err'),

  btnAutopilot: document.getElementById('btn-autopilot'),
  autopilotText: document.getElementById('autopilot-text'),
  btnScan: document.getElementById('btn-scan'),
  btnPause: document.getElementById('btn-pause'),
  btnResume: document.getElementById('btn-resume'),
  btnStop: document.getElementById('btn-stop'),

  statTotal: document.getElementById('stat-total'),
  statDeleted: document.getElementById('stat-deleted'),
  statPending: document.getElementById('stat-pending'),
  statFailed: document.getElementById('stat-failed'),

  progressStatus: document.getElementById('progress-status'),
  progressPct: document.getElementById('progress-pct'),
  progressFill: document.getElementById('progress-fill'),

  filterChips: document.querySelectorAll('.chip'),
  searchInput: document.getElementById('search-input'),
  postsContainer: document.getElementById('posts-container'),

  termLogs: document.getElementById('term-logs'),
  chkAutoscroll: document.getElementById('chk-autoscroll'),
  btnClearTerm: document.getElementById('btn-clear-term'),

  langUr: document.getElementById('lang-ur'),
  langEn: document.getElementById('lang-en')
};

function setLanguage(lang) {
  currentLang = lang;
  dom.langUr.classList.toggle('active', lang === 'ur');
  dom.langEn.classList.toggle('active', lang === 'en');

  const dict = I18N[lang];
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    if (dict[key]) el.innerHTML = dict[key];
  });

  updateControlsUI();
}

function updateConnectionUI() {
  if (state.isConnected) {
    dom.connDot.className = state.isAutoPilot ? 'pulse-dot running' : 'pulse-dot connected';
    dom.connTitle.textContent = state.pageTitle || 'Facebook Page';
    dom.connUrl.textContent = state.pageUrl || '';
  } else {
    dom.connDot.className = 'pulse-dot';
    dom.connTitle.textContent = 'Not Connected';
    dom.connUrl.textContent = 'Open Facebook tab in browser';
  }
}

function updateStatsUI() {
  const s = state.stats || { totalFound: 0, deleted: 0, pending: 0, failed: 0 };
  dom.statTotal.textContent = s.totalFound;
  dom.statDeleted.textContent = s.deleted;
  dom.statPending.textContent = s.pending;
  dom.statFailed.textContent = s.failed;

  const pct = s.totalFound > 0 ? Math.round(((s.deleted + s.failed) / s.totalFound) * 100) : 0;
  dom.progressPct.textContent = `${pct}%`;
  dom.progressFill.style.width = `${pct}%`;

  const dict = I18N[currentLang];
  if (state.isAutoPilot) {
    dom.progressStatus.textContent = state.isPaused ? dict.status_paused : dict.status_autopilot;
  } else {
    dom.progressStatus.textContent = dict.status_ready;
  }
}

function updateControlsUI() {
  const dict = I18N[currentLang];

  if (state.isAutoPilot) {
    dom.btnAutopilot.classList.add('running');
    dom.autopilotText.textContent = dict.btn_stop_autopilot;
    dom.btnStop.classList.remove('hidden');

    if (state.isPaused) {
      dom.btnPause.classList.add('hidden');
      dom.btnResume.classList.remove('hidden');
    } else {
      dom.btnPause.classList.remove('hidden');
      dom.btnResume.classList.add('hidden');
    }
  } else {
    dom.btnAutopilot.classList.remove('running');
    dom.autopilotText.textContent = dict.btn_start_autopilot;
    dom.btnPause.classList.add('hidden');
    dom.btnResume.classList.add('hidden');
    dom.btnStop.classList.add('hidden');
  }

  dom.delayRange.value = state.delaySeconds || 4;
  dom.delayVal.textContent = (state.delaySeconds || 4) + 's';
  dom.toggleDryRun.checked = !!state.dryRun;
  dom.toggleStopErr.checked = !!state.stopOnError;
}

function renderPostsList() {
  const container = dom.postsContainer;
  let list = state.posts || [];

  if (currentTypeFilter !== 'all') {
    list = list.filter(p => p.type === currentTypeFilter);
  }
  if (searchQuery.trim()) {
    const q = searchQuery.toLowerCase();
    list = list.filter(p => (p.title && p.title.toLowerCase().includes(q)) || (p.id && p.id.includes(q)));
  }

  if (list.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <p>${I18N[currentLang].empty_tip}</p>
      </div>
    `;
    return;
  }

  container.innerHTML = '';
  list.forEach(p => {
    const item = document.createElement('div');
    item.className = 'post-item';

    let icon = '📝';
    if (p.type === 'video') icon = '🎬';
    else if (p.type === 'reel') icon = '📱';
    else if (p.type === 'photo') icon = '🖼️';

    item.innerHTML = `
      <div class="post-type-icon">${icon}</div>
      <div class="post-details">
        <div class="post-title" title="${escapeHtml(p.title || p.id)}">${escapeHtml(p.title || 'Post #' + p.id)}</div>
        <div class="post-meta">
          <span>${p.timestamp || 'Recently'}</span>
          ${p.error ? `<span style="color:#f87171;">⚠️ ${escapeHtml(p.error)}</span>` : ''}
        </div>
      </div>
      <div class="post-status-tag tag-${p.status}">${p.status}</div>
      ${p.status === 'pending' ? `<button class="btn-xs btn-outline btn-del-single" data-id="${p.id}" title="Delete">🗑️</button>` : ''}
    `;

    const delBtn = item.querySelector('.btn-del-single');
    if (delBtn) {
      delBtn.addEventListener('click', () => {
        deleteSinglePost(p.id);
      });
    }

    container.appendChild(item);
  });
}

function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function appendLog(log) {
  const line = document.createElement('div');
  line.className = `log-line log-${log.level || 'info'}`;
  line.innerHTML = `
    <span class="log-t">[${log.timestamp || new Date().toLocaleTimeString()}]</span>
    <span class="log-m">${escapeHtml(log.message)}</span>
  `;

  dom.termLogs.prepend(line);
  if (dom.termLogs.children.length > 150) {
    dom.termLogs.lastElementChild.remove();
  }
  if (dom.chkAutoscroll.checked) {
    dom.termLogs.scrollTop = 0;
  }
}

function applyState(newState) {
  state = { ...state, ...newState };
  updateConnectionUI();
  updateStatsUI();
  updateControlsUI();
  renderPostsList();
}

// Background Actions
function fetchState() {
  if (isExtension) {
    chrome.runtime.sendMessage({ action: 'GET_STATE' }, res => {
      if (res && res.state) {
        applyState(res.state);
        if (res.state.logs) {
          dom.termLogs.innerHTML = '';
          res.state.logs.slice(0, 80).forEach(appendLog);
        }
      }
    });
  } else {
    // Standalone Mock Preview
    const mockPosts = [
      { id: '1', title: 'Top 10 Unreal Engine 5 Gameplay Moments', type: 'video', status: 'deleted', timestamp: '1d ago' },
      { id: '2', title: 'Viral Comedy Reel #42', type: 'reel', status: 'pending', timestamp: '2d ago' },
      { id: '3', title: 'New Studio Setup Photo Album', type: 'photo', status: 'pending', timestamp: '3d ago' },
      { id: '4', title: 'Important Announcement: Stream scheduled for Friday', type: 'post', status: 'pending', timestamp: '4d ago' }
    ];
    applyState({
      isConnected: true,
      pageTitle: 'Tech Official Facebook Page',
      pageUrl: 'https://facebook.com/tech/videos',
      posts: mockPosts,
      stats: { totalFound: 4, deleted: 1, pending: 3, failed: 0 }
    });
  }
}

function toggleAutoPilot() {
  if (state.isAutoPilot) {
    if (isExtension) chrome.runtime.sendMessage({ action: 'STOP_AUTOPILOT' });
    state.isAutoPilot = false;
    updateControlsUI();
  } else {
    if (isExtension) {
      chrome.runtime.sendMessage({ action: 'START_AUTOPILOT' }, res => {
        if (!res || !res.success) alert(res?.message || 'Open a Facebook tab first!');
      });
    } else {
      state.isAutoPilot = true;
      updateControlsUI();
      appendLog({ level: 'warn', message: '⚡ Auto-Pilot started in preview simulation!' });
    }
  }
}

function deleteSinglePost(id) {
  if (isExtension) {
    chrome.runtime.sendMessage({ action: 'DELETE_SINGLE', postId: id });
  } else {
    const p = state.posts.find(x => x.id === id);
    if (p) {
      p.status = 'deleted';
      state.stats.deleted++;
      state.stats.pending = Math.max(0, state.stats.pending - 1);
      updateStatsUI();
      renderPostsList();
      appendLog({ level: 'success', message: `Deleted single post: "${p.title}"` });
    }
  }
}

function updateSettings() {
  const delaySeconds = parseInt(dom.delayRange.value, 10) || 4;
  const dryRun = dom.toggleDryRun.checked;
  const stopOnError = dom.toggleStopErr.checked;

  dom.delayVal.textContent = delaySeconds + 's';
  state.delaySeconds = delaySeconds;
  state.dryRun = dryRun;
  state.stopOnError = stopOnError;

  if (isExtension) {
    chrome.runtime.sendMessage({ action: 'UPDATE_SETTINGS', delaySeconds, dryRun, stopOnError });
  }
}

function setupListeners() {
  dom.btnAutopilot.addEventListener('click', toggleAutoPilot);
  
  dom.btnScan.addEventListener('click', () => {
    if (isExtension) chrome.runtime.sendMessage({ action: 'START_SCAN' });
  });

  dom.btnPause.addEventListener('click', () => {
    if (isExtension) chrome.runtime.sendMessage({ action: 'PAUSE_DELETE' });
  });

  dom.btnResume.addEventListener('click', () => {
    if (isExtension) chrome.runtime.sendMessage({ action: 'RESUME_DELETE' });
  });

  dom.btnStop.addEventListener('click', () => {
    if (isExtension) chrome.runtime.sendMessage({ action: 'STOP_AUTOPILOT' });
  });

  dom.btnConnect.addEventListener('click', () => {
    if (isExtension) chrome.runtime.sendMessage({ action: 'CONNECT_TAB' });
  });

  dom.btnSettings.addEventListener('click', () => {
    dom.settingsDrawer.classList.toggle('hidden');
  });

  dom.delayRange.addEventListener('input', updateSettings);
  dom.toggleDryRun.addEventListener('change', updateSettings);
  dom.toggleStopErr.addEventListener('change', updateSettings);

  dom.filterChips.forEach(chip => {
    chip.addEventListener('click', () => {
      dom.filterChips.forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      currentTypeFilter = chip.getAttribute('data-type');
      renderPostsList();
    });
  });

  dom.searchInput.addEventListener('input', (e) => {
    searchQuery = e.target.value;
    renderPostsList();
  });

  dom.btnClearTerm.addEventListener('click', () => {
    if (isExtension) chrome.runtime.sendMessage({ action: 'CLEAR_LOGS' });
    dom.termLogs.innerHTML = '';
  });

  dom.langUr.addEventListener('click', () => setLanguage('ur'));
  dom.langEn.addEventListener('click', () => setLanguage('en'));
}

if (isExtension) {
  chrome.runtime.onMessage.addListener(msg => {
    if (msg.action === 'STATE_UPDATED') {
      applyState(msg.state);
    } else if (msg.action === 'LOG_ADDED') {
      appendLog(msg.log);
      if (msg.stats) {
        state.stats = msg.stats;
        updateStatsUI();
      }
    }
  });
}

document.addEventListener('DOMContentLoaded', () => {
  setupListeners();
  setLanguage('ur');
  fetchState();
});
